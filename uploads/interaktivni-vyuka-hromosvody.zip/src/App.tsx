import React, { useState, useEffect, useMemo } from 'react';
import { Zap, Shield, ShieldAlert, Home, Info, CheckCircle2, AlertTriangle, Activity, Share2, X, GraduationCap, RefreshCcw, Award } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { allQuestions } from './data/quizQuestions';

const App = () => {
  const [hasProtection, setHasProtection] = useState(true);
  const [isStriking, setIsStriking] = useState(false);
  const [strikeResult, setStrikeResult] = useState<'safe' | 'danger' | null>(null);
  const [voltage, setVoltage] = useState(0);
  const [current, setCurrent] = useState(0);
  const [isShaking, setIsShaking] = useState(false);
  const [activeTab, setActiveTab] = useState('simulation');
  const [showQR, setShowQR] = useState(false);
  const [activeComponent, setActiveComponent] = useState<string | null>(null);

  // Quiz state
  const [quizStarted, setQuizStarted] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [quizScore, setQuizScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);

  // Get 10 random questions from the pool of 50
  const quizQuestions = useMemo(() => {
    return [...allQuestions]
      .sort(() => Math.random() - 0.5)
      .slice(0, 10);
  }, [quizFinished]); // Re-shuffle only when restarting (after finish)

  const handleAnswerClick = (index: number) => {
    if (isAnswered) return;
    setSelectedAnswer(index);
    setIsAnswered(true);
    if (index === quizQuestions[currentQuestionIndex].correctAnswer) {
      setQuizScore(prev => prev + 1);
    }
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < quizQuestions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
    } else {
      setQuizFinished(true);
    }
  };

  const resetQuiz = () => {
    setQuizStarted(false);
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setIsAnswered(false);
    setQuizScore(0);
    setQuizFinished(false);
  };

  const simulateStrike = () => {
    setIsStriking(true);
    setStrikeResult(null);
    setIsShaking(true);
    
    // Animate voltage/current spike
    const startTime = Date.now();
    
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      if (elapsed < 300) {
        setVoltage(Math.floor(Math.random() * 500 + 800)); // MV
        setCurrent(Math.floor(Math.random() * 50 + 150)); // kA
      } else if (elapsed < 1000) {
        setVoltage(prev => Math.max(0, prev - (prev * 0.1)));
        setCurrent(prev => Math.max(0, prev - (prev * 0.1)));
      } else {
        clearInterval(interval);
      }
    }, 40);

    setTimeout(() => {
      setIsStriking(false);
      setIsShaking(false);
      setStrikeResult(hasProtection ? 'safe' : 'danger');
      if (hasProtection) {
        setVoltage(0);
        setCurrent(0);
      }
    }, 1000);
  };

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(currentUrl)}`;

  const TheorySection = ({ title, icon: Icon, children }: { title: string, icon: any, children: React.ReactNode }) => (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 mb-4"
    >
      <div className="flex items-center gap-2 mb-3 text-blue-700 font-bold border-b pb-2">
        <Icon size={20} />
        <h2>{title}</h2>
      </div>
      <div className="text-slate-600 text-sm leading-relaxed">
        {children}
      </div>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans">
      {/* QR Code Modal */}
      <AnimatePresence>
        {showQR && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white p-8 rounded-2xl shadow-2xl max-w-xs w-full text-center relative"
            >
              <button 
                onClick={() => setShowQR(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 cursor-pointer"
                id="close-qr-button"
              >
                <X size={24} />
              </button>
              <h3 className="text-xl font-bold text-slate-800 mb-4">Sdílet lekci</h3>
              <div className="bg-slate-100 p-4 rounded-xl mb-4 inline-block">
                <img src={qrCodeUrl} alt="QR kód pro sdílení" className="w-48 h-48 mx-auto" referrerPolicy="no-referrer" />
              </div>
              <p className="text-sm text-slate-500 mb-2">Naskenujte kód telefonem pro rychlý přístup k interaktivní lekci.</p>
              <div className="text-[10px] text-slate-400 break-all">{currentUrl}</div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <header className="max-w-4xl mx-auto mb-8 text-center relative">
        <div className="absolute right-0 top-0">
          <button 
            onClick={() => setShowQR(true)}
            className="flex items-center gap-2 bg-white border border-slate-200 px-3 py-1.5 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors text-sm font-medium shadow-sm cursor-pointer"
            id="share-button"
          >
            <Share2 size={16} />
            <span className="hidden sm:inline">Sdílet</span>
          </button>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-800 mb-2 flex flex-col sm:flex-row items-center justify-center gap-2">
          <Zap className="text-yellow-500" fill="currentColor" />
          Hromosvody: Cesta nejmenšího odporu
        </h1>
        <p className="text-slate-600 italic">Interaktivní lekce pro budoucí elektrikáře</p>
      </header>

      <main className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Sidebar Navigation */}
        <div className="lg:col-span-3 space-y-2">
          <button 
            onClick={() => setActiveTab('simulation')}
            className={`w-full text-left p-3 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${activeTab === 'simulation' ? 'bg-blue-600 text-white shadow-md' : 'bg-white text-slate-600 hover:bg-slate-100'}`}
            id="nav-simulation"
          >
            <Activity size={18} /> Simulace výboje
          </button>
          <button 
            onClick={() => setActiveTab('components')}
            className={`w-full text-left p-3 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${activeTab === 'components' ? 'bg-blue-600 text-white shadow-md' : 'bg-white text-slate-600 hover:bg-slate-100'}`}
            id="nav-components"
          >
            <Shield size={18} /> Části soustavy
          </button>
          <button 
            onClick={() => setActiveTab('safety')}
            className={`w-full text-left p-3 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${activeTab === 'safety' ? 'bg-blue-600 text-white shadow-md' : 'bg-white text-slate-600 hover:bg-slate-100'}`}
            id="nav-safety"
          >
            <ShieldAlert size={18} /> Bezpečnost a normy
          </button>
          <button 
            onClick={() => setActiveTab('quiz')}
            className={`w-full text-left p-3 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${activeTab === 'quiz' ? 'bg-blue-600 text-white shadow-md' : 'bg-white text-slate-600 hover:bg-slate-100'}`}
            id="nav-quiz"
          >
            <GraduationCap size={18} /> Závěrečný test
          </button>
          
          <div className="mt-8 p-4 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl text-white shadow-lg hidden lg:block">
            <h4 className="font-bold mb-2 flex items-center gap-2">
              <Share2 size={16} /> QR kód lekce
            </h4>
            <div className="bg-white p-2 rounded-lg mb-2">
              <img src={qrCodeUrl} alt="QR kód" className="w-full" referrerPolicy="no-referrer" />
            </div>
            <p className="text-[10px] opacity-80 text-center">Naskenuj a studuj v mobilu</p>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="lg:col-span-9">
          <AnimatePresence mode="wait">
            {activeTab === 'simulation' && (
              <motion.div 
                key="simulation"
                initial={{ opacity: 0, x: 20 }}
                animate={{ 
                  opacity: 1, 
                  x: isShaking ? [0, -2, 2, -2, 2, 0] : 0 
                }}
                transition={{ duration: 0.1, repeat: isShaking ? 10 : 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200 relative overflow-hidden min-h-[450px] flex flex-col items-center justify-center">
                  {/* Sky background */}
                  <div className={`absolute inset-0 transition-colors duration-500 ${isStriking ? 'bg-slate-700' : 'bg-blue-50'}`} />
                  
                  {/* Dynamic Clouds */}
                  <motion.div 
                    animate={{ x: isStriking ? [-5, 5, -5] : [0, 10, 0] }}
                    transition={{ duration: 5, repeat: Infinity }}
                    className="absolute top-10 w-full flex justify-around opacity-40 pointer-events-none"
                  >
                    {[1, 2, 3].map(i => (
                      <div key={i} className={`h-12 w-24 bg-white rounded-full blur-xl ${isStriking ? 'bg-slate-400' : 'bg-white'}`} />
                    ))}
                  </motion.div>

                  {/* Voltage/Current Meter */}
                  <AnimatePresence>
                    {(voltage > 0 || current > 0) && (
                      <motion.div 
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        className="absolute top-6 right-6 z-20 space-y-2"
                      >
                        <div className="bg-black/80 backdrop-blur text-white px-4 py-2 rounded-lg border border-yellow-500/50 min-w-[140px]">
                          <div className="text-[10px] uppercase font-bold text-yellow-500 tracking-widest mb-1 flex items-center gap-1">
                            <Activity size={12} /> Napětí
                          </div>
                          <div className="text-xl font-mono tabular-nums leading-none">
                            {voltage} <span className="text-xs text-slate-400">MV</span>
                          </div>
                        </div>
                        <div className="bg-black/80 backdrop-blur text-white px-4 py-2 rounded-lg border border-orange-500/50 min-w-[140px]">
                          <div className="text-[10px] uppercase font-bold text-orange-500 tracking-widest mb-1 flex items-center gap-1">
                            <Zap size={12} /> Proud
                          </div>
                          <div className="text-xl font-mono tabular-nums leading-none">
                            {current} <span className="text-xs text-slate-400">kA</span>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* The House Drawing (SVG) */}
                  <div 
                    className="relative z-10 w-full max-w-sm"
                  >
                    <svg viewBox="0 0 200 200" className="w-full h-auto drop-shadow-2xl">
                      {/* Lightning Strike Path */}
                      <AnimatePresence>
                        {isStriking && (
                          <motion.g
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                          >
                            {/* The Main Bolt */}
                            <motion.path 
                              initial={{ pathLength: 0, opacity: 0 }}
                              animate={{ 
                                pathLength: 1, 
                                opacity: [0, 1, 0.5, 1, 0.4, 1, 0] 
                              }}
                              transition={{
                                pathLength: { duration: 0.15, ease: "easeIn" },
                                opacity: { duration: 0.6, times: [0, 0.2, 0.3, 0.4, 0.6, 0.8, 1] }
                              }}
                              d={hasProtection 
                                ? "M110,-20 L95,10 L105,40" 
                                : "M95,-20 L110,15 L85,45 L115,75 L100,100"
                              } 
                              fill="none" 
                              stroke="white" 
                              strokeWidth="4" 
                              strokeLinecap="round"
                              className="drop-shadow-[0_0_20px_rgba(255,255,255,1)]"
                            />
                            {/* Branching */}
                            {!hasProtection && (
                              <motion.path 
                                initial={{ pathLength: 0, opacity: 0 }}
                                animate={{ pathLength: 1, opacity: [0, 0.7, 0] }}
                                transition={{ delay: 0.05, duration: 0.2 }}
                                d="M110,15 L130,30 M85,45 L65,55"
                                fill="none"
                                stroke="#fbbf24"
                                strokeWidth="2"
                              />
                            )}
                            {/* Secondary Glow Bolt */}
                            <motion.path 
                              initial={{ pathLength: 0, opacity: 0 }}
                              animate={{ 
                                pathLength: 1, 
                                opacity: [0, 0.5, 0] 
                              }}
                              transition={{ duration: 0.3, ease: "easeIn" }}
                              d={hasProtection 
                                ? "M110,-20 L95,10 L105,40" 
                                : "M95,-20 L110,15 L85,45 L115,75 L100,100"
                              } 
                              fill="none" 
                              stroke="#fbbf24" 
                              strokeWidth="8" 
                              strokeLinecap="round"
                              className="blur-sm"
                            />
                            {/* Impact Flash Circle */}
                            <motion.circle 
                              cx={hasProtection ? 105 : 100} cy={hasProtection ? 40 : 100}
                              initial={{ r: 0 }}
                              animate={{ r: [0, 40, 60], opacity: [0, 1, 0] }}
                              transition={{ duration: 0.5 }}
                              fill="white"
                              className="blur-md"
                            />
                          </motion.g>
                        )}
                      </AnimatePresence>
                      
                      {/* Damage effect (Enhanced Smoke) */}
                      {strikeResult === 'danger' && (
                        <motion.g initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                          {[1, 2, 3, 4, 5, 6, 7].map(i => (
                            <motion.circle 
                              key={`smoke-${i}`}
                              cx={70 + (i % 3) * 20}
                              cy={80}
                              animate={{ 
                                y: [0, -150],
                                x: [70 + (i % 3) * 20, 60 + (i % 3) * 30 + (Math.sin(i) * 40)],
                                opacity: [0, 0.4, 0],
                                r: [5, 35]
                              }}
                              transition={{ 
                                duration: 3 + (i * 0.2), 
                                repeat: Infinity, 
                                delay: i * 0.3,
                                ease: "easeOut"
                              }}
                              fill="#334155"
                            />
                          ))}
                          {/* Embers/Sparks */}
                          {[1, 2, 3, 4].map(i => (
                            <motion.circle 
                              key={`spark-${i}`}
                              cx={90 + (i * 8)}
                              cy={90}
                              animate={{ 
                                y: [0, -60, -20],
                                x: [90 + i * 8, 70 + i * 15, 110 + i * 5],
                                opacity: [1, 1, 0],
                                scale: [1, 2, 0]
                              }}
                              transition={{ duration: 0.7, repeat: Infinity, delay: i * 0.15 }}
                              fill="#f97316"
                            />
                          ))}
                        </motion.g>
                      )}

                      {/* Screen Flash Overlay */}
                      <AnimatePresence>
                        {isStriking && (
                          <motion.rect
                            initial={{ opacity: 0 }}
                            animate={{ opacity: [0, 1, 0] }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            x="-50" y="-50" width="300" height="300"
                            fill="white"
                            className="pointer-events-none z-50"
                          />
                        )}
                      </AnimatePresence>

                      {/* Ground */}
                      <rect x="0" y="180" width="200" height="20" fill="#3f6212" />
                      <rect x="0" y="185" width="200" height="15" fill="#365314" />

                      {/* House Body */}
                      <rect 
                        x="50" y="100" width="100" height="80" 
                        fill={strikeResult === 'danger' ? '#475569' : '#f8fafc'} 
                        stroke="#cbd5e1"
                        strokeWidth="1"
                        className="transition-colors duration-1000" 
                      />
                      <polygon points="40,100 160,100 100,50" fill={strikeResult === 'danger' ? '#1e293b' : '#475569'} className="transition-colors duration-1000" />
                      
                      {/* Charred effect for danger result */}
                      {strikeResult === 'danger' && (
                        <motion.path 
                          initial={{ opacity: 0 }}
                          animate={{ opacity: [0, 1, 0.8] }}
                          d="M100,50 L120,65 L100,75 L80,65 Z" 
                          fill="#0f172a" 
                          className="blur-[2px] opacity-60"
                        />
                      )}
                      
                      {/* Windows */}
                      <rect x="65" y="115" width="20" height="20" fill={isStriking ? "#fef08a" : "#bae6fd"} className="transition-colors duration-200" />
                      <rect x="115" y="115" width="20" height="20" fill={isStriking ? "#fef08a" : "#bae6fd"} className="transition-colors duration-200" />
                      <rect x="85" y="145" width="30" height="35" fill="#94a3b8" />

                      {/* Lightning Rod (Conditional) */}
                      {hasProtection && (
                        <g>
                          <line x1="105" y1="40" x2="105" y2="45" stroke="#1e293b" strokeWidth="2.5" />
                          <circle cx="105" cy="40" r="2" fill="#3b82f6" />
                          {/* Down conductor */}
                          <path d="M105,45 L165,85 L165,185" fill="none" stroke="#1e293b" strokeWidth="2" />
                          
                          {/* Current flow visualization */}
                          {isStriking && (
                            <motion.path 
                              initial={{ pathLength: 0 }}
                              animate={{ pathLength: 1 }}
                              d="M105,40 L105,45 L165,85 L165,185" 
                              fill="none" 
                              stroke="#3b82f6" 
                              strokeWidth="4" 
                              strokeLinecap="round"
                            />
                          )}
                        </g>
                      )}
                    </svg>
                  </div>

                  {/* Simulation Controls */}
                  <div className="relative z-20 mt-8 w-full flex flex-col md:flex-row gap-4 items-center justify-between bg-white/90 backdrop-blur p-4 rounded-xl border border-slate-200 shadow-xl">
                    <div className="flex items-center gap-4">
                      <span className="text-sm font-bold text-slate-700">Hromosvod:</span>
                      <button 
                        onClick={() => setHasProtection(!hasProtection)}
                        className={`px-4 py-2 rounded-full font-medium transition-all cursor-pointer ${hasProtection ? 'bg-green-100 text-green-700 border-2 border-green-500' : 'bg-red-100 text-red-700 border-2 border-red-500'}`}
                        id="toggle-protection"
                      >
                        {hasProtection ? 'INSTALOVÁN' : 'CHYBÍ'}
                      </button>
                    </div>
                    
                    <button 
                      disabled={isStriking}
                      onClick={simulateStrike}
                      className="bg-yellow-500 hover:bg-yellow-600 disabled:bg-slate-300 text-white font-bold py-3 px-8 rounded-xl shadow-lg transition-transform active:scale-95 flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed"
                      id="trigger-strike"
                    >
                      <Zap size={20} /> VYVOLAT VÝBOJ
                    </button>
                  </div>

                  {/* Results message */}
                  <AnimatePresence>
                    {strikeResult && (
                      <motion.div 
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className={`absolute top-4 left-4 right-4 p-4 rounded-lg flex items-center gap-3 shadow-lg z-20 ${strikeResult === 'safe' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}`}
                      >
                        {strikeResult === 'safe' ? (
                          <>
                            <CheckCircle2 />
                            <span><strong>V pořádku!</strong> Energie byla bezpečně svedena do uzemnění. Dům i obyvatelé jsou v bezpečí.</span>
                          </>
                        ) : (
                          <>
                            <AlertTriangle />
                            <span><strong>KATASTROFA!</strong> Výboj prošel konstrukcí domu. Riziko požáru, zničení elektroinstalace a ohrožení života!</span>
                          </>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
                    <h3 className="font-bold text-blue-800 mb-2 flex items-center gap-2"><Info size={18}/> Úkol pro vás:</h3>
                    <p className="text-sm text-blue-700">Vypněte hromosvod a sledujte, co se stane. Poté si všimněte, kudy teče proud, když je ochrana zapnutá. Proud si vždy vybírá cestu s nejnižší impedancí.</p>
                  </div>
                  <div className="bg-amber-50 p-4 rounded-xl border border-amber-100 text-sm">
                    <h3 className="font-bold text-amber-800 mb-2">Zapamatujte si:</h3>
                    <ul className="list-disc ml-4 space-y-1 text-amber-700">
                      <li>Blesk má napětí v milionech voltů.</li>
                      <li>Proud může dosahovat až 200 kA.</li>
                      <li>Ochrana musí být spojitá a revidovaná.</li>
                    </ul>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'components' && (
              <motion.div 
                key="components"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200">
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
                    {/* Interactive SVG Diagram */}
                    <div className="md:col-span-5 flex flex-col items-center justify-center bg-slate-50 rounded-xl p-4 border border-slate-100">
                      <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 font-mono">Schéma LPS</h3>
                      <div className="relative w-full max-w-[250px]">
                        <svg viewBox="0 0 200 220" className="w-full h-auto drop-shadow-md">
                          {/* House Body */}
                          <rect x="50" y="100" width="100" height="80" fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="1" />
                          <polygon points="40,100 160,100 100,50" fill="#94a3b8" stroke="#64748b" strokeWidth="1" />
                          
                          {/* Ground */}
                          <rect x="0" y="180" width="200" height="10" fill="#e2e8f0" />
                          
                          {/* 1. LPS - Jímací soustava */}
                          <g 
                            className={`cursor-pointer group transition-all duration-300 ${activeComponent && activeComponent !== 'lps' ? 'opacity-30 grayscale-[0.5]' : 'opacity-100'}`} 
                            onClick={() => {
                              setActiveComponent('lps');
                              const el = document.getElementById('theory-lps');
                              el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            }}
                          >
                            <line 
                              x1="100" y1="50" x2="100" y2="35" 
                              stroke={activeComponent === 'lps' ? '#2563eb' : '#3b82f6'} 
                              strokeWidth={activeComponent === 'lps' ? '6' : '3'} 
                              className="transition-all" 
                            />
                            <circle 
                              cx="100" cy="35" r={activeComponent === 'lps' ? '6' : '3'} 
                              fill={activeComponent === 'lps' ? '#2563eb' : '#3b82f6'} 
                              className={`${activeComponent === 'lps' ? 'drop-shadow-[0_0_5px_rgba(37,99,235,0.6)]' : 'animate-pulse'}`} 
                            />
                            <line 
                              x1="100" y1="50" x2="40" y2="100" 
                              stroke="#3b82f6" 
                              strokeWidth={activeComponent === 'lps' ? '3' : '2'} 
                              strokeDasharray={activeComponent === 'lps' ? '0' : '4,2'} 
                              className="transition-all"
                            />
                            <line 
                              x1="100" y1="50" x2="160" y2="100" 
                              stroke="#3b82f6" 
                              strokeWidth={activeComponent === 'lps' ? '3' : '2'} 
                              strokeDasharray={activeComponent === 'lps' ? '0' : '4,2'} 
                              className="transition-all"
                            />
                            <circle 
                              cx="140" cy="65" 
                              r={activeComponent === 'lps' ? '14' : '10'} 
                              fill={activeComponent === 'lps' ? '#2563eb' : 'white'} 
                              stroke="#3b82f6" 
                              strokeWidth={activeComponent === 'lps' ? '3' : '2'} 
                              className="transition-all duration-300"
                            />
                            <text 
                              x="140" y={activeComponent === 'lps' ? 70 : 69} 
                              textAnchor="middle" 
                              className={`text-[12px] font-black transition-all ${activeComponent === 'lps' ? 'fill-white scale-125' : 'fill-blue-600'}`}
                            >1</text>
                          </g>

                          {/* 2. Svody */}
                          <g 
                            className={`cursor-pointer group transition-all duration-300 ${activeComponent && activeComponent !== 'svody' ? 'opacity-30 grayscale-[0.5]' : 'opacity-100'}`}
                            onClick={() => {
                              setActiveComponent('svody');
                              const el = document.getElementById('theory-svody');
                              el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            }}
                          >
                            {/* Energy Flow Glow on group hover or active */}
                            <path 
                              d="M160,100 L160,180" 
                              fill="none" 
                              stroke="#f59e0b" 
                              strokeWidth="10" 
                              className={`transition-opacity ${activeComponent === 'svody' ? 'opacity-30 blur-md' : 'opacity-0 group-hover:opacity-20 blur-md'}`} 
                            />
                            <path 
                              d="M40,100 L40,180" 
                              fill="none" 
                              stroke="#f59e0b" 
                              strokeWidth="10" 
                              className={`transition-opacity ${activeComponent === 'svody' ? 'opacity-30 blur-md' : 'opacity-0 group-hover:opacity-20 blur-md'}`} 
                            />

                            {/* Main Conductor Paths */}
                            <path 
                              d="M160,100 L160,180" 
                              fill="none" 
                              stroke={activeComponent === 'svody' ? '#d97706' : '#f59e0b'} 
                              strokeWidth={activeComponent === 'svody' ? '6' : '3'} 
                              className="transition-all group-hover:stroke-amber-600" 
                            />
                            <path 
                              d="M40,100 L40,180" 
                              fill="none" 
                              stroke={activeComponent === 'svody' ? '#d97706' : '#f59e0b'} 
                              strokeWidth={activeComponent === 'svody' ? '6' : '3'} 
                              className="transition-all group-hover:stroke-amber-600" 
                            />

                            {/* Animated Flow Dots */}
                            <motion.path 
                              d="M160,100 L160,180" 
                              fill="none" 
                              stroke="white" 
                              strokeWidth="2" 
                              strokeDasharray="5,15"
                              className={`pointer-events-none transition-opacity ${activeComponent === 'svody' ? 'opacity-80' : 'opacity-0 group-hover:opacity-60'}`}
                              animate={{ strokeDashoffset: [0, -20] }}
                              transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                            />
                            <motion.path 
                              d="M40,100 L40,180" 
                              fill="none" 
                              stroke="white" 
                              strokeWidth="2" 
                              strokeDasharray="5,15"
                              className={`pointer-events-none transition-opacity ${activeComponent === 'svody' ? 'opacity-80' : 'opacity-0 group-hover:opacity-60'}`}
                              animate={{ strokeDashoffset: [0, -20] }}
                              transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                            />

                            <circle 
                              cx="180" cy="140" 
                              r={activeComponent === 'svody' ? '14' : '10'} 
                              fill={activeComponent === 'svody' ? '#d97706' : 'white'} 
                              stroke="#f59e0b" 
                              strokeWidth={activeComponent === 'svody' ? '3' : '2'} 
                              className="transition-all duration-300"
                            />
                            <text 
                              x="180" y={activeComponent === 'svody' ? 145 : 144} 
                              textAnchor="middle" 
                              className={`text-[12px] font-black transition-all ${activeComponent === 'svody' ? 'fill-white scale-125' : 'fill-amber-600'}`}
                            >2</text>
                          </g>

                          {/* 3. Uzemnění */}
                          <g 
                            className={`cursor-pointer group transition-all duration-300 ${activeComponent && activeComponent !== 'uzemneni' ? 'opacity-30 grayscale-[0.5]' : 'opacity-100'}`}
                            onClick={() => {
                              setActiveComponent('uzemneni');
                              const el = document.getElementById('theory-uzemneni');
                              el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            }}
                          >
                            <line 
                              x1="30" y1="180" x2="170" y2="180" 
                              stroke={activeComponent === 'uzemneni' ? '#059669' : '#10b981'} 
                              strokeWidth={activeComponent === 'uzemneni' ? '8' : '4'} 
                              className="transition-all" 
                            />
                            <line x1="40" y1="180" x2="40" y2="195" stroke="#10b981" strokeWidth={activeComponent === 'uzemneni' ? '3' : '2'} />
                            <line x1="160" y1="180" x2="160" y2="195" stroke="#10b981" strokeWidth={activeComponent === 'uzemneni' ? '3' : '2'} />
                            <circle 
                              cx="100" cy="195" 
                              r={activeComponent === 'uzemneni' ? '14' : '10'} 
                              fill={activeComponent === 'uzemneni' ? '#059669' : 'white'} 
                              stroke="#10b981" 
                              strokeWidth={activeComponent === 'uzemneni' ? '3' : '2'} 
                              className="transition-all duration-300"
                            />
                            <text 
                              x="100" y={activeComponent === 'uzemneni' ? 200 : 199} 
                              textAnchor="middle" 
                              className={`text-[12px] font-black transition-all ${activeComponent === 'uzemneni' ? 'fill-white scale-125' : 'fill-emerald-600'}`}
                            >3</text>
                          </g>

                          {/* 4. Vnitřní ochrana */}
                          <g 
                            className={`cursor-pointer group transition-all duration-300 ${activeComponent && activeComponent !== 'spd' ? 'opacity-30 grayscale-[0.5]' : 'opacity-100'}`}
                            onClick={() => {
                              setActiveComponent('spd');
                              const el = document.getElementById('theory-spd');
                              el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                            }}
                          >
                            <rect 
                              x="85" y="140" 
                              width="30" height="40" 
                              fill={activeComponent === 'spd' ? '#64748b' : '#94a3b8'} 
                              className="transition-colors"
                            />
                            <rect 
                              x="95" y="150" 
                              width={activeComponent === 'spd' ? "14" : "10"} 
                              height={activeComponent === 'spd' ? "14" : "10"} 
                              fill="#ef4444" 
                              className={activeComponent === 'spd' ? 'drop-shadow-[0_0_8px_rgba(239,68,68,0.5)]' : 'animate-pulse'} 
                            />
                            <circle 
                              cx="70" cy="160" 
                              r={activeComponent === 'spd' ? '14' : '10'} 
                              fill={activeComponent === 'spd' ? '#dc2626' : 'white'} 
                              stroke="#ef4444" 
                              strokeWidth={activeComponent === 'spd' ? '3' : '2'} 
                              className="transition-all duration-300"
                            />
                            <text 
                              x="70" y={activeComponent === 'spd' ? 165 : 164} 
                              textAnchor="middle" 
                              className={`text-[12px] font-black transition-all ${activeComponent === 'spd' ? 'fill-white scale-125' : 'fill-red-600'}`}
                            >4</text>
                          </g>
                        </svg>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-4 text-center">Klikněte na čísla pro detaily komponent</p>
                    </div>

                    {/* Detail Text Panels */}
                    <div className="md:col-span-7 space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar p-2">
                      <div id="theory-lps" className="scroll-mt-6 transition-all duration-300">
                        <div className={`p-1 rounded-xl transition-all duration-500 ${activeComponent === 'lps' ? 'ring-2 ring-blue-500 bg-blue-50/50 scale-[1.02]' : ''}`}>
                          <TheorySection title="1. Jímací soustava (LPS)" icon={Shield}>
                            <p className="mb-2">Zachytává přímý zásah blesku. Skládá se z jímacích vodičů, tyčí a mříží na střeše objektu. Je to první kontakt s výbojem.</p>
                            <div className="flex flex-wrap gap-2 mt-2">
                              <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-[10px] border border-blue-100">Jímací tyče</span>
                              <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-[10px] border border-blue-100">Mřížová soustava</span>
                              <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-[10px] border border-blue-100">Pomocné jímače</span>
                            </div>
                          </TheorySection>
                        </div>
                      </div>

                      <div id="theory-svody" className="scroll-mt-6 transition-all duration-300">
                        <div className={`p-1 rounded-xl transition-all duration-500 ${activeComponent === 'svody' ? 'ring-2 ring-amber-500 bg-amber-50/50 scale-[1.02]' : ''}`}>
                          <TheorySection title="2. Svody" icon={Zap}>
                            <p className="mb-2">Vodivé spojení mezi střechou a zemí. Musí být co nejkratší a bez prudkých ohybů, aby blesk „nevyskočil“ z vodiče do vnitřní instalace.</p>
                            <ul className="list-disc ml-4 space-y-1 text-xs text-slate-500">
                              <li>Materiál: FeZn, Cu nebo AlMgSi</li>
                              <li>Uvnitř každého svodu je zkušební svorka pro revizní měření</li>
                            </ul>
                          </TheorySection>
                        </div>
                      </div>

                      <div id="theory-uzemneni" className="scroll-mt-6 transition-all duration-300">
                        <div className={`p-1 rounded-xl transition-all duration-500 ${activeComponent === 'uzemneni' ? 'ring-2 ring-emerald-500 bg-emerald-50/50 scale-[1.02]' : ''}`}>
                          <TheorySection title="3. Uzemňovací soustava" icon={Home}>
                            <p className="mb-2">Zajišťuje bezpečné rozptýlení proudu blesku do země. Čím nižší je odpor půdy, tím rychleji se náboj ztratí.</p>
                            <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-100 text-xs text-emerald-800">
                              <strong>Základový zemnič:</strong> Pásek v betonu základů je nejoblíbenější a nejtrvanlivější volbou pro moderní stavby.
                            </div>
                          </TheorySection>
                        </div>
                      </div>

                      <div id="theory-spd" className="scroll-mt-6 transition-all duration-300">
                        <div className={`p-1 rounded-xl transition-all duration-500 ${activeComponent === 'spd' ? 'ring-2 ring-red-500 bg-red-50/50 scale-[1.02]' : ''}`}>
                          <TheorySection title="4. Vnitřní ochrana (SPD)" icon={ShieldAlert}>
                            <p>Ochrana elektroinstalace před přepětím vzniklým indukcí. SPD (Surge Protection Device) svádí nebezpečné špičky do země dříve, než poškodí čipy.</p>
                            <div className="mt-2 space-y-1">
                              <div className="flex justify-between text-[10px] items-center p-1 border-b border-red-100">
                                <span className="font-bold">Typ 1+2 (T1+T2)</span>
                                <span className="text-slate-400 italic">Hlavní rozváděč u vstupu</span>
                              </div>
                              <div className="flex justify-between text-[10px] items-center p-1">
                                <span className="font-bold">Typ 3 (T3)</span>
                                <span className="text-slate-400 italic">Koncové zásuvky u PC/TV</span>
                              </div>
                            </div>
                          </TheorySection>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'safety' && (
              <motion.div 
                key="safety"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                {/* Section header */}
                <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200">
                  <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <ShieldCheck className="text-green-600" /> Normy ČSN EN 62305 v praxi
                  </h2>
                  <p className="text-slate-600 text-sm mb-6">Pro bezpečnou instalaci nestačí jen materiál, ale dodržení technických parametrů. Klikněte na jednotlivé hodnoty pro detailní vysvětlení.</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {[
                      { val: "10 Ω", label: "Zemní odpor", desc: "Maximální hodnota pro běžné objekty. Nižší odpor = bezpečnější rozptýlení proudu.", icon: Activity },
                      { val: "2-4 roky", label: "Lhůta revize", desc: "U objektů LPS III a IV je lhůta 4 roky, u kritických staveb (školy, nemocnice) 2 roky.", icon: RefreshCcw },
                      { val: "s", label: "Bezpečná vzdálenost", desc: "Výpočtová hodnota k zabránění přeskokům blesku na vnitřní instalace nebo konstrukci.", icon: ShieldAlert }
                    ].map((item, i) => (
                      <motion.div 
                        key={i}
                        whileHover={{ y: -5 }}
                        className="group relative bg-slate-50 p-4 rounded-xl border border-slate-200 cursor-help"
                      >
                        <div className="text-2xl font-black text-blue-600 mb-1">{item.val}</div>
                        <div className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-2">{item.label}</div>
                        <div className="text-[11px] text-slate-400 leading-relaxed group-hover:text-slate-600 transition-colors">
                          {item.desc}
                        </div>
                        <item.icon className="absolute top-4 right-4 text-slate-200 group-hover:text-blue-100 transition-colors" size={24} />
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Myths vs Facts interactive section */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-bold text-slate-800 flex items-center gap-2 px-2">
                      <Info size={18} className="text-blue-500" /> Mýty vs. Fakta
                    </h3>
                    {[
                      { m: "Hromosvod blesky přitahuje z okolí několika kilometrů.", f: "CHYBA. Hromosvod blesky nepřitahuje, dává jim pouze bezpečnou cestu v posledních desítkách metrů dráhy blesku." },
                      { m: "Auto je v bezpečí kvůli gumovým pneumatikám.", f: "CHYBA. Auto chrání kovová karoserie (Faradayova klec), blesk pneumatiky snadno přeskočí i bez kontaktu." },
                      { m: "Mám hromosvod, nemusím mít vnitřní přepěťovou ochranu.", f: "CHYBA. Hromosvod chrání budovu, vnitřní ochrana (SPD) chrání citlivou elektroniku před indukcí." }
                    ].map((item, i) => (
                      <motion.div 
                        key={i}
                        initial={false}
                        className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden"
                      >
                        <div className="p-4 bg-red-50/50 border-b border-red-100 flex gap-3">
                          <X className="text-red-500 shrink-0" size={18} />
                          <p className="text-xs font-semibold text-red-900 italic">{item.m}</p>
                        </div>
                        <div className="p-4 bg-emerald-50/50 flex gap-3">
                          <CheckCircle2 className="text-emerald-500 shrink-0" size={18} />
                          <p className="text-xs text-emerald-900">{item.f}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>

                  {/* Warning section with animation */}
                  <div className="bg-slate-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
                    <div className="absolute -right-8 -bottom-8 opacity-10 rotate-12">
                      <AlertTriangle size={160} />
                    </div>
                    <div className="relative z-10">
                      <h3 className="text-rose-400 font-bold uppercase tracking-widest text-xs mb-4 flex items-center gap-2">
                        <AlertTriangle size={16} /> Kritická rizika v instalaci
                      </h3>
                      <div className="space-y-6">
                        <div className="group">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="w-2 h-10 bg-rose-500 rounded-full" />
                            <h4 className="font-bold">Využití okapu jako svodu</h4>
                          </div>
                          <p className="text-sm text-slate-400 leading-relaxed group-hover:text-slate-200 transition-colors">
                            Okap není projektován pro bleskové proudy. Při úderu může dojít k jeho roztržení, zapálení fasády nebo úrazu osob v blízkosti. <strong>Vždy používejte certifikovaný FeZn drát!</strong>
                          </p>
                        </div>
                        <div className="group">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="w-2 h-10 bg-amber-500 rounded-full" />
                            <h4 className="font-bold">Ostré ohyby a kličky</h4>
                          </div>
                          <p className="text-sm text-slate-400 leading-relaxed group-hover:text-slate-200 transition-colors">
                            Blesk má v ohybu velkou tendenci „vyskočit“ a najít si cestu zdi či elektroinstalací. Poloměr ohybu musí být minimálně 20 cm.
                          </p>
                        </div>
                        <div className="pt-4 border-t border-slate-800">
                          <div className="flex items-center justify-between text-xs font-mono text-slate-500">
                            <span>REVIZNÍ DOKLAD #62305</span>
                            <span className="text-rose-500 px-2 py-0.5 bg-rose-500/10 rounded">NEVYHOVUJE</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'quiz' && (
              <motion.div 
                key="quiz"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200 min-h-[450px] flex flex-col"
              >
                {!quizStarted && !quizFinished ? (
                  <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6">
                    <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mb-2">
                      <GraduationCap size={40} />
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold text-slate-800 mb-2">Závěrečný vědomostní test</h2>
                      <p className="text-slate-600 max-w-md">Ověřte si své znalosti o ochraně před bleskem. Test obsahuje 10 náhodných otázek z naší databáze.</p>
                    </div>
                    <button 
                      onClick={() => setQuizStarted(true)}
                      className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-10 rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer"
                      id="start-quiz"
                    >
                      SPUSTIT TEST
                    </button>
                  </div>
                ) : quizFinished ? (
                  <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6">
                    <motion.div 
                      initial={{ scale: 0.5, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="w-24 h-24 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600 mb-2"
                    >
                      <Award size={48} />
                    </motion.div>
                    <div>
                      <h2 className="text-3xl font-bold text-slate-800 mb-1">Test dokončen!</h2>
                      <p className="text-lg text-slate-600 italic mb-4">Váš výsledek:</p>
                      <div className="text-5xl font-black text-blue-600 mb-2">
                        {quizScore} / 10
                      </div>
                      <p className="text-slate-500">
                        {quizScore === 10 ? "Excelentní výsledek! Jste připraven na revizi." : 
                         quizScore >= 7 ? "Dobrá práce! Máte velmi slušný přehled." : 
                         quizScore >= 5 ? "Průměrný výsledek. Doporučujeme si látku prostudovat znovu." : 
                         "Slabší výsledek. Bezpečnost vyžaduje více studia."}
                      </p>
                    </div>
                    <button 
                      onClick={resetQuiz}
                      className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 px-8 rounded-xl transition-colors cursor-pointer"
                      id="restart-quiz"
                    >
                      <RefreshCcw size={20} /> ZKUSIT ZNOVU
                    </button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="flex justify-between items-center border-b pb-4">
                      <div className="flex items-center gap-2">
                        <span className="bg-blue-600 text-white text-xs font-bold px-2.5 py-1 rounded-full">Otázka {currentQuestionIndex + 1} z 10</span>
                      </div>
                      <div className="text-sm font-medium text-slate-500">
                        Správně: <span className="text-green-600">{quizScore}</span>
                      </div>
                    </div>

                    <h3 className="text-xl font-bold text-slate-800 leading-snug">
                      {quizQuestions[currentQuestionIndex].question}
                    </h3>

                    <div className="space-y-3">
                      {quizQuestions[currentQuestionIndex].options.map((option, idx) => {
                        let buttonStyle = "border-slate-200 hover:bg-slate-50 text-slate-700";
                        if (isAnswered) {
                          if (idx === quizQuestions[currentQuestionIndex].correctAnswer) {
                            buttonStyle = "bg-green-100 border-green-500 text-green-800 ring-2 ring-green-200";
                          } else if (idx === selectedAnswer) {
                            buttonStyle = "bg-red-100 border-red-500 text-red-800 ring-2 ring-red-200";
                          } else {
                            buttonStyle = "opacity-50 border-slate-200";
                          }
                        }

                        return (
                          <button
                            key={idx}
                            disabled={isAnswered}
                            onClick={() => handleAnswerClick(idx)}
                            className={`w-full text-left p-4 rounded-xl border-2 transition-all font-medium flex justify-between items-center group ${buttonStyle} ${!isAnswered ? 'cursor-pointer' : 'cursor-default'}`}
                          >
                            <span>{option}</span>
                            {!isAnswered && (
                              <div className="w-6 h-6 rounded-full border-2 border-slate-200 group-hover:border-blue-400 transition-colors" />
                            )}
                            {isAnswered && idx === quizQuestions[currentQuestionIndex].correctAnswer && (
                              <CheckCircle2 size={18} className="text-green-600" />
                            )}
                            {isAnswered && idx === selectedAnswer && idx !== quizQuestions[currentQuestionIndex].correctAnswer && (
                              <X size={18} className="text-red-600" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    <AnimatePresence>
                      {isAnswered && (
                        <motion.div 
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className={`p-4 rounded-xl text-sm leading-relaxed ${selectedAnswer === quizQuestions[currentQuestionIndex].correctAnswer ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}
                        >
                          <p className="font-bold mb-1">
                            {selectedAnswer === quizQuestions[currentQuestionIndex].correctAnswer ? "Správně!" : "Špatně."}
                          </p>
                          <p>{quizQuestions[currentQuestionIndex].explanation}</p>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {isAnswered && (
                      <div className="pt-4 flex justify-end">
                        <button 
                          onClick={nextQuestion}
                          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-10 rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer flex items-center gap-2"
                        >
                          {currentQuestionIndex === quizQuestions.length - 1 ? "DOKONČIT TEST" : "DALŠÍ OTÁZKA"}
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      <footer className="max-w-4xl mx-auto mt-12 py-8 border-t border-slate-200 text-center text-slate-400 text-sm">
        &copy; {new Date().getFullYear()} Učební materiál pro obor Elektrikář | Bezpečnost na prvním místě
      </footer>
    </div>
  );
};

// Simple icon replacement for missing lucide imports
const ShieldCheck = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>
);

export default App;
