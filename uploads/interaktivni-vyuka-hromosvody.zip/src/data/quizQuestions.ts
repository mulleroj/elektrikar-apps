export interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export const allQuestions: Question[] = [
  {
    question: "Jaký je hlavní účel bleskosvodu (LPS)?",
    options: ["Zabránit vzniku blesku", "Svést bleskový proud bezpečně do země", "Zlepšit příjem televizního signálu", "Ochránit dům před deštěm"],
    correctAnswer: 1,
    explanation: "Hlavním účelem je zachytit blesk a bezpečně ho dovést do uzemnění, aby nedošlo k poškození objektu."
  },
  {
    question: "Co znamená zkratka LPS?",
    options: ["Light Power System", "Lightning Protection System", "Low Pressure Sensor", "Long Phase Signal"],
    correctAnswer: 1,
    explanation: "LPS je mezinárodní zkratka pro Lightning Protection System (Systém ochrany před bleskem)."
  },
  {
    question: "Jaká norma v ČR řeší ochranu před bleskem?",
    options: ["ČSN EN 50110", "ČSN EN 62305", "ČSN 33 2000-4-41", "ČSN EN 61010"],
    correctAnswer: 1,
    explanation: "Soubor norem ČSN EN 62305 (části 1 až 4) je základním předpisem pro navrhování hromosvodů."
  },
  {
    question: "Jaký je doporučený maximální zemní odpor jímací soustavy?",
    options: ["50 Ω", "10 Ω", "100 Ω", "1 Ω"],
    correctAnswer: 1,
    explanation: "Pro většinu objektů je požadován zemní odpor do 10 Ω."
  },
  {
    question: "K čemu slouží zkušební svorka na svodu?",
    options: ["K připevnění okapu", "K rozpojení svodu pro měření zemního odporu", "K uzemnění antény", "K dekoraci fasády"],
    correctAnswer: 1,
    explanation: "Zkušební svorka umožňuje odpojit nadzemní část od uzemnění za účelem revizního měření."
  },
  {
    question: "Z jakého materiálu se nejčastěji vyrábí vodič hromosvodu?",
    options: ["Zinek", "Pozinkovaná ocel (FeZn)", "Hliník (čistý)", "Plast s kovovým jádrem"],
    correctAnswer: 1,
    explanation: "FeZn (žárově pozinkovaná ocel) je nejrozšířenějším materiálem díky poměru cena/výkon."
  },
  {
    question: "Co je to 'dostatečná vzdálenost s'?",
    options: ["Vzdálenost mezi domy", "Vzdálenost mezi hromosvodem a kovovými částmi uvnitř/vně domu", "Délka jímací tyče", "Hloubka uložení zemniče"],
    correctAnswer: 1,
    explanation: "Je to minimální vzdálenost, která brání přeskokům bleskového proudu na jiné vodivé části objektu."
  },
  {
    question: "Který typ přepěťové ochrany (SPD) se instaluje do hlavního rozvaděče?",
    options: ["Typ 3", "Typ 1 (T1)", "Typ 4", "Jen pojistky"],
    correctAnswer: 1,
    explanation: "SPD Typ 1 (nebo kombinovaný T1+T2) zachytává největší energii bleskového proudu na vstupu do objektu."
  },
  {
    question: "Jak často se obvykle provádí revize hromosvodu u běžných rodinných domů (LPS III a IV)?",
    options: ["Každý rok", "Jednou za 4 roky", "Každých 10 let", "Nikdy"],
    correctAnswer: 1,
    explanation: "Podle normy 62305 je lhůta pro pravidelnou revizi u objektů ve třídě III a IV obvykle 4 roky."
  },
  {
    question: "Co tvoří jímací soustavu na střeše?",
    options: ["Okapy a roury", "Jímací vedení, tyče a podpěry", "Anténa a satelit", "Tašky a laťování"],
    correctAnswer: 1,
    explanation: "Jímací soustava sestává z jímacích vodičů, tyčí a pomocných jímačů rozmístěných po střeše."
  },
  {
    question: "Může být hromosvod veden uvnitř zdi?",
    options: ["Ano, pokud je v nehořlavé trubce a dostatečně dimenzován", "Ne, nikdy", "Pouze pokud je ze zlata", "Jen u mrakodrapů"],
    correctAnswer: 0,
    explanation: "Skrytý svod je možný, ale vyžaduje specifické provedení dle norem k eliminaci rizika požáru."
  },
  {
    question: "Jaká je funkce zemniče?",
    options: ["Zahřívat půdu", "Rozptýlit bleskový proud do země", "Chránit před deštěm", "Ukotvit dům proti větru"],
    correctAnswer: 1,
    explanation: "Zemnič zajišťuje bezpečný a rychlý přechod proudu z vodiče do okolní zeminy."
  },
  {
    question: "Jakou barvu má obvykle zemnící vodič v elektroinstalaci?",
    options: ["Černo-bílou", "Zelenou-žlutou", "Hnědou", "Modrou"],
    correctAnswer: 1,
    explanation: "V mezinárodním značení je ochranný vodič (PE/PEN) vždy žlutozelený."
  },
  {
    question: "Co je to 'krokové napětí'?",
    options: ["Napětí při chůzi po koberci", "Riziko úrazu v okolí dopadu blesku kvůli rozdílu potenciálů na délku kroku", "Napětí v zásuvce", "Rychlost blesku"],
    correctAnswer: 1,
    explanation: "Při průchodu velkého proudu zemí vzniká napěťový spád. Rozdíl mezi nohama člověka může být smrtelný."
  },
  {
    question: "Který kov má nejlepší vodivost (ale je drahý pro běžný hromosvod)?",
    options: ["Železo", "Měď (Cu)", "Hliník", "Olovo"],
    correctAnswer: 1,
    explanation: "Měď má vynikající vodivost, používá se u luxusnějších instalací nebo specifických aplikací."
  },
  {
    question: "Může blesk udeřit dvakrát do stejného místa?",
    options: ["Ne, blesk má paměť", "Ano, výškové budovy jsou zasaženy mnohokrát ročně", "Jen v úterý", "Pouze pokud prší ze spodu"],
    correctAnswer: 1,
    explanation: "Výškové budovy, hory nebo věže bývají zasaženy velmi často i během jedné bouřky."
  },
  {
    question: "Co je to Faradayova klec?",
    options: ["Klec na ptáky", "Prostor chráněný vodivým obalem (mříží), kde je uvnitř nulová intenzita elektrického pole", "Výrobce hromosvodů", "Úkryt v podzemí"],
    correctAnswer: 1,
    explanation: "Pokud je objekt obklopen správně navrženou jímací mříží, blesk klouže po povrchu a dovnitř nepronikne."
  },
  {
    question: "Která třída ochrany LPS je nejpřísnější (pro nemocnice, jaderné elektrárny)?",
    options: ["Třída IV", "Třída I", "Třída X", "Třída A"],
    correctAnswer: 1,
    explanation: "Třída I (LPS I) je určena pro objekty s nejvyšším rizikem a vyžaduje nejhustší síť jímačů a svodů."
  },
  {
    question: "Jak hluboko se obvykle ukládá zemnící pásek v zemi?",
    options: ["10 cm", "minimálně 0,6 až 0,8 m", "5 metrů", "Stačí ho položit na trávu"],
    correctAnswer: 1,
    explanation: "Hloubka 60-80 cm zajišťuje stabilní vlhkost a ochranu před mrazem."
  },
  {
    question: "Čím se měří zemní odpor?",
    options: ["Metrem", "Měřičem zemního odporu (např. přístroj PU 180)", "Teploměrem", "Váhou"],
    correctAnswer: 1,
    explanation: "K revizi se používají speciální měřicí přístroje vysílající proud do měřicích sond."
  },
  {
    question: "K čemu slouží SPD Typ 2?",
    options: ["Ochrana před proudem blesku na vstupu", "Střední ochrana před přepětím v podružných rozvaděčích", "Jemná ochrana u zásuvky", "Nepoužívá se"],
    correctAnswer: 1,
    explanation: "Typ 2 (SPD T2) omezuje přepětí, které prošlo přes první stupeň nebo vzniklo spínacími pochody."
  },
  {
    question: "Co se stane, když je svod hromosvodu přerušený?",
    options: ["Nic, blesk přeskočí", "Blesk může nekontrolovaně udeřit do trubek nebo elektroinstalace uvnitř domu", "Hromosvod bude fungovat lépe", "V domě vypadne internet"],
    correctAnswer: 1,
    explanation: "Přerušený svod je extrémně nebezpečný, protože hromadí náboj v místě přerušení a vyvolá ničivý výboj do okolí."
  },
  {
    question: "Jak se jmenuje horní špička hromosvodu?",
    options: ["Hromová jehla", "Jímací tyč", "Sběrač jisker", "Anténní stožár"],
    correctAnswer: 1,
    explanation: "Oficiální termín je jímací tyč (nebo jímací hrot)."
  },
  {
    question: "Jaký tvar má obvykle základový zemnič?",
    options: ["Kulatý", "Plochý pásek (např. 30x4 mm)", "Tvar pyramidy", "Je to jen sypký prášek"],
    correctAnswer: 1,
    explanation: "Uzemňovací pásek o rozměru 30x4 mm v ocelovém provedení FeZn je nejběžnějším standardem."
  },
  {
    question: "Může se jako náhodný zemnič použít armatura v betonu?",
    options: ["Ne, beton izoluje", "Ano, pokud je vodivě propojená a vyhovuje normě", "Pouze v zimě", "Jen u dřevostaveb"],
    correctAnswer: 1,
    explanation: "Železobetonové základy jsou vynikajícím zemničem (základový zemnič), pokud jsou správně svařeny nebo svorkovány."
  },
  {
    question: "Co dělat při bouřce venku na otevřeném poli?",
    options: ["Vylézt na strom", "Lehnout si na zem a roztáhnout ruce", "Dřepnout si s nohama u sebe nebo najít nízký dolík", "Běžet co nejrychleji"],
    correctAnswer: 2,
    explanation: "V dřepu minimalizujete svou výšku a s nohama u sebe omezujete riziko krokového napětí."
  },
  {
    question: "Co je to 'přímý úder blesku'?",
    options: ["Když blesk udeří do sousedního města", "Zásah bleskem přímo do konstrukce nebo LPS objektu", "Hlasitý hřím", "Statická elektřina při svlékání svetru"],
    correctAnswer: 1,
    explanation: "Je to úder vedený přímo do sledovaného objektu, vyžadující nejvyšší úroveň ochrany."
  },
  {
    question: "Který materiál má nejdelší životnost bez koroze v zemi?",
    options: ["Čisté železo", "Nerezová ocel (V4A)", "Hliník", "Dřevo"],
    correctAnswer: 1,
    explanation: "Nerezová ocel V4A je vysoce odolná proti korozi i v agresivním půdním prostředí."
  },
  {
    question: "Proč se u hromosvodů nepoužívají ostré ohyby svodů (pravé úhly)?",
    options: ["Vypadá to ošklivě", "V ostrém ohybu blesk snadněji 'vyskočí' (přeskočí) ven z vodiče", "Vodič by se mohl zlomit", "Špatně se to natírá"],
    correctAnswer: 1,
    explanation: "Blesk má vysokofrekvenční charakter a velkou energii. Ostrý ohyb tvoří velkou impedanci a riziko přeskoku."
  },
  {
    question: "Jak se nazývá výboj mezi mrakem a zemí?",
    options: ["Eliášův oheň", "Blesk", "Polární záře", "Duha"],
    correctAnswer: 1,
    explanation: "Blesk je silný elektrostatický výboj doprovázený světelným jevem (bleskem) a zvukovým jevem (hřmením)."
  },
  {
    question: "Co je to 'sekundární účinek blesku'?",
    options: ["Druhý blesk v řadě", "Indukce přepětí v kabelech způsobená blízkým úderem blesku", "Déšť po bouřce", "Mokré zdi"],
    correctAnswer: 1,
    explanation: "I když blesk neudeří přímo do vás, jeho magnetické pole může zničit elektroniku v okruhu stovek metrů."
  },
  {
    question: "Jak poznáte vzdálenost bouřky?",
    options: ["Podle barvy blesku", "Počítáním sekund mezi bleskem a hřměním (3 s = cca 1 km)", "Podle síly větru", "Pohledem na hodinky"],
    correctAnswer: 1,
    explanation: "Zvuk šíří cca 340 m/s. 3 sekundy rozdílu tedy znamenají vzdálenost zhruba 1 kilometr."
  },
  {
    question: "Lze použít hliník jako zemnič v hlíně?",
    options: ["Ano, je lehký", "Ne, hliník v zemi velmi rychle koroduje a rozpadá se", "Jen pokud je natřený na modro", "Pouze v písku"],
    correctAnswer: 1,
    explanation: "Hliník (Al) je pro přímý styk s půdou nevhodný kvůli elektrochemické korozi."
  },
  {
    question: "K čemu slouží svodič bleskových proudů?",
    options: ["K přivolání blesku", "K bezpečnému svedení bleskové energie z napájecích vodičů do uzemnění", "K nabíjení baterií bleskem", "K ochraně před průvanem"],
    correctAnswer: 1,
    explanation: "SPD omezují napětí na bezpečnou úroveň, kterou spotřebiče vydrží."
  },
  {
    question: "Kolik svodů musí mít minimálně budova s obvodem nad 50 metrů (LPS III)?",
    options: ["1", "minimálně jeden na každých 15 metrů obvodu (typicky 4 a více)", "100", "0"],
    correctAnswer: 1,
    explanation: "Norma určuje počet svodů podle třídy ochrany a obvodu budovy (LPS III = á 15 metrů)."
  },
  {
    question: "Proč se hromosvod lakuje nebo používá FeZn?",
    options: ["Kvůli barvě", "Ochrana proti korozi a prodloužení životnosti", "Aby blesk neklouzal", "Je to levnější než plast"],
    correctAnswer: 1,
    explanation: "Vnější vlivy (déšť, smog) by nechráněné železo zničily rzí během pár let."
  },
  {
    question: "Může být auto bezpečný úkryt při bouřce?",
    options: ["Ne, pneumatiky hoří", "Ano, funguje jako Faradayova klec (pokud má kovovou střechu)", "Jen pokud máte otevřená okna", "Pouze verze s plátěnou střechou"],
    correctAnswer: 1,
    explanation: "Kovová karoserie svede výboj po povrchu do země. Nedotýkejte se kovových částí uvnitř."
  },
  {
    question: "Co je to 'blesková koule' (metoda valivé koule)?",
    options: ["Speciální zbraň", "Geometrický model pro návrh ochranného prostoru jímačů", "Kulový blesk", "Hračka pro děti"],
    correctAnswer: 1,
    explanation: "Pomyslná koule se 'valí' po objektu; místa, kterých se nedotkne, jsou chráněna před přímým úderem."
  },
  {
    question: "Jaký je průřez běžného FeZn drátu na svod hromosvodu?",
    options: ["1 mm²", "cca 50 mm² (průměr 8 mm)", "500 mm²", "0,1 mm"],
    correctAnswer: 1,
    explanation: "Drát o průměru 8 mm má plochu průřezu cca 50 mm², což bezpečně přenese bleskový proud."
  },
  {
    question: "Který spotřebič je nejcitlivější na přepětí?",
    options: ["Žehlička", "Počítač / Router", "Stará žárovka", "Litinová kamna"],
    correctAnswer: 1,
    explanation: "Elektronika (čipy) pracuje s nízkým napětím a pár stovek voltů navíc ji okamžitě prorazí."
  },
  {
    question: "Co značí písmeno 's' ve výpočtu hromosvodu?",
    options: ["Rychlost (speed)", "Dostatečná vzdálenost (separation distance)", "Čas (seconds)", "Plocha (square)"],
    correctAnswer: 1,
    explanation: "V normě 62305 's' označuje kritickou vzdálenost k zabránění přeskokům."
  },
  {
    question: "Jsou revize hromosvodu povinné ze zákona (u firem/SVJ)?",
    options: ["Ne, jsou dobrovolné", "Ano, vyplývá to ze zákoníku práce a požárních předpisů", "Jen v Praze", "Pouze u výškových budov"],
    correctAnswer: 1,
    explanation: "Provozovatel objektu je povinen udržovat technická zařízení v bezpečném stavu, což revize dokládají."
  },
  {
    question: "Může blesk zničit dům s hromosvodem?",
    options: ["Ne, hromosvod je 100% jistota", "Ano, pokud je špatně navržen, proveden nebo zanedbán", "Pouze pokud blesk hodí bůh Zeus", "Jen v noci"],
    correctAnswer: 1,
    explanation: "Hromosvod snižuje riziko, ale při špatném projektu (chybějící SPD, nedostatečné uzemnění) k poškození dojít může."
  },
  {
    question: "Co se doporučuje u citlivé elektroniky během bouřky?",
    options: ["Zapnout více programů", "Fyzicky vytáhnout zástrčku ze zásuvky", "Zakrýt ji dekou", "Dát ji do lednice"],
    correctAnswer: 1,
    explanation: "Fyzické odpojení je nejjistější ochrana, SPD prvky mají své limity."
  },
  {
    question: "Jak se upevňuje vodič hromosvodu ke křidlicové střeše?",
    options: ["Lepidlem na papír", "Drtiči blesků", "Podpěrami vedení (např. do hřebenáče nebo pod tašku)", "Nijak, leží tam volně"],
    correctAnswer: 2,
    explanation: "Existuje celá řada typizovaných podpěr, které drží drát v pevné a bezpečné poloze."
  },
  {
    question: "Proč se jímací tyče dávají ke komínům?",
    options: ["Aby komín lépe táhl", "Horké plyny a saze mají nižší elektrickou pevnost a blesk do komínu rád udeří", "Kvůli vymetání sazí", "Je to pro ozdobu"],
    correctAnswer: 1,
    explanation: "Ionizovaný vzduch z komína je vodivější, proto komín vyžaduje zvýšenou ochranu."
  },
  {
    question: "Co je to 'izolovaný LPS'?",
    options: ["Hromosvod v gumovém obalu", "Systém, kde se jímací soustava nedotýká chráněného objektu (stožáry)", "Hromosvod bez uzemnění", "Nefunkční hromosvod"],
    correctAnswer: 1,
    explanation: "Používá se u speciálních objektů (výbušniny), aby případný výboj neprošel konstrukcí ani indukčně."
  },
  {
    question: "Jaký úkaz často předchází úderu blesku v horách (sršení)?",
    options: ["Zastavení času", "Eliášův oheň (doutnavý výboj na hrotech)", "Zelený záblesk", "Zpěv ptáků"],
    correctAnswer: 1,
    explanation: "Pokud cítíte brnění nebo vidíte modré světlo na hrotech, udeří blesk do pár sekund!"
  },
  {
    question: "Může hromosvod přitahovat blesky?",
    options: ["Ano, funguje jako magnet", "Ne, hromosvod blesk nepřitahuje z dálky, pouze mu dává cestu, jakmile se přiblíží", "Jen pokud je natřený na červeno", "Pouze v pondělí"],
    correctAnswer: 1,
    explanation: "Blesk si cestu 'vybírá' až v posledních desítkách metrů. Hromosvod pouze určí bezpečné místo dopadu."
  },
  {
    question: "Co je nejdůležitější vlastností elektrikáře při práci na hromosvodech?",
    options: ["Rychlý běh", "Znalost norem, pečlivost a certifikace", "Dobrá nálada", "Vlastní auto"],
    correctAnswer: 1,
    explanation: "Špatně zapojený hromosvod je horší než žádný. Odbornost a znalost ČSN EN 62305 je klíčová."
  }
];
