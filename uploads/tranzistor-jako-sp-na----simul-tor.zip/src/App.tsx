import React, { useState, useMemo } from 'react';
import { Power, Zap, AlertTriangle, Calculator, Info, ArrowRight, QrCode, X, CheckCircle2, HelpCircle, RefreshCcw } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, ReferenceDot } from 'recharts';

const QUIZ_QUESTIONS = [
  {
    question: "Kdy je tranzistor v režimu 'Hrazení' (vypnuto)?",
    options: [
      "Když je Vin větší než 0.7V",
      "Když je Vin menší než 0.7V",
      "Když je proud kolektoru maximální",
      "Když je odpor RL nulový"
    ],
    correct: 1,
    explanation: "Tranzistor NPN začíná vést až po překonání napětí PN přechodu báze-emitor, což je typicky 0.7V."
  },
  {
    question: "Jaký je hlavní účel odporu RB?",
    options: [
      "Zvyšuje napětí VCC",
      "Omezuje proud kolektoru IC",
      "Omezuje proud bází IB a chrání tranzistor",
      "Slouží jako zátěž obvodu"
    ],
    correct: 2,
    explanation: "Bez odporu RB by do báze tekl nekontrolovaný proud, který by mohl tranzistor zničit."
  },
  {
    question: "Co se stane s napětím VCE, když se tranzistor dostane do saturace?",
    options: [
      "Vzroste na hodnotu VCC",
      "Klesne k minimální hodnotě (cca 0.2V)",
      "Zůstane přesně na 0.7V",
      "Bude se rovnat napětí Vin"
    ],
    correct: 1,
    explanation: "V saturaci je tranzistor plně sepnut a chová se téměř jako ideální vodič s minimálním úbytkem napětí."
  },
  {
    question: "Jak ovlivní zvýšení odporu zátěže RL bod saturace?",
    options: [
      "Tranzistor saturuje dříve (při menším proudu báze)",
      "Tranzistor saturuje později (vyžaduje větší Vin)",
      "Zvýšení RL nemá na saturaci žádný vliv",
      "Tranzistor se v saturaci více zahřívá"
    ],
    correct: 0,
    explanation: "Vyšší RL omezuje maximální IC. Menší IC znamená, že k dosažení saturace stačí menší proud báze."
  },
  {
    question: "Proč je nebezpečné provozovat tranzistor jako spínač v lineární oblasti?",
    options: [
      "Protože tranzistor vůbec nevede proud",
      "Protože je napětí VCE příliš nízké",
      "Protože vzniká velký ztrátový výkon (teplo) na tranzistoru",
      "Protože se tím poškozuje zátěž RL"
    ],
    correct: 2,
    explanation: "V lineární oblasti je na tranzistoru současně napětí i proud, což vytváří teplo (P = UCE * IC). V saturaci je napětí minimální, v hrazení zase proud."
  },
  {
    question: "Jaký je vztah mezi proudy tranzistoru?",
    options: [
      "IE = IC + IB",
      "IC = IE + IB",
      "IB = IC + IE",
      "IE = IC * IB"
    ],
    correct: 0,
    explanation: "Proud emitoru je součtem proudu kolektoru a proudu báze (podle 1. Kirchhoffova zákona)."
  },
  {
    question: "Co označuje zkratka hFE (nebo beta)?",
    options: [
      "Vstupní odpor tranzistoru",
      "Stejnosměrný proudový zesilovací činitel",
      "Maximální napětí kolektoru",
      "Rychlost spínání tranzistoru"
    ],
    correct: 1,
    explanation: "hFE udává, kolikrát je proud kolektoru větší než proud báze v lineární oblasti."
  },
  {
    question: "Proč se používá dioda antiparalelně k indukční zátěži (např. relé)?",
    options: [
      "Aby se zvýšil proud zátěží",
      "Aby se tranzistor rychleji sepnul",
      "K ochraně tranzistoru před napěťovými špičkami při vypnutí",
      "K omezení proudu báze"
    ],
    correct: 2,
    explanation: "Při vypnutí indukční zátěže vzniká vysoké indukované napětí opačné polarity, které by mohlo prorazit tranzistor."
  },
  {
    question: "V jakém stavu se tranzistor chová jako rozpojený spínač?",
    options: [
      "V saturaci",
      "V lineární oblasti",
      "V režimu hrazení (cut-off)",
      "Při Vin = 5V"
    ],
    correct: 2,
    explanation: "V režimu hrazení neteče bází žádný proud, tranzistor je nevodivý a obvodem zátěže neprotéká proud."
  },
  {
    question: "Jaká je typická hodnota napětí VBE v saturaci u křemíkového tranzistoru?",
    options: [
      "0.2 V",
      "0.7 až 0.9 V",
      "12 V",
      "0 V"
    ],
    correct: 1,
    explanation: "Napětí mezi bází a emitorem je v sepnutém stavu dáno úbytkem na PN přechodu, což je cca 0.7V."
  },
  {
    question: "Co se stane, pokud budeme tranzistor v saturaci budit ještě větším proudem IB?",
    options: [
      "Proud IC se výrazně zvýší",
      "Napětí VCE klesne na nulu",
      "Proud IC se již téměř nezmění (zůstane na maximu)",
      "Tranzistor se okamžitě vypne"
    ],
    correct: 2,
    explanation: "V saturaci je IC limitován odporem zátěže a napětím VCC. Další zvyšování IB už IC nezvýší."
  },
  {
    question: "Jaká je hlavní výhoda tranzistoru oproti mechanickému spínači?",
    options: [
      "Větší rozměry",
      "Vysoká rychlost spínání a absence pohyblivých částí",
      "Nulový úbytek napětí v sepnutém stavu",
      "Jednodušší zapojení bez odporů"
    ],
    correct: 1,
    explanation: "Tranzistory mohou spínat milionykrát za sekundu a neopotřebovávají se mechanicky."
  },
  {
    question: "Co znamená označení NPN?",
    options: [
      "Napětí-Proud-Napětí",
      "Struktura polovodičů: Negativní-Pozitivní-Negativní",
      "Název výrobce tranzistoru",
      "Nízký-Průměrný-Nízký zisk"
    ],
    correct: 1,
    explanation: "Označuje vrstvy polovodiče typu N (kolektor), P (báze) a N (emitor)."
  },
  {
    question: "Který vývod tranzistoru je v zapojení se společným emitorem připojen na GND (u NPN)?",
    options: [
      "Báze",
      "Kolektor",
      "Emitor",
      "Žádný"
    ],
    correct: 2,
    explanation: "V základním zapojení NPN spínače je emitor připojen přímo na záporný pól (GND)."
  },
  {
    question: "Jaký je ztrátový výkon na tranzistoru v ideálním stavu saturace?",
    options: [
      "Maximální možný",
      "Velmi malý (díky nízkému VCE)",
      "Nulový",
      "Stejný jako na zátěži"
    ],
    correct: 1,
    explanation: "Protože P = U * I a napětí VCE je v saturaci velmi malé (cca 0.2V), je i ztrátový výkon relativně nízký."
  },
  {
    question: "Co se stane s proudem IC, pokud se přeruší přívod do báze?",
    options: [
      "IC se zvýší na maximum",
      "IC klesne na nulu (tranzistor zavře)",
      "IC zůstane stejný",
      "Tranzistor se zničí"
    ],
    correct: 1,
    explanation: "Bez proudu báze tranzistor nevede, tedy IC zanikne."
  },
  {
    question: "Jak ovlivňuje teplota proudový zisk hFE?",
    options: [
      "Zisk se s teplotou nemění",
      "Zisk se s rostoucí teplotou obvykle zvyšuje",
      "Zisk s teplotou klesá k nule",
      "Teplota ovlivňuje pouze napětí VCC"
    ],
    correct: 1,
    explanation: "U většiny bipolárních tranzistorů proudový zisk s teplotou mírně roste, což může vést k tepelné nestabilitě."
  },
  {
    question: "K čemu slouží chladič u výkonových tranzistorů?",
    options: [
      "Ke zvýšení napětí Vin",
      "K odvodu tepla vznikajícího ztrátovým výkonem",
      "Ke snížení odporu RL",
      "K dekoraci obvodu"
    ],
    correct: 1,
    explanation: "Při spínání velkých proudů vzniká teplo, které je nutné odvést, aby nedošlo k tepelnému zničení přechodů."
  },
  {
    question: "Jaký je rozdíl mezi bipolárním tranzistorem (BJT) a MOSFETem z hlediska řízení?",
    options: [
      "Žádný, oba se řídí proudem",
      "BJT se řídí proudem, MOSFET napětím",
      "BJT se řídí napětím, MOSFET proudem",
      "Oba se řídí pouze mechanicky"
    ],
    correct: 1,
    explanation: "U BJT řídíme proud kolektoru proudem báze, u MOSFETu řídíme proud kanálem pomocí napětí na hradle (Gate)."
  },
  {
    question: "Co se stane, pokud je odpor RB příliš velký?",
    options: [
      "Tranzistor se zničí velkým proudem",
      "Tranzistor se nemusí plně otevřít (nedosáhne saturace)",
      "Zvýší se napětí VCC",
      "Zátěž RL shoří"
    ],
    correct: 1,
    explanation: "Velký RB omezí proud báze natolik, že IC nedosáhne svého maxima a tranzistor zůstane v lineární oblasti."
  }
];

const App = () => {
  const [vin, setVin] = useState(0);
  const [vcc, setVcc] = useState(12);
  const [rBase, setRBase] = useState(1000);
  const [rLoad, setRLoad] = useState(100);
  const [hfe, setHfe] = useState(100);
  const [showQR, setShowQR] = useState(false);

  // Quiz state
  const [quizStarted, setQuizStarted] = useState(false);
  const [activeQuestions, setActiveQuestions] = useState<typeof QUIZ_QUESTIONS>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [quizFinished, setQuizFinished] = useState(false);

  // Vypočtené hodnoty pro simulaci
  const iBase = Math.max(0, (vin - 0.7) / rBase);
  const iCollectorIdeal = iBase * hfe;
  const iCollectorMax = vcc / rLoad;
  const iCollectorActual = Math.min(iCollectorIdeal, iCollectorMax);
  const vCe = Math.max(0.2, vcc - (iCollectorActual * rLoad));

  // Data pro graf VCE vs RL
  const chartData = useMemo(() => {
    const data = [];
    for (let rl = 10; rl <= 1000; rl += 10) {
      const icMax = vcc / rl;
      const icActual = Math.min(iCollectorIdeal, icMax);
      const vceVal = Math.max(0.2, vcc - (icActual * rl));
      data.push({ rl, vce: parseFloat(vceVal.toFixed(2)) });
    }
    return data;
  }, [vcc, iCollectorIdeal]);

  // Určení pracovního stavu
  let status = "Hrazení (Vypnuto)";
  let statusColor = "bg-gray-100 text-gray-800 border-gray-400";
  let ledOpacity = 0.1;

  if (vin > 0.7) {
    if (iCollectorIdeal >= iCollectorMax) {
      status = "Saturace (Plně sepnuto)";
      statusColor = "bg-green-100 text-green-800 border-green-400";
      ledOpacity = 1;
    } else {
      status = "Lineární oblast (Zesilování)";
      statusColor = "bg-yellow-100 text-yellow-800 border-yellow-400";
      ledOpacity = iCollectorActual / iCollectorMax;
    }
  }

  const handleAnswer = (index: number) => {
    if (showFeedback) return;
    setSelectedOption(index);
    setShowFeedback(true);
    if (index === activeQuestions[currentQuestion].correct) {
      setScore(score + 1);
    }
  };

  const nextQuestion = () => {
    if (currentQuestion < activeQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setShowFeedback(false);
      setSelectedOption(null);
    } else {
      setQuizFinished(true);
    }
  };

  const startQuiz = () => {
    const shuffled = [...QUIZ_QUESTIONS].sort(() => 0.5 - Math.random());
    setActiveQuestions(shuffled.slice(0, 5));
    setQuizStarted(true);
  };

  const resetQuiz = () => {
    setQuizStarted(false);
    setCurrentQuestion(0);
    setScore(0);
    setShowFeedback(false);
    setSelectedOption(null);
    setQuizFinished(false);
    setActiveQuestions([]);
  };

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans text-slate-900">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Záhlaví aplikace */}
        <header className="bg-blue-800 text-white p-5 rounded-2xl shadow-xl border-b-4 border-blue-900">
          <div className="flex justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <Zap className="fill-yellow-400 text-yellow-400 shrink-0" size={32} />
              <div>
                <h1 className="text-xl md:text-3xl font-bold tracking-tight">Tranzistor jako spínač</h1>
                <p className="hidden sm:block text-blue-200 text-xs mt-0.5 font-medium">Interaktivní simulátor pro výuku</p>
              </div>
            </div>
            
            <div className="relative">
              <button 
                onClick={() => setShowQR(!showQR)}
                className="flex items-center gap-2 bg-white/10 hover:bg-white/20 transition-colors p-2 md:px-4 md:py-2 rounded-xl border border-white/20 group"
                title="QR kód pro studenty"
              >
                <QrCode size={20} className="text-white group-hover:scale-110 transition-transform" />
                <span className="text-xs font-bold hidden md:inline">SDÍLET</span>
              </button>

              {/* QR Modal Dropdown */}
              {showQR && (
                <div className="absolute top-full right-0 mt-3 p-4 bg-white rounded-2xl shadow-2xl z-50 border border-slate-200 w-64 animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="flex justify-between items-center mb-3">
                    <p className="text-slate-800 text-[10px] font-bold uppercase tracking-wider">Naskenujte mobilem</p>
                    <button onClick={() => setShowQR(false)} className="text-slate-400 hover:text-slate-600">
                      <X size={16} />
                    </button>
                  </div>
                  <div className="bg-slate-50 aspect-square rounded-xl flex items-center justify-center p-3 border border-slate-100">
                    <QrCode size={160} className="text-slate-900" />
                  </div>
                  <p className="text-[10px] text-slate-500 mt-3 text-center italic">Otevře simulaci v mobilu studenta</p>
                </div>
              )}
            </div>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Schéma a ovládání */}
          <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2 text-slate-700">
              <Power className="text-blue-600" size={20} /> Schéma zapojení
            </h2>
            
            <div className="relative h-64 bg-slate-50 rounded-xl border border-dashed border-slate-300 flex items-center justify-center mb-6 overflow-hidden">
              <svg viewBox="0 0 400 300" className="w-full h-full max-w-[300px]">
                {/* VCC */}
                <line x1="200" y1="20" x2="200" y2="50" stroke="#334155" strokeWidth="2" />
                <text x="180" y="15" className="text-[10px] font-bold fill-red-600 uppercase">VCC (+{vcc}V)</text>
                
                {/* Zátěž RL */}
                <rect x="185" y="50" width="30" height="40" fill={status === "Saturace (Plně sepnuto)" ? "#fbbf24" : "#cbd5e1"} stroke="#334155" strokeWidth="2" />
                <text x="225" y="75" className="text-[10px] fill-slate-500">RL ({rLoad}Ω)</text>

                {/* Tranzistor */}
                <circle cx="200" cy="150" r="40" fill="none" stroke="#334155" strokeWidth="2" />
                <line x1="180" y1="130" x2="180" y2="170" stroke="#334155" strokeWidth="4" />
                <line x1="180" y1="150" x2="140" y2="150" stroke="#334155" strokeWidth="2" /> 
                <line x1="180" y1="140" x2="200" y2="110" stroke="#334155" strokeWidth="2" /> 
                <line x1="200" y1="110" x2="200" y2="90" stroke="#334155" strokeWidth="2" />
                
                <line x1="180" y1="160" x2="200" y2="190" stroke="#334155" strokeWidth="2" /> 
                <polygon points="200,190 190,185 195,180" fill="#334155" /> 
                <line x1="200" y1="190" x2="200" y2="230" stroke="#334155" strokeWidth="2" />
                
                {/* GND */}
                <line x1="180" y1="230" x2="220" y2="230" stroke="#334155" strokeWidth="2" />
                <line x1="185" y1="235" x2="215" y2="235" stroke="#334155" strokeWidth="2" />
                <line x1="192" y1="240" x2="208" y2="240" stroke="#334155" strokeWidth="2" />
                
                {/* Popisky */}
                <text x="125" y="145" className="text-[10px] font-bold fill-blue-600">B</text>
                <text x="205" y="105" className="text-[10px] font-bold fill-blue-600">C</text>
                <text x="205" y="205" className="text-[10px] font-bold fill-blue-600">E</text>

                {/* RB */}
                <rect x="80" y="140" width="40" height="20" fill="white" stroke="#334155" strokeWidth="2" />
                <text x="85" y="135" className="text-[10px] fill-slate-500">RB</text>
                <line x1="80" y1="150" x2="40" y2="150" stroke="#334155" strokeWidth="2" />
                <text x="10" y="155" className="text-xs font-bold fill-blue-600 uppercase">Vin</text>
              </svg>

              {/* Efekt světla */}
              <div 
                className="absolute top-12 left-1/2 -translate-x-1/2 w-20 h-20 rounded-full bg-yellow-400 blur-3xl transition-opacity duration-300 pointer-events-none"
                style={{ opacity: ledOpacity * 0.5 }}
              />
            </div>

            <div className="space-y-4">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                <div className="flex justify-between items-center mb-3">
                  <label className="text-sm font-bold text-slate-600 uppercase tracking-tight">Vstupní napětí (Vin)</label>
                  <span className="bg-blue-600 text-white px-3 py-1 rounded-lg font-mono font-bold text-sm shadow-sm">{vin.toFixed(1)} V</span>
                </div>
                <input 
                  type="range" min="0" max="12" step="0.1" 
                  value={vin} onChange={(e) => setVin(parseFloat(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
              </div>
              
              <div className={`p-4 rounded-xl border-2 text-center font-bold shadow-sm transition-all text-sm uppercase tracking-wide ${statusColor}`}>
                {status}
              </div>
            </div>
          </div>

          {/* Naměřené hodnoty */}
          <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200 flex flex-col">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2 text-slate-700">
              <Calculator className="text-blue-600" size={20} /> Technické parametry
            </h2>
            
            <div className="grid grid-cols-2 gap-3 mb-6">
              <div className="p-4 bg-blue-50/50 rounded-xl border border-blue-100 relative overflow-hidden">
                <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Proud bází (IB)</p>
                <p className="text-xl font-mono font-bold text-blue-700">{(iBase * 1000).toFixed(2)} <span className="text-xs">mA</span></p>
                <p className="text-[9px] text-blue-400 mt-1 font-medium italic">IB = (Vin - 0.7) / RB</p>
              </div>
              <div className="p-4 bg-blue-50/50 rounded-xl border border-blue-100">
                <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Proud IC</p>
                <p className="text-xl font-mono font-bold text-blue-700">{(iCollectorActual * 1000).toFixed(1)} <span className="text-xs">mA</span></p>
                <div className="mt-1 space-y-0.5">
                  <p className="text-[9px] text-blue-400 font-medium italic">IC = IB × hFE</p>
                  <p className="text-[9px] text-slate-500 font-bold uppercase">Max: {(iCollectorMax * 1000).toFixed(1)} mA</p>
                  <p className="text-[8px] text-slate-400 italic leading-tight">Limit: VCC / RL</p>
                </div>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Napětí VCE</p>
                <p className="text-xl font-mono font-bold text-slate-700">{vCe.toFixed(2)} <span className="text-xs">V</span></p>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Napájecí VCC</p>
                <p className="text-xl font-mono font-bold text-slate-700">{vcc.toFixed(1)} <span className="text-xs">V</span></p>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 col-span-2">
                <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Zesílení (hFE)</p>
                <p className="text-xl font-mono font-bold text-slate-700">{hfe}</p>
              </div>
            </div>

            {/* Interaktivní graf VCE vs RL */}
            <div className="flex-grow bg-slate-50 rounded-xl border border-slate-100 p-4 relative">
              <p className="text-[10px] font-bold text-slate-400 uppercase mb-4 text-center">Závislost VCE na RL (kliknutím změníte RL)</p>
              <div className="h-48 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart 
                    data={chartData} 
                    onClick={(data) => {
                      if (data && data.activePayload) {
                        setRLoad(data.activePayload[0].payload.rl);
                      }
                    }}
                    margin={{ top: 5, right: 5, left: -20, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis 
                      dataKey="rl" 
                      hide 
                    />
                    <YAxis 
                      domain={[0, 12]} 
                      tick={{ fontSize: 10, fill: '#94a3b8' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip 
                      contentStyle={{ fontSize: '10px', borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                      labelFormatter={(value) => `RL: ${value} Ω`}
                      formatter={(value: number) => [`${value} V`, 'VCE']}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="vce" 
                      stroke="#2563eb" 
                      strokeWidth={2} 
                      dot={false} 
                      activeDot={{ r: 4, fill: '#2563eb' }}
                      isAnimationActive={false}
                    />
                    <ReferenceLine x={rLoad} stroke="#ef4444" strokeDasharray="3 3" label={{ position: 'top', value: `RL=${rLoad}Ω`, fill: '#ef4444', fontSize: 10, fontWeight: 'bold' }} />
                    <ReferenceLine y={vCe} stroke="#ef4444" strokeDasharray="3 3" label={{ position: 'insideRight', value: `VCE=${vCe.toFixed(2)}V`, fill: '#ef4444', fontSize: 10, fontWeight: 'bold', offset: 10 }} />
                    <ReferenceDot x={rLoad} y={vCe} r={4} fill="#ef4444" stroke="none" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-between mt-2 px-2">
                <span className="text-[9px] text-slate-400 font-bold uppercase">10 Ω</span>
                <span className="text-[9px] text-slate-400 font-bold uppercase">Odpor zátěže (RL)</span>
                <span className="text-[9px] text-slate-400 font-bold uppercase">1000 Ω</span>
              </div>
              
              <div className="mt-4 p-3 bg-blue-50/30 rounded-lg border border-blue-100/50">
                <p className="text-[10px] text-slate-600 leading-relaxed">
                  <strong>Vliv RL:</strong> Odpor zátěže určuje maximální možný proud kolektoru <span className="font-mono text-blue-700">IC,max = VCC / RL</span>. 
                  Čím je <strong>RL vyšší</strong>, tím menší proud stačí k tomu, aby se tranzistor plně sepnul (dosáhl saturace). 
                  Naopak při <strong>nízkém RL</strong> protéká zátěž velký proud a tranzistor vyžaduje mnohem silnější buzení bází, aby napětí <span className="font-mono text-blue-700">VCE</span> kleslo k nule.
                </p>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-slate-100 space-y-4">
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Konfigurace komponent</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center bg-slate-50 p-2 px-3 rounded-lg border border-slate-100" title="RB omezuje proud IB">
                  <div className="flex flex-col">
                    <div className="flex items-center gap-1">
                      <span className="text-xs font-semibold text-slate-600">Odpor RB (báze)</span>
                      <Info size={12} className="text-slate-400 cursor-help" />
                    </div>
                    <span className="text-[9px] text-slate-400 font-medium italic">Omezuje proud IB</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" value={rBase} onChange={(e) => setRBase(Number(e.target.value))}
                      className="w-20 p-1 border border-slate-200 rounded text-right font-mono text-sm bg-white"
                    /> <span className="text-xs text-slate-400 font-bold">Ω</span>
                  </div>
                </div>
                <div className="flex justify-between items-center bg-slate-50 p-2 px-3 rounded-lg border border-slate-100">
                  <span className="text-xs font-semibold text-slate-600">Napětí VCC (zdroj)</span>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" value={vcc} onChange={(e) => setVcc(Number(e.target.value))}
                      className="w-20 p-1 border border-slate-200 rounded text-right font-mono text-sm bg-white"
                    /> <span className="text-xs text-slate-400 font-bold">V</span>
                  </div>
                </div>
                <div className="flex justify-between items-center bg-slate-50 p-2 px-3 rounded-lg border border-slate-100">
                  <span className="text-xs font-semibold text-slate-600">Odpor RL (zátěž)</span>
                  <div className="flex items-center gap-2">
                    <input 
                      type="number" value={rLoad} onChange={(e) => setRLoad(Number(e.target.value))}
                      className="w-20 p-1 border border-slate-200 rounded text-right font-mono text-sm bg-white"
                    /> <span className="text-xs text-slate-400 font-bold">Ω</span>
                  </div>
                </div>
                <div className="flex justify-between items-center bg-slate-50 p-2 px-3 rounded-lg border border-slate-100">
                  <span className="text-xs font-semibold text-slate-600">Beta zesílení (hFE)</span>
                  <input 
                    type="number" value={hfe} onChange={(e) => setHfe(Number(e.target.value))}
                    className="w-20 p-1 border border-slate-200 rounded text-right font-mono text-sm bg-white"
                  />
                </div>
              </div>
              <p className="text-[10px] text-slate-400 italic leading-tight">
                * Změna RL ovlivňuje maximální proud kolektoru a tím i bod, kdy tranzistor přechází do saturace (VCE ≈ 0.2V).
              </p>
            </div>
          </div>
        </div>

        {/* Info panel */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-md border border-slate-200">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-slate-800">
              <Info className="text-blue-600" size={18} /> Metodika pro výuku
            </h2>
            <div className="text-sm text-slate-600 space-y-4 leading-relaxed">
              <p>
                Cílem spínacího režimu je, aby na tranzistoru byl v sepnutém stavu co nejmenší úbytek napětí. 
                Tím se minimalizuje ztrátový výkon <strong>P = UCE × IC</strong> a tranzistor se nehřeje.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 bg-blue-50/50 rounded-lg border border-blue-100">
                  <p className="font-bold text-blue-800 text-xs uppercase mb-1 flex items-center gap-1"><ArrowRight size={12} /> Uzavření</p>
                  <p className="text-xs italic">{'Vin < 0.7V. Tranzistor nevede. Zátěž je bez proudu.'}</p>
                </div>
                <div className="p-3 bg-green-50/50 rounded-lg border border-green-100">
                  <p className="font-bold text-green-800 text-xs uppercase mb-1 flex items-center gap-1"><ArrowRight size={12} /> Saturace</p>
                  <p className="text-xs italic">Báze je "přeplněna" proudem. Tranzistor je plně vodivý.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-orange-50 p-6 rounded-2xl shadow-md border border-orange-200">
            <h2 className="text-md font-bold mb-4 flex items-center gap-2 text-orange-800 uppercase tracking-tight">
              <AlertTriangle className="text-orange-600" size={18} /> Bezpečnost
            </h2>
            <ul className="text-xs space-y-3 text-orange-900 font-medium">
              <li className="flex gap-2">
                <span className="text-orange-500">•</span>
                <span><strong>Žádná báze "na přímo":</strong> Vždy použijte bázový odpor RB k omezení proudu.</span>
              </li>
              <li className="flex gap-2">
                <span className="text-orange-500">•</span>
                <span><strong>Teplo v lineární oblasti:</strong> Pokud tranzistor není v saturaci, hrozí tepelný průraz.</span>
              </li>
              <li className="flex gap-2">
                <span className="text-orange-500">•</span>
                <span><strong>Indukční špičky:</strong> Při spínání cívek je nutná dioda antiparalelně k zátěži.</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Quiz Section */}
        <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold flex items-center gap-2 text-slate-800">
              <HelpCircle className="text-blue-600" size={24} /> Test znalostí
            </h2>
            {quizStarted && !quizFinished && (
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                Otázka {currentQuestion + 1} z {activeQuestions.length}
              </span>
            )}
          </div>

          {!quizStarted ? (
            <div className="text-center py-8 space-y-4">
              <div className="bg-blue-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <HelpCircle className="text-blue-600" size={32} />
              </div>
              <h3 className="text-lg font-bold text-slate-800">Jste připraveni na test?</h3>
              <p className="text-sm text-slate-500 max-w-md mx-auto">
                Prověřte své znalosti o tranzistoru v režimu spínače. Test obsahuje 5 náhodně vybraných otázek z celkového fondu 20 otázek.
              </p>
              <button 
                onClick={startQuiz}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-xl font-bold transition-all shadow-lg hover:shadow-blue-200"
              >
                Spustit test
              </button>
            </div>
          ) : quizFinished ? (
            <div className="text-center py-8 space-y-6">
              <div className="bg-green-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="text-green-600" size={48} />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-slate-800">Test dokončen!</h3>
                <p className="text-slate-500 mt-2">Vaše skóre je:</p>
                <div className="text-5xl font-black text-blue-600 mt-2">{score} / {activeQuestions.length}</div>
              </div>
              <p className="text-sm text-slate-500 max-w-md mx-auto italic">
                {score === activeQuestions.length 
                  ? "Gratulujeme! Jste expertem na tranzistorové spínače." 
                  : score >= 3 
                  ? "Dobrá práce! Máte solidní základy, ale některé detaily by stálo za to zopakovat." 
                  : "Zkuste si simulaci ještě jednou projít a sledovat, jak se mění parametry při saturaci."}
              </p>
              <button 
                onClick={resetQuiz}
                className="flex items-center gap-2 mx-auto bg-slate-100 hover:bg-slate-200 text-slate-700 px-6 py-2 rounded-xl font-bold transition-all"
              >
                <RefreshCcw size={18} /> Zkusit znovu
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              <h3 className="text-lg font-bold text-slate-800 leading-tight">
                {activeQuestions[currentQuestion].question}
              </h3>
              
              <div className="grid grid-cols-1 gap-3">
                {activeQuestions[currentQuestion].options.map((option, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleAnswer(idx)}
                    disabled={showFeedback}
                    className={`p-4 text-left rounded-xl border-2 transition-all text-sm font-medium ${
                      showFeedback
                        ? idx === activeQuestions[currentQuestion].correct
                          ? "bg-green-50 border-green-500 text-green-800"
                          : idx === selectedOption
                          ? "bg-red-50 border-red-500 text-red-800"
                          : "bg-white border-slate-100 text-slate-400"
                        : "bg-white border-slate-200 hover:border-blue-400 hover:bg-blue-50/30 text-slate-700"
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span>{option}</span>
                      {showFeedback && idx === activeQuestions[currentQuestion].correct && (
                        <CheckCircle2 size={18} className="text-green-600" />
                      )}
                    </div>
                  </button>
                ))}
              </div>

              {showFeedback && (
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 animate-in fade-in slide-in-from-bottom-2 duration-300">
                  <p className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">Vysvětlení</p>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {activeQuestions[currentQuestion].explanation}
                  </p>
                  <button 
                    onClick={nextQuestion}
                    className="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2"
                  >
                    {currentQuestion === activeQuestions.length - 1 ? "Dokončit test" : "Další otázka"} <ArrowRight size={18} />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default App;
