/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Zap, 
  AlertTriangle, 
  Info, 
  Calculator, 
  BookOpen, 
  Ruler, 
  ShieldCheck, 
  Thermometer, 
  GraduationCap, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  Share2, 
  X,
  Trash2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';

const standardSizes = [1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120];

const App = () => {
  const [tab, setTab] = useState('calc');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  
  // Chart material choice
  const [chartMaterial, setChartMaterial] = useState('cu');
  
  // States for Calculator
  const [calcMode, setCalcMode] = useState('section'); // section, capacity
  const [selectedNorm, setSelectedNorm] = useState('5-52'); // 5-52, 2130
  const [power, setPower] = useState(3680);
  const [voltage, setVoltage] = useState(230);
  const [length, setLength] = useState(20);
  const [material, setMaterial] = useState('cu');
  const [phases, setPhases] = useState(1);
  const [maxDrop, setMaxDrop] = useState(3);
  const [cosPhi, setCosPhi] = useState(1);
  const [ambientTemp, setAmbientTemp] = useState(30);
  const [groupCount, setGroupCount] = useState(1);
  const [selectedSection, setSelectedSection] = useState(2.5);

  const [results, setResults] = useState({
    current: 0,
    section: 0,
    standardSection: 0,
    actualDrop: 0,
    resistance: 0,
    iz: 0,
    iz_adj: 0
  });

  // Basic current capacity table (Method C - on wall/in plaster) simplified for CSV
  // Key: section_mm2, Value: [Cu_Amps, Al_Amps]
  const capacityTable: { [key: number]: [number, number] } = {
    1.5: [19.5, 15],
    2.5: [27, 21],
    4: [36, 28],
    6: [46, 36],
    10: [63, 49],
    16: [85, 66],
    25: [112, 83],
    35: [138, 103],
    50: [168, 125],
    70: [213, 158],
    95: [258, 192],
    120: [299, 222]
  };

  // Temperature correction factors (simplified)
  const getTempFactor = (temp: number) => {
    if (temp <= 20) return 1.12;
    if (temp <= 25) return 1.06;
    if (temp <= 30) return 1.00;
    if (temp <= 35) return 0.94;
    if (temp <= 40) return 0.87;
    if (temp <= 45) return 0.79;
    if (temp <= 50) return 0.71;
    return 0.5;
  };

  // Grouping correction factors (simplified)
  const getGroupFactor = (count: number) => {
    if (count === 1) return 1.00;
    if (count === 2) return 0.80;
    if (count === 3) return 0.70;
    if (count === 4) return 0.65;
    if (count <= 6) return 0.57;
    if (count <= 9) return 0.50;
    return 0.45;
  };

  const [history, setHistory] = useState<any[]>([]);

  const saveToHistory = () => {
    const newItem = {
      id: Date.now().toString(),
      power,
      voltage,
      length,
      material,
      phases,
      maxDrop,
      cosPhi,
      calcMode,
      standardSection: calcMode === 'section' ? results.standardSection : selectedSection,
      timestamp: Date.now()
    };
    setHistory(prev => [newItem, ...prev].slice(0, 10));
  };

  const clearHistory = () => {
    if (window.confirm('Opravdu chcete smazat celou historii výpočtů?')) {
      setHistory([]);
    }
  };

  const loadFromHistory = (item: any) => {
    setPower(item.power);
    setVoltage(item.voltage);
    setLength(item.length);
    setMaterial(item.material);
    setPhases(item.phases);
    setMaxDrop(item.maxDrop);
    setCosPhi(item.cosPhi || 1);
    if (item.calcMode) setCalcMode(item.calcMode);
  };

  // States for Test
  const [testState, setTestState] = useState('intro'); // intro, playing, finished
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedQuestions, setSelectedQuestions] = useState<any[]>([]);
  const [score, setScore] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);

  // Database of 50 tasks
  const testBank = useMemo(() => {
    const materials = ['cu', 'al'];
    const phaseOptions = [1, 3];
    const tasks = [];
    
    for (let i = 0; i < 50; i++) {
      const p = Math.floor(Math.random() * 20 + 1) * 500; // 500W to 10kW
      const l = Math.floor(Math.random() * 8 + 1) * 10; // 10m to 80m
      const m = materials[Math.floor(Math.random() * materials.length)];
      const ph = phaseOptions[Math.floor(Math.random() * phaseOptions.length)];
      const v = ph === 1 ? 230 : 400;
      const drop = 3; // Standard 3% for test
      
      const rho = m === 'cu' ? 0.0178 : 0.029;
      const IVal = ph === 1 ? p / v : p / (Math.sqrt(3) * v);
      const deltaU_max = (v * drop) / 100;
      const k = ph === 1 ? 2 : Math.sqrt(3);
      const S = (k * l * IVal * rho) / deltaU_max;
      const correctS = standardSizes.find(size => size >= S) || 120;

      tasks.push({
        id: i,
        power: p,
        length: l,
        material: m,
        phases: ph,
        voltage: v,
        drop: drop,
        correctS: correctS
      });
    }
    return tasks;
  }, []);

  const startTest = () => {
    const shuffled = [...testBank].sort(() => 0.5 - Math.random());
    setSelectedQuestions(shuffled.slice(0, 10));
    setScore(0);
    setCurrentQuestionIdx(0);
    setTestState('playing');
    setFeedback(null);
    setUserAnswer('');
  };

  const handleAnswer = () => {
    const correct = parseFloat(userAnswer) === selectedQuestions[currentQuestionIdx].correctS;
    if (correct) setScore(s => s + 1);
    
    setFeedback(correct ? 'correct' : 'wrong');

    setTimeout(() => {
      if (currentQuestionIdx < 9) {
        setCurrentQuestionIdx(idx => idx + 1);
        setFeedback(null);
        setUserAnswer('');
      } else {
        setTestState('finished');
      }
    }, 1500);
  };

  // Calculator Logic
  const calculate = () => {
    const rho = material === 'cu' ? 0.0178 : 0.029; 
    let I = phases === 1 ? power / (voltage * cosPhi) : power / (Math.sqrt(3) * voltage * cosPhi);
    const deltaU_max = (voltage * maxDrop) / 100;
    const k = phases === 1 ? 2 : Math.sqrt(3);
    let S = (k * length * I * rho) / deltaU_max;
    const stdS = standardSizes.find(size => size >= S) || standardSizes[standardSizes.length - 1];
    const R = (k * length * rho) / stdS;
    const actualDeltaU = I * R;
    const actualDropPerc = (actualDeltaU / voltage) * 100;

    // Iz calculation
    const baseIz = capacityTable[selectedSection][material === 'cu' ? 0 : 1];
    const kt = getTempFactor(ambientTemp);
    const kg = getGroupFactor(groupCount);
    const adjustedIz = baseIz * kt * kg;

    setResults({
      current: I,
      section: S,
      standardSection: stdS,
      actualDrop: actualDropPerc,
      resistance: R,
      iz: baseIz,
      iz_adj: adjustedIz
    });
  };

  useEffect(() => {
    calculate();
  }, [power, voltage, length, material, phases, maxDrop, cosPhi, ambientTemp, groupCount, selectedSection]);

  // QR Code URL (using current window location)
  const appUrl = typeof window !== 'undefined' ? window.location.href : '';
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(appUrl)}`;

  const copyToClipboard = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(appUrl)
        .then(() => alert('Odkaz byl zkopírován!'))
        .catch(() => alert('Chyba při kopírování.'));
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans text-slate-800 relative">
      
      {/* Share Modal Overlay */}
      <AnimatePresence>
        {isShareModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" 
            onClick={() => setIsShareModalOpen(false)}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl p-8 max-w-sm w-full shadow-2xl text-center relative" 
              onClick={e => e.stopPropagation()}
            >
              <button 
                onClick={() => setIsShareModalOpen(false)} 
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors"
                id="close-share-modal"
              >
                <X size={24} />
              </button>
              <div className="bg-blue-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 text-blue-600">
                <Share2 size={32} />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">Sdílet aplikaci</h3>
              <p className="text-sm text-slate-500 mb-6">Naskenujte kód pro rychlé otevření v mobilu nebo tabletu.</p>
              
              <div className="bg-slate-50 p-4 rounded-2xl border-2 border-slate-100 inline-block mb-6 shadow-inner">
                <img 
                  src={qrCodeUrl} 
                  alt="QR kód aplikace" 
                  className="w-48 h-48" 
                  referrerPolicy="no-referrer"
                  onError={(e: any) => { e.target.src = 'https://via.placeholder.com/200?text=QR+Error'; }} 
                />
              </div>
              
              <button 
                onClick={copyToClipboard}
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2"
                id="copy-link-btn"
              >
                Kopírovat odkaz
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-5xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200">
        
        {/* Header */}
        <div className="bg-blue-700 p-6 text-white flex justify-between items-center">
          <div>
            <div className="flex items-center gap-3">
              <Zap className="w-8 h-8 fill-yellow-400 text-yellow-400" />
              <h1 className="text-2xl font-bold tracking-tight">Elektro-Průřez Master</h1>
            </div>
            <p className="text-blue-100 mt-1 opacity-90 text-sm">Interaktivní výuka dimenzování vodičů</p>
          </div>
          
          <div className="flex items-center gap-2">
            {tab === 'test' && testState === 'playing' && (
              <div className="bg-blue-800 px-4 py-2 rounded-lg font-bold border border-blue-600 shadow-inner mr-2 hidden md:block">
                Otázka {currentQuestionIdx + 1} / 10
              </div>
            )}
            <button 
              onClick={() => setIsShareModalOpen(true)}
              className="p-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all border border-white/20 group shadow-sm"
              title="Sdílet aplikaci"
              id="share-btn"
            >
              <Share2 size={20} className="group-hover:scale-110 transition-transform" />
            </button>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50">
          <button 
            onClick={() => setTab('calc')}
            className={`flex-1 py-4 px-2 flex items-center justify-center gap-2 font-semibold transition-all text-xs sm:text-sm ${tab === 'calc' ? 'text-blue-700 border-b-2 border-blue-700 bg-white' : 'text-slate-500 hover:bg-slate-100'}`}
          >
            <Calculator size={18} /> <span className="hidden sm:inline">Kalkulačka</span><span className="sm:hidden">Výpočet</span>
          </button>
          <button 
            onClick={() => setTab('test')}
            className={`flex-1 py-4 px-2 flex items-center justify-center gap-2 font-semibold transition-all text-xs sm:text-sm ${tab === 'test' ? 'text-blue-700 border-b-2 border-blue-700 bg-white' : 'text-slate-500 hover:bg-slate-100'}`}
          >
            <GraduationCap size={18} /> <span className="hidden sm:inline">Test znalostí</span><span className="sm:hidden">Test</span>
          </button>
          <button 
            onClick={() => setTab('theory')}
            className={`flex-1 py-4 px-2 flex items-center justify-center gap-2 font-semibold transition-all text-xs sm:text-sm ${tab === 'theory' ? 'text-blue-700 border-b-2 border-blue-700 bg-white' : 'text-slate-500 hover:bg-slate-100'}`}
          >
            <BookOpen size={18} /> <span className="hidden sm:inline">Teorie</span><span className="sm:hidden">Teorie</span>
          </button>
        </div>

        <div className="p-6">
          <AnimatePresence mode="wait">
            {tab === 'calc' && (
              <motion.div 
                key="calc"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <div className="flex bg-slate-100 p-1 rounded-xl mb-6 w-fit">
                  <button 
                    onClick={() => setCalcMode('section')} 
                    className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${calcMode === 'section' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                  >
                    Výpočet průřezu
                  </button>
                  <button 
                    onClick={() => setCalcMode('capacity')} 
                    className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${calcMode === 'capacity' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                  >
                    Zatížitelnost vodiče
                  </button>
                </div>

                <div className="grid md:grid-cols-2 gap-8">
                  {/* Controls */}
                  <div className="space-y-6">
                    <h2 className="text-lg font-bold flex items-center gap-2 text-slate-700 border-b pb-2">
                      <Ruler size={20} className="text-blue-500" /> Parametry {calcMode === 'section' ? 'vedení' : 'uložení'}
                    </h2>
                    
                    {calcMode === 'section' ? (
                      <>
                        <div className="space-y-2 mb-4">
                          <label className="text-xs font-bold text-slate-500 uppercase">Referenční norma</label>
                          <select 
                            value={selectedNorm} 
                            onChange={(e) => {
                              const norm = e.target.value;
                              setSelectedNorm(norm);
                              if (norm === '2130') setMaxDrop(2); // Often stricter for residential main lines
                              else setMaxDrop(3);
                            }} 
                            className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white shadow-sm text-sm font-bold text-blue-700"
                          >
                            <option value="5-52">ČSN 33 2000-5-52 ed.2 (Všeobecná)</option>
                            <option value="2130">ČSN 33 2130 (Bytové instalace)</option>
                          </select>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Výkon P (W)</label>
                            <input type="number" value={power} onChange={(e) => setPower(Number(e.target.value))} className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white shadow-sm" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Délka L (m)</label>
                            <input type="number" value={length} onChange={(e) => setLength(Number(e.target.value))} className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white shadow-sm" />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Napětí U (V)</label>
                            <select value={voltage} onChange={(e) => setVoltage(Number(e.target.value))} className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white shadow-sm">
                              <option value={230}>230 V (1f)</option>
                              <option value={400}>400 V (3f)</option>
                            </select>
                          </div>
                          <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Fáze</label>
                            <div className="flex gap-2">
                              {[1, 3].map(p => (
                                <button key={p} onClick={() => setPhases(p)} className={`flex-1 py-2 rounded-lg border font-bold transition-all ${phases === p ? 'bg-blue-600 text-white border-blue-600 shadow-md' : 'bg-white border-slate-300 text-slate-600'}`}>{p} f</button>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Materiál (ρ)</label>
                            <select value={material} onChange={(e) => setMaterial(e.target.value)} className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white shadow-sm">
                              <option value="cu">Měď (Cu)</option>
                              <option value="al">Hliník (Al)</option>
                            </select>
                          </div>
                          <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Úbytek ΔU (%)</label>
                            <input type="number" step="0.1" value={maxDrop} onChange={(e) => setMaxDrop(Number(e.target.value))} className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white shadow-sm" />
                          </div>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Průřez S (mm²)</label>
                            <select value={selectedSection} onChange={(e) => setSelectedSection(Number(e.target.value))} className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white shadow-sm">
                              {standardSizes.map(s => <option key={s} value={s}>{s} mm²</option>)}
                            </select>
                          </div>
                          <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Materiál (ρ)</label>
                            <select value={material} onChange={(e) => setMaterial(e.target.value)} className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white shadow-sm">
                              <option value="cu">Měď (Cu)</option>
                              <option value="al">Hliník (Al)</option>
                            </select>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Okolní teplota (°C)</label>
                            <input type="number" value={ambientTemp} onChange={(e) => setAmbientTemp(Number(e.target.value))} className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white shadow-sm" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-500 uppercase">Seskupení (obvody)</label>
                            <input type="number" min="1" max="20" value={groupCount} onChange={(e) => setGroupCount(Number(e.target.value))} className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white shadow-sm" />
                          </div>
                        </div>
                        <div className="p-4 bg-blue-50 rounded-xl border border-blue-100 space-y-2">
                          <div className="text-[10px] font-black text-blue-600 uppercase">Pro srovnání se spotřebičem:</div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1">
                              <label className="text-[9px] font-bold text-slate-500 uppercase">Příkon P (W)</label>
                              <input type="number" value={power} onChange={(e) => setPower(Number(e.target.value))} className="w-full p-1.5 border border-slate-200 rounded text-xs bg-white" />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[9px] font-bold text-slate-500 uppercase">Napětí U (V)</label>
                              <select value={voltage} onChange={(e) => setVoltage(Number(e.target.value))} className="w-full p-1.5 border border-slate-200 rounded text-xs bg-white">
                                <option value={230}>230 V</option>
                                <option value={400}>400 V</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>

                  {/* Result Card */}
                  <div className="flex flex-col gap-4">
                    <motion.div 
                      layout
                      className="bg-slate-900 text-white rounded-2xl p-6 flex flex-col justify-between shadow-2xl relative border-4 border-slate-800"
                    >
                      <div>
                        <h2 className="text-blue-400 text-[10px] font-black uppercase tracking-widest mb-4">Výstupy výpočtu</h2>
                        
                        {calcMode === 'section' ? (
                          <div className="space-y-4">
                            <div className="flex justify-between items-center bg-blue-100/10 p-2 rounded-lg border border-white/5">
                              <span className="text-[9px] text-slate-500 uppercase font-black">Aplikovaná norma:</span>
                              <span className="text-[9px] text-blue-400 font-bold">{selectedNorm === '5-52' ? 'ČSN 33 2000-5-52' : 'ČSN 33 2130'}</span>
                            </div>
                            <div>
                              <div className="text-slate-400 text-[10px] uppercase font-bold">Výpočtový proud (In)</div>
                              <div className="text-3xl font-mono font-bold text-white leading-none">{results.current.toFixed(2)} A</div>
                            </div>
                            <div className="pt-2 border-t border-slate-800">
                              <div className="text-yellow-400 text-xs font-black uppercase mb-1">Doporučený průřez</div>
                              <div className="text-5xl font-black text-white">{results.standardSection} <span className="text-xl text-slate-500 font-normal">mm²</span></div>
                            </div>
                            <motion.div 
                              animate={{ scale: [1, 1.02, 1] }}
                              className={`p-3 rounded-xl flex items-center gap-3 ${results.actualDrop > maxDrop ? 'bg-red-500/10 border border-red-500/50' : 'bg-green-500/10 border border-green-500/50'}`}
                            >
                              <div className={`text-xs font-bold ${results.actualDrop > maxDrop ? 'text-red-400' : 'text-green-400'}`}>Skutečný úbytek: {results.actualDrop.toFixed(2)} %</div>
                            </motion.div>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            <div>
                              <div className="text-slate-400 text-[10px] uppercase font-bold">{"Základní zatížitelnost ($I_{ref}$)"}</div>
                              <div className="text-2xl font-mono font-bold text-slate-300">{results.iz} A</div>
                            </div>
                            <div className="pt-2 border-t border-slate-800">
                              <div className="text-yellow-400 text-xs font-black uppercase mb-1">Bezpečný proud po redukci ($I_z$)</div>
                              <div className="text-5xl font-black text-white">{results.iz_adj.toFixed(1)} <span className="text-xl text-slate-500 font-normal">A</span></div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-2">
                              <div className="bg-slate-800/50 p-2 rounded text-[10px]">
                                <span className="text-slate-500 block">Teplota ($k_1$):</span>
                                <span className="text-blue-400 font-bold">{getTempFactor(ambientTemp).toFixed(2)}</span>
                              </div>
                              <div className="bg-slate-800/50 p-2 rounded text-[10px]">
                                <span className="text-slate-500 block">Seskupení ($k_2$):</span>
                                <span className="text-blue-400 font-bold">{getGroupFactor(groupCount).toFixed(2)}</span>
                              </div>
                            </div>

                            <div className={`p-3 rounded-xl flex items-center justify-between gap-3 ${results.current > results.iz_adj ? 'bg-red-500/10 border border-red-500/50' : 'bg-green-500/10 border border-green-500/50'}`}>
                              <div className={`text-[10px] font-bold ${results.current > results.iz_adj ? 'text-red-400' : 'text-green-400'}`}>
                                Proud spotřebiče: {results.current.toFixed(1)} A
                              </div>
                              {results.current > results.iz_adj ? (
                                <AlertTriangle size={16} className="text-red-500 animate-pulse" />
                              ) : (
                                <CheckCircle2 size={16} className="text-green-500" />
                              )}
                            </div>
                          </div>
                        )}
                        
                        <button 
                          onClick={saveToHistory}
                          className="w-full mt-4 py-3 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2"
                        >
                          <RefreshCw size={14} /> Uložit do historie
                        </button>
                      </div>
                    </motion.div>
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs text-amber-800">
                      <p><strong>{calcMode === 'section' ? 'Výpočet dle úbytku:' : 'Výpočet zatížitelnosti:'}</strong> {calcMode === 'section' ? 'Hledáme vhodný vodič pro daný výkon a délku.' : 'Zjišťujeme, zda vybraný vodič bezpečně unese proud spotřebiče v daných podmínkách.'}</p>
                    </div>
                  </div>
                </div>

                {/* History Section */}
                {history.length > 0 && (
                  <div className="mt-12 space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                        <RefreshCw size={16} /> Historie výpočtů
                      </h3>
                      <button 
                        onClick={clearHistory}
                        className="text-xs text-red-500 hover:text-red-700 font-bold flex items-center gap-1 transition-colors px-2 py-1 rounded hover:bg-red-50"
                        title="Smazat celou historii"
                        id="clear-history-btn"
                      >
                        <Trash2 size={14} /> Smazat historii
                      </button>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {history.map((item) => (
                        <motion.div 
                          key={item.id}
                          layout
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="bg-white border-2 border-slate-100 rounded-xl p-4 shadow-sm hover:border-blue-200 transition-all relative group"
                        >
                          <div className="flex justify-between items-start mb-3">
                            <div className="bg-blue-600 text-white px-2 py-1 rounded text-[10px] font-black">{item.standardSection} mm²</div>
                            <div className="text-[8px] text-slate-400 italic uppercase">{item.calcMode === 'capacity' ? 'Zatížitelnost' : 'Průřez'}</div>
                            <button 
                              onClick={() => loadFromHistory(item)}
                              className="text-blue-600 hover:text-blue-800 text-[10px] font-bold underline"
                            >
                              Obnovit
                            </button>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-[10px]">
                            <div className="text-slate-500">P: <span className="text-slate-800 font-bold">{item.power}W</span></div>
                            <div className="text-slate-500">L: <span className="text-slate-800 font-bold">{item.length}m</span></div>
                            <div className="text-slate-500">U: <span className="text-slate-800 font-bold">{item.voltage}V ({item.phases}f)</span></div>
                            <div className="text-slate-500">Mat: <span className="text-slate-800 font-bold">{item.material === 'cu' ? 'Cu' : 'Al'}</span></div>
                            <div className="text-slate-500">Limit: <span className="text-slate-800 font-bold">{item.maxDrop}%</span></div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {tab === 'test' && (
              <motion.div 
                key="test"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="max-w-2xl mx-auto py-4"
              >
                {testState === 'intro' && (
                  <div className="text-center space-y-6 py-8">
                    <motion.div 
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto text-blue-600"
                    >
                      <GraduationCap size={40} />
                    </motion.div>
                    <div>
                      <h2 className="text-2xl font-bold text-slate-800">Znalostní test: Dimenzování</h2>
                      <p className="text-slate-600 mt-2 text-sm sm:text-base">Čeká vás 10 náhodných úloh z praxe. Pro výpočet použijte kalkulačku v první záložce. Předpokládaný úbytek napětí je vždy <strong>ΔU = 3%</strong>.</p>
                    </div>
                    <button 
                      onClick={startTest} 
                      className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-xl shadow-lg transition-transform hover:scale-105 active:scale-95 flex items-center gap-2 mx-auto"
                      id="start-test-btn"
                    >
                      Spustit test <RefreshCw size={18} />
                    </button>
                  </div>
                )}

                {testState === 'playing' && (
                  <div className="space-y-8">
                    <motion.div 
                      key={currentQuestionIdx}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-sm"
                    >
                      <div className="absolute top-0 right-0 p-4 opacity-5 text-slate-900"><Calculator size={80} /></div>
                      <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                        Zadání úkolu {currentQuestionIdx + 1}:
                      </h3>
                      <div className="grid grid-cols-2 gap-y-6 gap-x-4 sm:gap-x-8">
                        <div className="flex items-center gap-3">
                          <Zap size={18} className="text-yellow-500 shrink-0" />
                          <div><span className="text-[10px] text-slate-500 block uppercase font-bold">Výkon</span><span className="text-base sm:text-lg font-mono font-bold">{selectedQuestions[currentQuestionIdx]?.power} W</span></div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Ruler size={18} className="text-blue-500 shrink-0" />
                          <div><span className="text-[10px] text-slate-500 block uppercase font-bold">Délka</span><span className="text-base sm:text-lg font-mono font-bold">{selectedQuestions[currentQuestionIdx]?.length} m</span></div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Thermometer size={18} className="text-orange-500 shrink-0" />
                          <div><span className="text-[10px] text-slate-500 block uppercase font-bold">Materiál</span><span className="text-base sm:text-lg font-bold">{selectedQuestions[currentQuestionIdx]?.material === 'cu' ? 'Měď (Cu)' : 'Hliník (Al)'}</span></div>
                        </div>
                        <div className="flex items-center gap-3">
                          <ShieldCheck size={18} className="text-green-500 shrink-0" />
                          <div><span className="text-[10px] text-slate-500 block uppercase font-bold">Soustava</span><span className="text-base sm:text-lg font-bold">{selectedQuestions[currentQuestionIdx]?.phases} fáze</span></div>
                        </div>
                      </div>
                    </motion.div>

                    <div className="space-y-4">
                      <label className="block text-[10px] font-bold text-slate-700 text-center uppercase tracking-widest">Zvolte správný průřez S (mm²):</label>
                      <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                        {standardSizes.map(size => (
                          <button 
                            key={size} 
                            disabled={feedback !== null}
                            onClick={() => setUserAnswer(size.toString())}
                            className={`py-3 rounded-lg border-2 font-mono font-bold transition-all text-sm sm:text-base ${userAnswer === size.toString() ? 'bg-blue-600 border-blue-600 text-white shadow-md' : 'bg-white border-slate-200 text-slate-600 hover:border-blue-300'}`}
                          >
                            {size}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="flex flex-col items-center gap-4">
                      <button 
                        onClick={handleAnswer} 
                        disabled={!userAnswer || feedback !== null}
                        className={`w-full max-w-xs py-4 rounded-xl font-black uppercase tracking-widest shadow-lg transition-all ${!userAnswer || feedback !== null ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-green-600 hover:bg-green-700 text-white hover:scale-105 active:scale-95'}`}
                        id="verify-answer-btn"
                      >
                        Ověřit odpověď
                      </button>
                      
                      <AnimatePresence>
                        {feedback && (
                          <motion.div 
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className={`flex items-center gap-2 font-bold ${feedback === 'correct' ? 'text-green-600' : 'text-red-600'}`}
                          >
                            {feedback === 'correct' ? <><CheckCircle2 /> Správně!</> : <><XCircle /> Chyba, správně bylo {selectedQuestions[currentQuestionIdx].correctS} mm²</>}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                )}

                {testState === 'finished' && (
                  <div className="text-center space-y-8 py-8">
                    <motion.div 
                      initial={{ scale: 0, rotate: -20 }}
                      animate={{ scale: 1, rotate: 0 }}
                      className="relative inline-block"
                    >
                      <div className={`w-32 h-32 rounded-full flex items-center justify-center border-8 ${score >= 7 ? 'border-green-500 text-green-500' : 'border-orange-500 text-orange-500'}`}>
                        <span className="text-4xl font-black">{score}/10</span>
                      </div>
                      <div className="absolute -bottom-2 -right-2 bg-white rounded-full p-2 shadow-lg border">
                        {score >= 7 ? <CheckCircle2 className="text-green-500" size={32} /> : <AlertTriangle className="text-orange-500" size={32} />}
                      </div>
                    </motion.div>
                    <div>
                      <h2 className="text-3xl font-black text-slate-800">Test dokončen!</h2>
                      <p className="text-slate-600 mt-2 text-lg">
                        {score === 10 ? 'Perfektní! Jste mistr dimenzování.' : score >= 7 ? 'Dobrá práce, základy ovládáte skvěle.' : 'Nebylo to špatné, ale zkuste si teorii ještě jednou projít.'}
                      </p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                      <button onClick={startTest} className="bg-blue-600 text-white font-bold py-3 px-8 rounded-xl shadow-lg flex items-center gap-2 justify-center hover:scale-105 transition-transform active:scale-95">
                        Zkusit znovu <RefreshCw size={18} />
                      </button>
                      <button onClick={() => setTab('calc')} className="bg-slate-200 text-slate-700 font-bold py-3 px-8 rounded-xl justify-center hover:bg-slate-300 transition-colors">
                        Zpět ke kalkulačce
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {tab === 'theory' && (
              <motion.div 
                key="theory"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="prose prose-slate max-w-none space-y-8 pb-12"
              >
                <section className="bg-blue-50 p-6 rounded-2xl border border-blue-100">
                  <h3 className="text-blue-900 mt-0 flex items-center gap-2 font-bold"><Info size={22} className="text-blue-600" /> Metodika výpočtu a normy</h3>
                  <p className="text-sm leading-relaxed">
                    Dimenzování vodičů se neřídí pouze úbytkem napětí. V praxi musí elektrotechnik zohlednit mechanickou pevnost, 
                    oteplení ( proudovou zatížitelnost) a ekonomické hledisko. Tato aplikace se zaměřuje na výpočet průřezu 
                    vzhledem k <strong>maximálnímu povolenému úbytku napětí (ΔU)</strong>, což je kritický parametr zejména u delších vedení.
                  </p>
                </section>

                <div className="grid md:grid-cols-2 gap-8">
                  <div className="bg-slate-50 p-5 rounded-xl border border-slate-200">
                    <h4 className="font-bold text-slate-800 mb-3 flex items-center gap-2">
                       <Calculator size={18} className="text-blue-600" /> Základní vzorce
                    </h4>
                    <div className="space-y-4 font-mono text-center">
                      <div className="bg-white p-4 rounded-lg border border-slate-300 shadow-sm">
                        <div className="text-[10px] text-slate-400 mb-1 uppercase tracking-widest font-sans">1-fázová soustava (L+N)</div>
                        <div className="text-lg">S = (2 · L · I · ρ) / ΔU</div>
                      </div>
                      <div className="bg-white p-4 rounded-lg border border-slate-300 shadow-sm">
                        <div className="text-[10px] text-slate-400 mb-1 uppercase tracking-widest font-sans">3-fázová soustava (3L+N)</div>
                        <div className="text-lg">S = (√3 · L · I · ρ) / ΔU</div>
                      </div>
                    </div>
                    <div className="mt-4 text-[11px] text-slate-500 space-y-1 px-1">
                      <p><strong>L:</strong> délka vedení v metrech [m]</p>
                      <p><strong>I:</strong> výpočtový proud v amprech [A]</p>
                      <p><strong>ρ:</strong> rezistivita materiálu [Ω·mm²/m] (Cu: 0.0178, Al: 0.029)</p>
                    </div>
                  </div>

                  <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 text-sm">
                    <h4 className="font-bold text-slate-800 mb-3 flex items-center gap-2">
                      <Ruler size={18} className="text-blue-600" /> Standardní průřezy
                    </h4>
                    <p className="mb-3 italic text-xs text-slate-600">
                      Vypočtený průřez se vždy zaokrouhluje na <strong>nejbližší vyšší</strong> hodnotu z této normalizované řady:
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {standardSizes.map(s => (
                        <span key={s} className="bg-white px-3 py-1.5 rounded-lg border border-slate-300 font-bold text-blue-600 shadow-sm">
                          {s} <span className="text-[10px] text-slate-400 font-normal">mm²</span>
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                    <div className="text-orange-600 bg-orange-50 w-10 h-10 rounded-lg flex items-center justify-center">
                      <Thermometer size={20} />
                    </div>
                    <h4 className="font-bold text-slate-800 m-0">Vliv teploty ($k_1$)</h4>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Se stoupající teplotou okolí klesá schopnost vodiče odvádět teplo. Pokud je okolní teplota vyšší než 30°C, 
                      musíme použít opravný koeficient, který snižuje maximální povolený proud vodičem.
                    </p>
                  </div>

                  <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                    <div className="text-blue-600 bg-blue-50 w-10 h-10 rounded-lg flex items-center justify-center">
                      <Zap size={20} />
                    </div>
                    <h4 className="font-bold text-slate-800 m-0">Seskupení ($k_2$)</h4>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Pokud v jednom žlabu nebo trubce vede více zatížených obvodů, vodiče se navzájem zahřívají. 
                      Pro 9 a více obvodů může tento koeficient klesnout až na 0.5 (poloviční zatížitelnost).
                    </p>
                  </div>

                  <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                    <div className="text-green-600 bg-green-50 w-10 h-10 rounded-lg flex items-center justify-center">
                      <AlertTriangle size={20} />
                    </div>
                    <h4 className="font-bold text-slate-800 m-0">Nadmořská výška</h4>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      V extrémních výškách (nad 2000 m n. m.) je řidší vzduch, který hůře chladí elektrické přístroje a vodiče. 
                      U běžných instalací do 1000 m n. m. se tento vliv obvykle zanedbává.
                    </p>
                  </div>
                </div>

                <div className="bg-slate-900 text-white p-6 rounded-2xl">
                  <h4 className="text-blue-400 mt-0 font-bold text-sm uppercase tracking-widest mb-4">Praktické pravidlo pro studenty</h4>
                  <p className="text-slate-300 text-sm leading-relaxed mb-0">
                    Vždy pamatujte: <strong>Jistič chrání vedení, ne spotřebič!</strong> Průřez vodiče musí být dimenzován tak, 
                    aby při dlouhodobém průchodu proudu nedošlo k poškození izolace teplem, a zároveň aby při zkratu 
                    došlo k bezpečnému a rychlému vypnutí jističe (impedance smyčky).
                  </p>
                </div>

                {/* Interactive Visualization Section */}
                <div className="bg-white border-2 border-slate-200 rounded-3xl overflow-hidden shadow-sm">
                  <div className="bg-slate-50 border-b border-slate-200 p-6">
                    <h3 className="text-slate-800 m-0 flex items-center gap-2 font-bold text-lg">
                      <RefreshCw size={22} className="text-blue-600" /> Interaktivní vizualizace vlivů
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">Sledujte, jak se mění zatížitelnost 2.5 mm² Cu vodiče (běžně 27 A) při změně podmínek.</p>
                  </div>
                  
                  <div className="p-6 grid md:grid-cols-2 gap-10">
                    <div className="space-y-8">
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <label className="text-xs font-black uppercase text-slate-600">Teplota okolí: {ambientTemp}°C</label>
                          <span className={`text-xs font-bold px-2 py-1 rounded ${getTempFactor(ambientTemp) < 1 ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>
                            $k_1$ = {getTempFactor(ambientTemp).toFixed(2)}
                          </span>
                        </div>
                        <input 
                          type="range" 
                          min="15" 
                          max="55" 
                          step="5"
                          value={ambientTemp} 
                          onChange={(e) => setAmbientTemp(Number(e.target.value))}
                          className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                        />
                      </div>

                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <label className="text-xs font-black uppercase text-slate-600">Počet obvodů v seskupení: {groupCount}</label>
                          <span className={`text-xs font-bold px-2 py-1 rounded ${getGroupFactor(groupCount) < 1 ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>
                            $k_2$ = {getGroupFactor(groupCount).toFixed(2)}
                          </span>
                        </div>
                        <input 
                          type="range" 
                          min="1" 
                          max="12" 
                          step="1"
                          value={groupCount} 
                          onChange={(e) => setGroupCount(Number(e.target.value))}
                          className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                        />
                      </div>
                    </div>

                    <div className="flex flex-col justify-center gap-6">
                      <div className="space-y-2">
                        <div className="flex justify-between text-[10px] font-bold uppercase text-slate-400">
                          <span>Využitelná kapacita ($I_z$)</span>
                          <span>{(27 * getTempFactor(ambientTemp) * getGroupFactor(groupCount)).toFixed(1)} A / 27 A</span>
                        </div>
                        <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden flex shadow-inner">
                          <motion.div 
                            animate={{ width: `${(getTempFactor(ambientTemp) * getGroupFactor(groupCount) * 100)}%` }}
                            className={`h-full transition-colors ${getTempFactor(ambientTemp) * getGroupFactor(groupCount) < 0.6 ? 'bg-red-500' : getTempFactor(ambientTemp) * getGroupFactor(groupCount) < 0.85 ? 'bg-orange-500' : 'bg-green-500'}`}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                          <div className="text-[10px] uppercase font-black text-slate-400 mb-1">Změna kapacity</div>
                          <div className={`text-xl font-black ${getTempFactor(ambientTemp) * getGroupFactor(groupCount) < 1 ? 'text-red-600' : 'text-slate-800'}`}>
                            {((getTempFactor(ambientTemp) * getGroupFactor(groupCount) - 1) * 100).toFixed(0)} %
                          </div>
                        </div>
                        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                          <div className="text-[10px] uppercase font-black text-slate-400 mb-1">Celkový koef. $k$</div>
                          <div className="text-xl font-black text-blue-600">
                            {(getTempFactor(ambientTemp) * getGroupFactor(groupCount)).toFixed(2)}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Capacity Graph Section */}
                <div className="bg-white border-2 border-slate-200 rounded-3xl overflow-hidden shadow-sm">
                  <div className="bg-slate-50 border-b border-slate-200 p-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                      <h3 className="text-slate-800 m-0 flex items-center gap-2 font-bold text-lg">
                        <Calculator size={22} className="text-blue-600" /> Graf zatížitelnosti vodičů
                      </h3>
                      <p className="text-xs text-slate-500 mt-1">{"Závislost maximálního proudu ($I_{ref}$) na průřezu vodiče ($S$)."}</p>
                    </div>
                    <div className="flex bg-slate-200 p-1 rounded-lg">
                      <button 
                        onClick={() => setChartMaterial('cu')}
                        className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all ${chartMaterial === 'cu' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                      >
                        Měď (Cu)
                      </button>
                      <button 
                        onClick={() => setChartMaterial('al')}
                        className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all ${chartMaterial === 'al' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                      >
                        Hliník (Al)
                      </button>
                    </div>
                  </div>

                  <div className="p-6 h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart 
                        data={Object.keys(capacityTable).map(s => ({
                          s: parseFloat(s),
                          val: capacityTable[parseFloat(s)][chartMaterial === 'cu' ? 0 : 1]
                        }))}
                        margin={{ top: 10, right: 30, left: 10, bottom: 30 }}
                      >
                        <defs>
                          <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={chartMaterial === 'cu' ? "#2563eb" : "#94a3b8"} stopOpacity={0.3}/>
                            <stop offset="95%" stopColor={chartMaterial === 'cu' ? "#2563eb" : "#94a3b8"} stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis 
                          dataKey="s" 
                          label={{ value: 'Průřez [mm²]', position: 'insideBottom', offset: -10, fontSize: 10, fontWeight: 'bold' }}
                          tick={{ fontSize: 10 }}
                        />
                        <YAxis 
                          label={{ value: 'Proud [A]', angle: -90, position: 'insideLeft', offset: 15, fontSize: 10, fontWeight: 'bold' }}
                          tick={{ fontSize: 10 }}
                        />
                        <Tooltip 
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                          formatter={(value: any) => [`${value} A`, 'Zatížitelnost']}
                          labelFormatter={(label) => `Průřez: ${label} mm²`}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="val" 
                          stroke={chartMaterial === 'cu' ? "#2563eb" : "#475569"} 
                          strokeWidth={3}
                          fillOpacity={1} 
                          fill="url(#colorVal)" 
                          animationDuration={1000}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="bg-slate-900 p-4 text-center text-slate-500 text-[10px] border-t border-slate-800 uppercase tracking-widest">
          Edukační modul: Výpočet průřezu vodičů | v1.3 | QR Sdílení aktivní
        </div>
      </div>
    </div>
  );
};

export default App;
