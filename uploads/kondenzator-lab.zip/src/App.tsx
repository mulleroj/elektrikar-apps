/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings, Info, RefreshCw, Zap, Cpu, ArrowRight, ZoomIn, Move, MousePointer2, Share2, X, BookOpen, Calculator, Activity } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

// Types
type Mode = 'AC' | 'DC';

interface TooltipData {
  x: number;
  y: number;
  time?: number;
  voltage?: number;
  current?: number;
  angle?: number;
  vAngle?: number;
  iAngle?: number;
  type: 'waves' | 'phasors';
}

// Constants
const COLOR_VOLTAGE = '#ef4444'; // Red-500
const COLOR_CURRENT = '#3b82f6'; // Blue-500

export default function App() {
  const [mode, setMode] = useState<Mode>('AC');
  const [frequency, setFrequency] = useState(50);
  const [capacitance, setCapacitance] = useState(100); // µF
  const [resistance, setResistance] = useState(10); // Ω
  const [dcResetTime, setDcResetTime] = useState(Date.now());
  
  // Advanced Settings
  const [vMax, setVMax] = useState(80);
  const [iMax, setIMax] = useState(80);
  const [animSpeed, setAnimSpeed] = useState(1.0);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [splitScope, setSplitScope] = useState(false);
  
  // Interactivity state
  const [zoom, setZoom] = useState(1);
  const [panX, setPanX] = useState(0);
  const [isPanning, setIsPanning] = useState(false);
  const [manualPhasorOffset, setManualPhasorOffset] = useState(0);
  const [isRotatingPhasors, setIsRotatingPhasors] = useState(false);
  const [tooltip, setTooltip] = useState<TooltipData | null>(null);
  const [showShare, setShowShare] = useState(false);
  const [showDoc, setShowDoc] = useState(false);
  const [hoveredSignal, setHoveredSignal] = useState<'voltage' | 'current' | null>(null);
  
  const canvasWavesRef = useRef<HTMLCanvasElement>(null);
  const canvasPhasorsRef = useRef<HTMLCanvasElement>(null);
  const resistanceDisplayRef = useRef<HTMLSpanElement>(null);
  const requestRef = useRef<number>(null);
  const startTimeRef = useRef(Date.now());
  const lastMouseX = useRef(0);
  const lastPhasorAngle = useRef(0);

  // Constants for physical realism
  const V_REAL_PEAK = 230; // V

  // Calculations
  const cFarads = capacitance / 1_000_000;
  const xcStatic = 1 / (2 * Math.PI * frequency * cFarads);
  const zTotal = Math.sqrt(Math.pow(resistance, 2) + Math.pow(xcStatic, 2));
  const phaseShiftRad = Math.atan(xcStatic / Math.max(0.01, resistance));
  const phaseShiftDeg = phaseShiftRad * 180 / Math.PI;

  const iRealPeak = V_REAL_PEAK / zTotal;
  
  // Visual scaling
  const iVisualScale = Math.min(1.8, Math.max(0.15, Math.pow(40 / zTotal, 0.6)));
  const iMaxVisual = iMax * iVisualScale;

  // Drawing helpers
  const drawArrow = (ctx: CanvasRenderingContext2D, x: number, y: number, angle: number, length: number, color: string, width: number = 3) => {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(length, 0);
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = 'round';
    ctx.stroke();
    
    // Arrowhead
    ctx.beginPath();
    ctx.fillStyle = color;
    ctx.moveTo(length, 0);
    ctx.lineTo(length - 10, -6);
    ctx.lineTo(length - 10, 6);
    ctx.fill();
    ctx.restore();
  };

  const animate = useCallback(() => {
    const now = Date.now();
    const elapsed = ((now - startTimeRef.current) / 1000) * animSpeed;
    
    const canvasWaves = canvasWavesRef.current;
    const canvasPhasors = canvasPhasorsRef.current;
    const resistanceDisplay = resistanceDisplayRef.current;
    
    if (!canvasWaves || !canvasPhasors) return;
    
    const ctxWaves = canvasWaves.getContext('2d');
    const ctxPhasors = canvasPhasors.getContext('2d');
    
    if (!ctxWaves || !ctxPhasors) return;

    // --- OSCILLOSCOPE ---
    ctxWaves.clearRect(0, 0, canvasWaves.width, canvasWaves.height);
    
    // Grid with Pan/Zoom
    ctxWaves.strokeStyle = '#1e293b';
    ctxWaves.lineWidth = 1;
    const gridSize = 40 * zoom;
    const startGridX = panX % gridSize;
    for (let i = startGridX; i < canvasWaves.width; i += gridSize) {
      ctxWaves.beginPath(); ctxWaves.moveTo(i, 0); ctxWaves.lineTo(i, canvasWaves.height); ctxWaves.stroke();
    }
    for (let i = 0; i < canvasWaves.height; i += 40) {
      ctxWaves.beginPath(); ctxWaves.moveTo(0, i); ctxWaves.lineTo(canvasWaves.width, i); ctxWaves.stroke();
    }

    const midY = canvasWaves.height / 2;
    const midYU = splitScope ? canvasWaves.height * 0.25 : midY;
    const midYI = splitScope ? canvasWaves.height * 0.75 : midY;
    const scaleFactor = splitScope ? 0.6 : 1.0;

    if (mode === 'AC') {
      const omega = 2 * Math.PI * frequency;
      const speed = 0.05;

      // Update static display bypass - show Impedance in AC
      if (resistanceDisplay) resistanceDisplay.innerText = zTotal.toFixed(2);

      // U Wave (Total Voltage)
      const isUHovered = hoveredSignal === 'voltage';
      ctxWaves.beginPath();
      ctxWaves.strokeStyle = COLOR_VOLTAGE;
      ctxWaves.lineWidth = isUHovered ? 6 : 3;
      if (isUHovered) {
        ctxWaves.shadowBlur = 15;
        ctxWaves.shadowColor = COLOR_VOLTAGE;
      }
      for (let x = 0; x < canvasWaves.width; x++) {
        const t = (x - panX) * (0.0002 / zoom);
        const y = midYU + Math.sin(omega * (t - elapsed * speed)) * vMax * scaleFactor;
        if (x === 0) ctxWaves.moveTo(x, y); else ctxWaves.lineTo(x, y);
      }
      ctxWaves.stroke();
      ctxWaves.shadowBlur = 0;

      // I Wave (Leads by phaseShiftRad)
      const isIHovered = hoveredSignal === 'current';
      ctxWaves.beginPath();
      ctxWaves.strokeStyle = COLOR_CURRENT;
      ctxWaves.lineWidth = isIHovered ? 6 : 3;
      if (isIHovered) {
        ctxWaves.shadowBlur = 15;
        ctxWaves.shadowColor = COLOR_CURRENT;
      }
      for (let x = 0; x < canvasWaves.width; x++) {
        const t = (x - panX) * (0.0002 / zoom);
        const y = midYI + Math.sin(omega * (t - elapsed * speed) + phaseShiftRad) * iMaxVisual * scaleFactor;
        if (x === 0) ctxWaves.moveTo(x, y); else ctxWaves.lineTo(x, y);
      }
      ctxWaves.stroke();
      ctxWaves.shadowBlur = 0;

      // Phasor Diagram
      ctxPhasors.clearRect(0, 0, canvasPhasors.width, canvasPhasors.height);
      const centerX = canvasPhasors.width / 2;
      const centerY = canvasPhasors.height / 2;
      const currentAngle = (-elapsed * 5) + manualPhasorOffset;

      if (hoveredSignal === 'voltage') {
        ctxPhasors.shadowBlur = 15;
        ctxPhasors.shadowColor = COLOR_VOLTAGE;
      }
      drawArrow(ctxPhasors, centerX, centerY, currentAngle, vMax * 0.8, COLOR_VOLTAGE, hoveredSignal === 'voltage' ? 6 : 3);
      ctxPhasors.shadowBlur = 0;

      // I Phasor leads by phaseShiftRad
      if (hoveredSignal === 'current') {
        ctxPhasors.shadowBlur = 15;
        ctxPhasors.shadowColor = COLOR_CURRENT;
      }
      drawArrow(ctxPhasors, centerX, centerY, currentAngle - phaseShiftRad, iMaxVisual * 0.8, COLOR_CURRENT, hoveredSignal === 'current' ? 6 : 3);
      ctxPhasors.shadowBlur = 0;

    } else {
      // DC Mode
      const dcElapsed = (now - dcResetTime) / 1000;
      const tau = Math.max(0.01, resistance * cFarads * 50); // Scaled for visualization speed (x50)

      // Update dynamic resistance display in DC
      if (resistanceDisplay) {
        const instantaneousTime = dcElapsed;
        const currentI = Math.exp(-instantaneousTime / tau);
        const rInferred = resistance / Math.max(0.001, currentI);
        resistanceDisplay.innerText = rInferred > 5000 ? "∞" : rInferred.toFixed(1);
      }

      // U Curve (Charging)
      const isUHovered = hoveredSignal === 'voltage';
      ctxWaves.beginPath();
      ctxWaves.strokeStyle = COLOR_VOLTAGE;
      ctxWaves.lineWidth = isUHovered ? 6 : 3;
      if (isUHovered) {
        ctxWaves.shadowBlur = 15;
        ctxWaves.shadowColor = COLOR_VOLTAGE;
      }
      for (let x = 0; x < canvasWaves.width; x++) {
        const t = ( (x - panX) / (canvasWaves.width * zoom) ) * 5;
        const timeWindow = t + dcElapsed - 2.5;
        let val = timeWindow < 0 ? 0 : 1 - Math.exp(-timeWindow / tau);
        const y = midYU - (val * vMax * scaleFactor);
        if (x === 0) ctxWaves.moveTo(x, y); else ctxWaves.lineTo(x, y);
      }
      ctxWaves.stroke();
      ctxWaves.shadowBlur = 0;

      // I Curve (Falling)
      const isIHovered = hoveredSignal === 'current';
      ctxWaves.beginPath();
      ctxWaves.strokeStyle = COLOR_CURRENT;
      ctxWaves.lineWidth = isIHovered ? 6 : 3;
      if (isIHovered) {
        ctxWaves.shadowBlur = 15;
        ctxWaves.shadowColor = COLOR_CURRENT;
      }
      for (let x = 0; x < canvasWaves.width; x++) {
        const t = ( (x - panX) / (canvasWaves.width * zoom) ) * 5;
        const timeWindow = t + dcElapsed - 2.5;
        let val = timeWindow < 0 ? 0 : Math.exp(-timeWindow / tau);
        const y = midYI - (val * iMaxVisual * scaleFactor);
        if (x === 0) ctxWaves.moveTo(x, y); else ctxWaves.lineTo(x, y);
      }
      ctxWaves.stroke();
      ctxWaves.shadowBlur = 0;

      // Static Phasors for DC
      ctxPhasors.clearRect(0, 0, canvasPhasors.width, canvasPhasors.height);
      const currentI_DC = Math.exp(-dcElapsed / tau);
      const currentU_DC = 1 - currentI_DC;
      
      if (hoveredSignal === 'voltage') {
        ctxPhasors.shadowBlur = 15;
        ctxPhasors.shadowColor = COLOR_VOLTAGE;
      }
      drawArrow(ctxPhasors, canvasPhasors.width / 2, canvasPhasors.height / 2, 0, currentU_DC * vMax, COLOR_VOLTAGE, hoveredSignal === 'voltage' ? 6 : 3);
      ctxPhasors.shadowBlur = 0;

      if (hoveredSignal === 'current') {
        ctxPhasors.shadowBlur = 15;
        ctxPhasors.shadowColor = COLOR_CURRENT;
      }
      drawArrow(ctxPhasors, canvasPhasors.width / 2, canvasPhasors.height / 2, 0, currentI_DC * iMaxVisual, COLOR_CURRENT, hoveredSignal === 'current' ? 6 : 3);
      ctxPhasors.shadowBlur = 0;
    }

    requestRef.current = requestAnimationFrame(animate);
  }, [mode, frequency, capacitance, dcResetTime, zoom, panX, xcStatic, vMax, iMax, animSpeed, resistance, splitScope, manualPhasorOffset, iMaxVisual, zTotal, phaseShiftRad, hoveredSignal]);

  useEffect(() => {
    const handleResize = () => {
      if (canvasWavesRef.current) {
        canvasWavesRef.current.width = canvasWavesRef.current.offsetWidth;
        canvasWavesRef.current.height = canvasWavesRef.current.offsetHeight;
      }
      if (canvasPhasorsRef.current) {
        canvasPhasorsRef.current.width = canvasPhasorsRef.current.offsetWidth;
        canvasPhasorsRef.current.height = canvasPhasorsRef.current.offsetHeight;
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    requestRef.current = requestAnimationFrame(animate);
    
    return () => {
      window.removeEventListener('resize', handleResize);
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [animate]);

  // Interaction handlers
  const handleOscilloscopeInteraction = (e: React.MouseEvent | React.WheelEvent) => {
    const canvas = canvasWavesRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (e.type === 'wheel') {
      const wheelEvent = e as React.WheelEvent;
      const zoomFactor = 1.1;
      const direction = wheelEvent.deltaY > 0 ? 1 / zoomFactor : zoomFactor;
      const nextZoom = Math.max(0.5, Math.min(10, zoom * direction));
      
      // Zoom relative to mouse position
      const mouseRelativeX = x - panX;
      const nextPanX = x - mouseRelativeX * (nextZoom / zoom);
      
      setZoom(nextZoom);
      setPanX(nextPanX);
      return;
    }

    if (e.type === 'mousedown') {
      setIsPanning(true);
      lastMouseX.current = e.clientX;
    } else if (e.type === 'mouseup' || e.type === 'mouseleave') {
      setIsPanning(false);
      if (e.type === 'mouseleave') {
        setTooltip(null);
        setHoveredSignal(null);
      }
    } else if (e.type === 'mousemove') {
      if (isPanning) {
        const dx = e.clientX - lastMouseX.current;
        setPanX(prev => prev + dx);
        lastMouseX.current = e.clientX;
      }
 
      // Proximity detection for highlighting
      const midY = canvas.height / 2;
      const midYU = splitScope ? canvas.height * 0.25 : midY;
      const midYI = splitScope ? canvas.height * 0.75 : midY;
      const scaleFactor = splitScope ? 0.6 : 1.0;

      // Tooltip data
      const now = Date.now();
      const elapsed = ((now - startTimeRef.current) / 1000) * animSpeed;

      let t, volt, curr;
      let voltVisY, currVisY;

      if (mode === 'AC') {
        const omega = 2 * Math.PI * frequency;
        const speed = 0.05;
        t = (x - panX) * (0.0002 / zoom);
        const voltVal = Math.sin(omega * (t - elapsed * speed));
        const currVal = Math.sin(omega * (t - elapsed * speed) + phaseShiftRad);
        volt = voltVal * vMax;
        curr = currVal * iMaxVisual;
        voltVisY = midYU + voltVal * vMax * scaleFactor;
        currVisY = midYI + currVal * iMaxVisual * scaleFactor;
      } else {
        const dcElapsed = (now - dcResetTime) / 1000;
        const tau = Math.max(0.01, resistance * cFarads * 50);
        t = ( (x - panX) / (canvas.width * zoom) ) * 5;
        const timeWindow = t + dcElapsed - 2.5;
        const voltVal = timeWindow < 0 ? 0 : 1 - Math.exp(-timeWindow / tau);
        const currVal = timeWindow < 0 ? 0 : Math.exp(-timeWindow / tau);
        volt = voltVal * vMax;
        curr = currVal * iMaxVisual;
        voltVisY = midYU - (voltVal * vMax * scaleFactor);
        currVisY = midYI - (currVal * iMaxVisual * scaleFactor);
      }

      // Highlight logic
      const distU = Math.abs(y - voltVisY);
      const distI = Math.abs(y - currVisY);
      if (distU < 30 && distU < distI) setHoveredSignal('voltage');
      else if (distI < 30 && distI < distU) setHoveredSignal('current');
      else setHoveredSignal(null);

      setTooltip({
        x, y, 
        time: t * 1000, 
        voltage: volt, 
        current: curr, 
        type: 'waves'
      });
    }
  };

  const handlePhasorInteraction = (e: React.MouseEvent) => {
    const canvas = canvasPhasorsRef.current;
    if (!canvas) return;
  
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const dx = x - centerX;
    const dy = y - centerY;
    const angle = Math.atan2(dy, dx);
  
    if (e.type === 'mousedown') {
      setIsRotatingPhasors(true);
      lastPhasorAngle.current = angle;
      return;
    }
  
    if (e.type === 'mouseup' || e.type === 'mouseleave') {
      setIsRotatingPhasors(false);
      if (e.type === 'mouseleave') {
        setTooltip(null);
        setHoveredSignal(null);
      }
      return;
    }
  
    if (e.type === 'mousemove') {
      if (isRotatingPhasors) {
        const delta = angle - lastPhasorAngle.current;
        setManualPhasorOffset(prev => prev + delta);
        lastPhasorAngle.current = angle;
      }
  
      const now = Date.now();
      const elapsed = ((now - startTimeRef.current) / 1000) * animSpeed;
  
      const currentVAngle = ((-elapsed * 5) + manualPhasorOffset);
      const vDeg = ((currentVAngle * 180 / Math.PI) % 360 + 360) % 360;
      const iDeg = (( (currentVAngle - phaseShiftRad) * 180 / Math.PI) % 360 + 360) % 360;

      // Proximity highlighting for phasors
      const mouseDist = Math.sqrt(dx*dx + dy*dy);
      if (mouseDist > 20) {
        const vAngleNorm = ((currentVAngle % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        const iAngleNorm = (((currentVAngle - phaseShiftRad) % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
        const mouseAngleNorm = ((angle % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);

        const diffV = Math.abs(vAngleNorm - mouseAngleNorm);
        const diffI = Math.abs(iAngleNorm - mouseAngleNorm);
        const smallestDiffV = Math.min(diffV, Math.PI * 2 - diffV);
        const smallestDiffI = Math.min(diffI, Math.PI * 2 - diffI);

        if (smallestDiffV < 0.2) setHoveredSignal('voltage');
        else if (smallestDiffI < 0.2) setHoveredSignal('current');
        else setHoveredSignal(null);
      } else {
        setHoveredSignal(null);
      }
  
      setTooltip({
        x, y: y - 20,
        vAngle: vDeg,
        iAngle: iDeg,
        voltage: V_REAL_PEAK,
        current: iRealPeak,
        type: 'phasors'
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <header className="flex flex-col md:flex-row justify-between items-center mb-10 gap-6">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <h1 className="text-4xl font-black tracking-tight bg-gradient-to-r from-blue-400 via-cyan-400 to-emerald-400 bg-clip-text text-transparent italic">
              KONDENZÁTOR LAB
            </h1>
            <p className="text-slate-500 font-mono text-sm uppercase tracking-widest mt-1">
              Fyzikální simulace reaktance & fázového posunu
            </p>
          </motion.div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowDoc(true)}
              className="p-3 bg-slate-900 border border-slate-800 rounded-2xl text-slate-400 hover:text-white hover:border-slate-700 transition-all shadow-xl"
              title="Dokumentace a teorie"
            >
              <Info size={20} />
            </button>

            <button
              onClick={() => setShowShare(true)}
              className="p-3 bg-slate-900 border border-slate-800 rounded-2xl text-slate-400 hover:text-white hover:border-slate-700 transition-all shadow-xl"
              title="Sdílet aplikaci"
            >
              <Share2 size={20} />
            </button>

            <div className="flex p-1 bg-slate-900/80 backdrop-blur border border-slate-800 rounded-2xl shadow-xl">
              {(['AC', 'DC'] as Mode[]).map((m) => (
                <button
                  key={m}
                  id={`btn-${m.toLowerCase()}`}
                  onClick={() => {
                    setMode(m);
                    if (m === 'DC') setDcResetTime(Date.now());
                    setPanX(0);
                    setZoom(1);
                  }}
                  className={`px-8 py-2.5 rounded-xl font-bold text-sm transition-all duration-300 relative ${
                    mode === m 
                      ? 'text-white' 
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  {mode === m && (
                    <motion.div 
                      layoutId="activeMode"
                      className="absolute inset-0 bg-blue-600 rounded-xl shadow-[0_0_20px_rgba(37,99,235,0.4)]"
                      transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                  <span className="relative z-10">{m}</span>
                </button>
              ))}
            </div>
          </div>
        </header>

        {/* Documentation Modal */}
        <AnimatePresence>
          {showDoc && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[110] flex items-center justify-center p-4 md:p-10 bg-slate-950/90 backdrop-blur-lg"
              onClick={() => setShowDoc(false)}
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-slate-900 border border-slate-800 rounded-[3rem] shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col relative"
              >
                <button 
                  onClick={() => setShowDoc(false)}
                  className="absolute top-8 right-8 p-3 bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-colors z-10"
                >
                  <X size={20} />
                </button>

                <div className="p-8 md:p-12 overflow-y-auto custom-scrollbar">
                  <header className="mb-12">
                    <div className="flex items-center gap-3 text-blue-400 mb-2">
                      <BookOpen size={20} />
                      <span className="text-xs font-black uppercase tracking-[0.3em]">Komplexní průvodce</span>
                    </div>
                    <h2 className="text-4xl font-black text-white italic">Fyzika kondenzátoru v obvodu</h2>
                  </header>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                    <section className="space-y-6">
                      <h3 className="text-xl font-bold text-white flex items-center gap-3">
                        <Zap className="text-blue-400" size={20} /> Střídavý proud (AC)
                      </h3>
                      <div className="space-y-4 text-slate-400 text-sm leading-relaxed">
                        <p>
                          V obvodu střídavého proudu se kondenzátor neustále periodicky nabíjí a vybíjí. Tento proces vytváří zdánlivý odpor, který nazýváme <strong>kapacitní reaktance (X<sub>C</sub>)</strong>.
                        </p>
                        <div className="bg-slate-950 p-6 rounded-3xl border border-slate-800 font-mono text-center">
                          <div className="text-[10px] text-slate-600 mb-2 uppercase">Vzorec reaktance</div>
                          <div className="text-2xl text-blue-400 font-black">X<sub>C</sub> = 1 / (2π · f · C)</div>
                        </div>
                        <p>
                          <strong>Klíčové pozorování:</strong> Čím vyšší je frekvence (f) nebo kapacita (C), tím nižší je reaktance. Při velmi vysokých frekvencích se kondenzátor chová téměř jako zkrat.
                        </p>
                        <h4 className="text-white font-bold mt-8">Fázový posun</h4>
                        <p>
                          Proud v ideálním kondenzátoru <strong>předbíhá</strong> napětí o 90° (π/2 rad). Je to proto, že proud musí do kondenzátoru "natéct", aby se na jeho deskách vytvořilo napětí.
                        </p>
                      </div>
                    </section>

                    <section className="space-y-6">
                      <h3 className="text-xl font-bold text-white flex items-center gap-3">
                        <Activity className="text-emerald-400" size={20} /> Stejnosměrný proud (DC)
                      </h3>
                      <div className="space-y-4 text-slate-400 text-sm leading-relaxed">
                        <p>
                          Při připojení k DC zdroji dochází k přechodovému ději – nabíjení. Proud v čase exponenciálně klesá, zatímco napětí na kondenzátoru roste.
                        </p>
                        <div className="bg-slate-950 p-6 rounded-3xl border border-slate-800 font-mono text-center">
                          <div className="text-[10px] text-slate-600 mb-2 uppercase">Časová konstanta</div>
                          <div className="text-2xl text-emerald-400 font-black">τ = R · C</div>
                        </div>
                        <p>
                          <strong>Časová konstanta (τ)</strong> určuje, jak rychle se kondenzátor nabije. Po uplynutí doby 1τ je kondenzátor nabit na cca 63 %, po 5τ se považuje za plně nabitý (99 %).
                        </p>
                        <h4 className="text-white font-bold mt-8">Impedance v praxi</h4>
                        <p>
                          V reálném obvodu je s kondenzátorem vždy spojen určitý odpor (R). Celkový odpor obvodu se nazývá <strong>impedance (Z)</strong> a vypočítá se jako vektorový součet:
                        </p>
                        <div className="bg-slate-950 p-6 rounded-3xl border border-slate-800 font-mono text-center">
                          <div className="text-xl text-white font-black">Z = √(R² + X<sub>C</sub>²)</div>
                        </div>
                      </div>
                    </section>
                  </div>

                  <div className="mt-12 p-8 bg-blue-600/10 border border-blue-500/20 rounded-[2.5rem]">
                    <h4 className="text-blue-400 font-black text-xs uppercase tracking-widest mb-4">Shrnutí pro studenty</h4>
                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-300">
                      <li className="flex gap-3">
                        <div className="mt-1 text-blue-400 font-bold">•</div>
                        <span>Kapacitní reaktance klesá s rostoucí frekvencí.</span>
                      </li>
                      <li className="flex gap-3">
                        <div className="mt-1 text-blue-400 font-bold">•</div>
                        <span>Proud předbíhá napětí (ICE - I leads C in E/Voltage circuits).</span>
                      </li>
                      <li className="flex gap-3">
                        <div className="mt-1 text-blue-400 font-bold">•</div>
                        <span>V DC obvodu je kondenzátor po nabití nevodivý.</span>
                      </li>
                      <li className="flex gap-3">
                        <div className="mt-1 text-blue-400 font-bold">•</div>
                        <span>Fázový posun závisí na poměru odporu R a reaktance X<sub>C</sub>.</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Share Modal */}
        <AnimatePresence>
          {showShare && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-md"
              onClick={() => setShowShare(false)}
            >
              <motion.div 
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-slate-900 border border-slate-800 p-8 rounded-[2.5rem] shadow-2xl max-w-xs w-full text-center relative"
              >
                <button 
                  onClick={() => setShowShare(false)}
                  className="absolute top-6 right-6 p-2 text-slate-500 hover:text-white transition-colors"
                >
                  <X size={20} />
                </button>

                <h3 className="text-xl font-black text-white mb-2">Sdílet simulaci</h3>
                <p className="text-slate-400 text-sm mb-8">Naskenujte kód pro rychlý přístup studentů</p>
                
                <div className="bg-white p-4 rounded-3xl inline-block shadow-[0_0_50px_rgba(255,255,255,0.1)] mb-8">
                  <QRCodeSVG 
                    value={window.location.href} 
                    size={200}
                    level="H"
                    includeMargin={false}
                  />
                </div>

                <div className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-4">Odkaz na aplikaci</div>
                <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl flex items-center gap-3 overflow-hidden">
                  <div className="text-[10px] text-slate-400 truncate font-mono flex-grow text-left">
                    {window.location.href}
                  </div>
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(window.location.href);
                    }}
                    className="text-[10px] text-blue-400 hover:text-blue-300 font-black uppercase whitespace-nowrap"
                  >
                    Kopírovat
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Sidebar: Controls */}
          <div className="lg:col-span-4 space-y-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 p-8 rounded-3xl shadow-2xl overflow-hidden relative"
            >
              <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                <Settings size={120} />
              </div>

              <h2 className="text-xl font-bold mb-8 flex items-center gap-3 text-white">
                <div className="p-2 bg-blue-500/10 rounded-lg">
                  <Cpu className="text-blue-400" size={20} />
                </div>
                Parametry obvodu
              </h2>
              
              <div className={`space-y-10 transition-opacity duration-300 ${mode === 'DC' ? 'opacity-30 pointer-events-none' : 'opacity-100'}`}>
                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <label className="text-xs uppercase tracking-wider text-slate-400 font-bold">Frekvence (f)</label>
                    <span className="font-mono text-xl font-bold text-blue-400">{frequency} <span className="text-xs text-slate-600">Hz</span></span>
                  </div>
                  <input 
                    type="range" 
                    min="5" max="200" 
                    value={frequency} 
                    onChange={(e) => setFrequency(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-full appearance-none cursor-pointer accent-blue-500"
                  />
                </div>
              </div>

              <div className="mt-10 space-y-4">
                <div className="flex justify-between items-end">
                  <label className="text-xs uppercase tracking-wider text-slate-400 font-bold">Kapacita (C)</label>
                  <span className="font-mono text-xl font-bold text-emerald-400">{capacitance} <span className="text-xs text-slate-600">µF</span></span>
                </div>
                <input 
                  type="range" 
                  min="10" max="1000" 
                  value={capacitance} 
                  onChange={(e) => setCapacitance(Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-full appearance-none cursor-pointer accent-emerald-500"
                />
              </div>

              <div className="mt-10 space-y-4">
                <div className="flex justify-between items-end">
                  <label className="text-xs uppercase tracking-wider text-slate-400 font-bold">Odpor (R)</label>
                  <span className="font-mono text-xl font-bold text-amber-400">{resistance} <span className="text-xs text-slate-600">Ω</span></span>
                </div>
                <input 
                  type="range" 
                  min="0" max="200" 
                  value={resistance} 
                  onChange={(e) => setResistance(Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-full appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              <div className="mt-12 pt-8 border-t border-slate-800/50">
                <div className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-black mb-3">
                  {mode === 'AC' ? 'Celková impedance' : 'Relativní odpor'} (Z)
                </div>
                <div className="flex items-baseline gap-2">
                  <span ref={resistanceDisplayRef} className="text-5xl font-mono font-black text-white leading-none">
                    {mode === 'AC' ? zTotal.toFixed(2) : '0.0'}
                  </span>
                  <span className="text-2xl font-mono text-blue-500 font-bold">Ω</span>
                </div>
                <p className="mt-6 text-sm text-slate-400 leading-relaxed font-medium">
                  {mode === 'AC' 
                    ? "Kondenzátor a rezistor v sérii tvoří komplexní odpor závislý na frekvenci." 
                    : "Odpor rezistoru limituje špičkový proud při zapnutí DC zdroje."}
                </p>
              </div>
            </motion.div>

            {/* Advanced Settings */}
            <motion.div 
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: 0.15 }}
               className="bg-slate-900/40 border border-slate-800 rounded-3xl overflow-hidden shadow-lg"
            >
              <button 
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="w-full p-6 flex justify-between items-center group"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-500/10 rounded-lg group-hover:bg-purple-500/20 transition-colors">
                    <Settings className="text-purple-400" size={16} />
                  </div>
                  <h2 className="text-sm font-black uppercase tracking-widest text-slate-400 group-hover:text-slate-200 transition-colors">Pokročilé nastavení</h2>
                </div>
                <motion.div
                  animate={{ rotate: showAdvanced ? 180 : 0 }}
                  className="text-slate-600"
                >
                  <ArrowRight size={16} className="rotate-90" />
                </motion.div>
              </button>

              <AnimatePresence>
                {showAdvanced && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="px-8 pb-8 space-y-8"
                  >
                    <div className="space-y-4">
                      <div className="flex justify-between items-end">
                        <label className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Měřítko napětí (V_visual)</label>
                        <span className="font-mono text-sm font-bold text-slate-300">{vMax}</span>
                      </div>
                      <input 
                        type="range" min="20" max="150" value={vMax} 
                        onChange={(e) => setVMax(Number(e.target.value))}
                        className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-purple-500"
                      />
                    </div>

                    <div className="space-y-4">
                      <div className="flex justify-between items-end">
                        <label className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Měřítko proudu (I_visual)</label>
                        <span className="font-mono text-sm font-bold text-slate-300">{iMax}</span>
                      </div>
                      <input 
                        type="range" min="20" max="150" value={iMax} 
                        onChange={(e) => setIMax(Number(e.target.value))}
                        className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-purple-500"
                      />
                    </div>

                    <div className="space-y-4">
                      <div className="flex justify-between items-end">
                        <label className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Rychlost animace</label>
                        <span className="font-mono text-sm font-bold text-slate-300">{animSpeed.toFixed(1)}x</span>
                      </div>
                      <input 
                        type="range" min="0.1" max="5" step="0.1" value={animSpeed} 
                        onChange={(e) => setAnimSpeed(Number(e.target.value))}
                        className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-purple-500"
                      />
                    </div>

                    <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                      <label className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">Rozdělený osciloskop</label>
                      <button 
                        onClick={() => setSplitScope(!splitScope)}
                        className={`w-12 h-6 rounded-full transition-colors relative ${splitScope ? 'bg-blue-600' : 'bg-slate-800'}`}
                      >
                        <motion.div 
                          animate={{ x: splitScope ? 26 : 4 }}
                          className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm"
                        />
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            <motion.div 
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: 0.1 }}
               className="bg-slate-900/30 border border-slate-800 p-6 rounded-3xl overflow-hidden relative"
            >
              <h2 className="text-xs uppercase tracking-widest font-black text-slate-500 mb-6 px-1">Interakce</h2>
              <div className="space-y-4 relative z-10">
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-slate-800 rounded-lg"><ZoomIn size={14} className="text-blue-400" /></div>
                  <div className="text-xs text-slate-400 font-medium leading-relaxed">
                    Kolečkem myši nad osciloskopem měníš <span className="text-slate-200">časovou základnu</span>.
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-slate-800 rounded-lg"><Move size={14} className="text-emerald-400" /></div>
                  <div className="text-xs text-slate-400 font-medium leading-relaxed">
                    Tažením myši se <span className="text-slate-200">posouváš v čase</span>.
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-slate-800 rounded-lg"><MousePointer2 size={14} className="text-amber-400" /></div>
                  <div className="text-xs text-slate-400 font-medium leading-relaxed">
                    Najetím na křivku zobrazíš <span className="text-slate-200">okamžité hodnoty</span>.
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-slate-800 rounded-lg"><RefreshCw size={14} className="text-blue-500" /></div>
                  <div className="text-xs text-slate-400 font-medium leading-relaxed">
                    Tažením fázoru můžeš <span className="text-slate-200">měnit počáteční fázi</span>.
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Main Visualization Panel */}
          <div className="lg:col-span-8 space-y-8">
            {/* Oscilloscope */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="bg-slate-900 border border-slate-800 p-2 rounded-[2rem] shadow-2xl relative group"
            >
              <div className="absolute top-6 left-8 flex items-center gap-2 z-10">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[10px] uppercase tracking-widest text-slate-500 font-black">Live Scope</span>
              </div>
              <div className="absolute top-6 right-8 text-[10px] uppercase tracking-widest text-slate-500 font-black z-10">
                {mode === 'AC' ? `${(5 / zoom).toFixed(1)} ms / div` : 'Timeline'}
              </div>
              
              <div className="relative overflow-hidden rounded-[1.5rem]">
                <canvas 
                  id="canvas-waves" 
                  ref={canvasWavesRef} 
                  onMouseDown={handleOscilloscopeInteraction}
                  onMouseMove={handleOscilloscopeInteraction}
                  onMouseUp={handleOscilloscopeInteraction}
                  onMouseLeave={handleOscilloscopeInteraction}
                  onWheel={handleOscilloscopeInteraction}
                  className={`w-full h-80 bg-slate-950 transition-cursor duration-200 ${isPanning ? 'cursor-grabbing' : 'cursor-crosshair'}`} 
                />
                
                {/* Wave Tooltip */}
                {tooltip && tooltip.type === 'waves' && (
                  <div 
                    className="absolute pointer-events-none bg-slate-900/95 backdrop-blur border border-slate-700 px-4 py-3 rounded-xl shadow-2xl z-50 min-w-[140px]"
                    style={{ left: tooltip.x + 15, top: tooltip.y - 100 }}
                  >
                    <div className="text-[10px] text-slate-500 font-black uppercase mb-2">Čas: {tooltip.time?.toFixed(2)} ms</div>
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center gap-4">
                        <span className="text-xs font-bold text-red-400">Napětí:</span>
                        <span className="font-mono text-xs font-black text-white">{tooltip.voltage?.toFixed(1)} V</span>
                      </div>
                      <div className="flex justify-between items-center gap-4">
                        <span className="text-xs font-bold text-blue-400">Proud:</span>
                        <span className="font-mono text-xs font-black text-white">{tooltip.current?.toFixed(1)} A</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Phasor Diagram */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-slate-900/50 backdrop-blur border border-slate-800 p-8 rounded-3xl flex flex-col items-center relative"
              >
                <div className="w-full text-[10px] uppercase tracking-[0.2em] font-black text-slate-500 mb-8 px-2 flex justify-between">
                  <span>Vektorová analýza</span>
                  <Zap size={14} className="text-amber-400" />
                </div>
                <div className="relative p-1 bg-slate-950 rounded-full border border-slate-800 shadow-inner">
                  <canvas 
                    id="canvas-phasors" 
                    ref={canvasPhasorsRef} 
                    onMouseDown={handlePhasorInteraction}
                    onMouseMove={handlePhasorInteraction}
                    onMouseUp={handlePhasorInteraction}
                    onMouseLeave={handlePhasorInteraction}
                    className={`w-48 h-48 rounded-full transition-all duration-200 ${isRotatingPhasors ? 'cursor-grabbing' : 'cursor-pointer'}`} 
                  />
                  
                  {/* Phasor Tooltip */}
                  {tooltip && tooltip.type === 'phasors' && (
                    <div 
                      className="absolute pointer-events-none bg-slate-900/95 backdrop-blur border border-slate-700 px-4 py-3 rounded-xl shadow-2xl z-50 text-left min-w-[160px]"
                      style={{ left: tooltip.x + 20, top: tooltip.y - 60 }}
                    >
                      <div className="text-[10px] text-slate-500 font-black uppercase mb-3 border-b border-slate-800 pb-2">Vektorové hodnoty</div>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center gap-4">
                          <span className="text-[10px] font-bold text-red-400 uppercase">U Fáze:</span>
                          <span className="font-mono text-xs font-black text-white">{tooltip.vAngle?.toFixed(1)}°</span>
                        </div>
                        <div className="flex justify-between items-center gap-4">
                          <span className="text-[10px] font-bold text-blue-400 uppercase">I Fáze:</span>
                          <span className="font-mono text-xs font-black text-white">{tooltip.iAngle?.toFixed(1)}°</span>
                        </div>
                        <div className="pt-1 flex justify-between items-center gap-4 border-t border-slate-800">
                          <span className="text-[10px] font-bold text-slate-400 uppercase">Posun (φ):</span>
                          <span className="font-mono text-xs font-black text-amber-400">{phaseShiftDeg.toFixed(1)}°</span>
                        </div>
                        <div className="flex justify-between items-center gap-4">
                          <span className="text-[10px] font-bold text-slate-500 uppercase">Špička (u/i):</span>
                          <span className="font-mono text-[10px] font-black text-slate-300">
                            {tooltip.voltage?.toFixed(0)}V / {tooltip.current && tooltip.current < 1 ? (tooltip.current * 1000).toFixed(0) + 'mA' : tooltip.current?.toFixed(1) + 'A'}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                <p className="mt-8 text-xs text-slate-400 text-center font-medium leading-relaxed max-w-[200px]">
                  {mode === 'AC' 
                    ? "Proud (modrý) předbíhá napětí o 90°."
                    : "Ustálený stav (DC): Proud zaniká, napětí je maximální."}
                </p>
              </motion.div>

              {/* Dynamic Info */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-slate-900 border border-slate-800 p-8 rounded-3xl flex flex-col"
              >
                <h3 className="font-black text-blue-400 mb-6 flex items-center gap-2">
                  <Info size={18} /> FYZIKÁLNÍ JEVY
                </h3>
                
                <div className="space-y-4 flex-grow">
                  <AnimatePresence mode="wait">
                    <motion.div 
                      key={mode}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="space-y-5"
                    >
                      {mode === 'AC' ? (
                        <>
                          <div className="flex gap-3">
                            <div className="mt-1 text-blue-500"><ArrowRight size={14} strokeWidth={3} /></div>
                            <p className="text-sm text-slate-300 font-medium leading-relaxed">
                              Při <span className="text-blue-400">f = {frequency} Hz</span> dochází ke změně polarity {frequency * 2}x za sekundu.
                            </p>
                          </div>
                          <div className="flex gap-3">
                            <div className="mt-1 text-blue-500"><ArrowRight size={14} strokeWidth={3} /></div>
                            <p className="text-sm text-slate-300 font-medium leading-relaxed">
                              Energie se nespotřebovává, pouze se cyklicky ukládá v <span className="text-emerald-400">elektrostatickém poli</span>.
                            </p>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="flex gap-3">
                            <div className="mt-1 text-emerald-500"><ArrowRight size={14} strokeWidth={3} /></div>
                            <p className="text-sm text-slate-300 font-medium leading-relaxed">
                              Po zapnutí teče max. proud, který <span className="text-emerald-400 font-bold italic">exponenciálně klesá</span>.
                            </p>
                          </div>
                          <div className="flex gap-3">
                            <div className="mt-1 text-emerald-500"><ArrowRight size={14} strokeWidth={3} /></div>
                            <p className="text-sm text-slate-300 font-medium leading-relaxed">
                              Nabitý kondenzátor se chová jako <span className="text-red-400 font-bold">přerušený obvod</span>.
                            </p>
                          </div>
                        </>
                      )}
                    </motion.div>
                  </AnimatePresence>
                </div>

                {mode === 'DC' && (
                  <motion.button 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    whileHover={{ scale: 1.02, backgroundColor: '#3b82f6' }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setDcResetTime(Date.now())}
                    className="mt-8 w-full bg-blue-600 text-white font-black py-4 rounded-2xl transition-shadow shadow-[0_10px_20px_-10px_rgba(37,99,235,0.4)] flex items-center justify-center gap-2 uppercase tracking-widest text-xs"
                  >
                    <RefreshCw size={14} strokeWidth={3} /> Resetovat nabíjení
                  </motion.button>
                )}
              </motion.div>
            </div>
          </div>
        </div>

        {/* Theory Section */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-12 space-y-8"
        >
          <div className="flex items-center gap-4 mb-8">
            <div className="h-px bg-slate-800 flex-grow" />
            <h2 className="text-sm uppercase tracking-[0.3em] font-black text-slate-500 whitespace-nowrap flex items-center gap-3">
              <BookOpen size={16} /> Teoretické základy
            </h2>
            <button 
              onClick={() => setShowDoc(true)}
              className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-[10px] font-black uppercase tracking-widest text-blue-400 hover:text-blue-300 hover:border-slate-700 transition-all flex items-center gap-2"
            >
              Podrobná dokumentace <ArrowRight size={12} />
            </button>
            <div className="h-px bg-slate-800 flex-grow" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-slate-400">
            {/* DC Theory */}
            <div className="bg-slate-900/30 border border-slate-800 p-8 rounded-[2.5rem] space-y-6">
              <div className="flex items-center gap-3 text-white">
                <div className="p-2 bg-emerald-500/10 rounded-xl text-emerald-400"><Activity size={20} /></div>
                <h3 className="font-bold">DC - Nabíjení</h3>
              </div>
              <p className="text-sm leading-relaxed">
                V okamžiku připojení ke stejnosměrnému zdroji se kondenzátor začne nabíjet. Proud je limitován pouze odporem rezistoru <span className="text-amber-400">R</span>.
              </p>
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <div className="text-[10px] uppercase font-bold text-slate-500 mb-2">Časová konstanta</div>
                <code className="text-xl font-mono text-emerald-400">τ = R · C</code>
                <p className="text-[10px] mt-2 opacity-50">Určuje rychlost nabíjení (za 5τ je nabito na 99%).</p>
              </div>
            </div>

            {/* AC Theory */}
            <div className="bg-slate-900/30 border border-slate-800 p-8 rounded-[2.5rem] space-y-6">
              <div className="flex items-center gap-3 text-white">
                <div className="p-2 bg-blue-500/10 rounded-xl text-blue-400"><Zap size={20} /></div>
                <h3 className="font-bold">AC - Reaktance</h3>
              </div>
              <p className="text-sm leading-relaxed">
                U střídavého proudu kondenzátor klade odpor neustálým přebíjením. Tento zdánlivý odpor nazýváme <span className="text-blue-400">kapacitní reaktance</span>.
              </p>
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <div className="text-[10px] uppercase font-bold text-slate-500 mb-2">Reaktance Xc</div>
                <code className="text-xl font-mono text-blue-400">X<sub>C</sub> = 1 / (2π f C)</code>
                <p className="text-[10px] mt-2 opacity-50">Čím vyšší frekvence, tím menší odpor kondenzátor klade.</p>
              </div>
            </div>

            {/* Phase Theory */}
            <div className="bg-slate-900/30 border border-slate-800 p-8 rounded-[2.5rem] space-y-6">
              <div className="flex items-center gap-3 text-white">
                <div className="p-2 bg-amber-500/10 rounded-xl text-amber-400"><Calculator size={20} /></div>
                <h3 className="font-bold">Impedance a Fáze</h3>
              </div>
              <p className="text-sm leading-relaxed">
                V sériovém zapojení R-C se odpory nesčítají aritmeticky, ale vektorově. Proud v kondenzátoru napětí <span className="text-red-400">předbíhá</span>.
              </p>
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <div className="text-[10px] uppercase font-bold text-slate-500 mb-2">Impedance Z</div>
                <code className="text-xl font-mono text-white">Z = √(R² + X<sub>C</sub>²)</code>
                <p className="text-[10px] mt-2 opacity-50">Výsledný odpor celého obvodu.</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
      
      {/* Background Decor */}
      <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
        <div className="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-blue-500/5 blur-[120px] rounded-full" />
        <div className="absolute -bottom-[10%] -right-[10%] w-[40%] h-[40%] bg-emerald-500/5 blur-[120px] rounded-full" />
      </div>
    </div>
  );
}
