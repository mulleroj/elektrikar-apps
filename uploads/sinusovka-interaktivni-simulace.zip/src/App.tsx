/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { 
  Pause, 
  Play, 
  Zap, 
  RotateCw, 
  Activity, 
  Info, 
  ChevronRight,
  MousePointer2,
  Share2,
  X,
  Copy,
  Check,
  BookOpen
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeCanvas } from 'qrcode.react';

// Types
interface Point {
  x: number;
  y: number;
}

const MAX_HISTORY = 400;

function TooltipLabel({ label, info }: { label: string, info: string }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="relative flex items-center gap-1 mb-2 group cursor-help"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="text-[10px] uppercase text-white/50 tracking-[1px] transition-colors group-hover:text-accent">
        {label}
      </div>
      <Info size={10} className="text-white/20 group-hover:text-accent transition-colors" />
      
      <AnimatePresence>
        {isHovered && (
          <motion.div
            initial={{ opacity: 0, y: 5, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 5, scale: 0.95 }}
            className="absolute bottom-full left-0 mb-2 w-48 z-50 glass-panel p-3 text-[11px] leading-snug text-white/90 shadow-2xl border-accent/20 bg-[#1a1c2c]/90"
          >
            <div className="text-accent font-bold mb-1 uppercase tracking-tighter text-[9px]">Detail parametru</div>
            {info}
            <div className="absolute top-full left-4 w-2 h-2 bg-accent/20 border-r border-b border-white/10 rotate-45 -translate-y-1" />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function App() {
  // State
  const [isRunning, setIsRunning] = useState(true);
  const [speed, setSpeed] = useState(0.015);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [currentStats, setCurrentStats] = useState({
    angle: 0,
    voltage: 0,
    quadrant: 'I.',
    phase: '-',
    explanation: 'Pohybujte jezdcem pro start simulace.'
  });

  // Refs for drawing
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);
  const animationRef = useRef<number>(null);
  const lastStateUpdateRef = useRef<number>(0);
  const angleRef = useRef(0);
  const historyRef = useRef<number[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  const speedRef = useRef(0.015);
  const isRunningRef = useRef(true);

  // Sync refs with state
  useEffect(() => {
    speedRef.current = speed;
  }, [speed]);

  useEffect(() => {
    isRunningRef.current = isRunning;
  }, [isRunning]);

  // Helper functions ... (rest unchanged)

  // Helper functions
  const getExplanation = (deg: number) => {
    if (deg >= 350 || deg <= 10) return "Nulový bod: Vodič klouže po siločárách. Žádné magnetické pole není protínáno.";
    if (deg > 10 && deg < 80) return "Nárůst: Úhel pohybu se blíží k 90°. Napětí plynule stoupá.";
    if (deg >= 80 && deg <= 100) return "Maximum: Vodič krájí pole kolmo. Sin(90°)=1, napětí dosahuje vrcholu.";
    if (deg > 100 && deg < 170) return "Pokles: Úhel se zmenšuje, indukované napětí klesá k nule.";
    if (deg >= 170 && deg <= 190) return "Obrat: Napětí prochází nulou a mění polaritu.";
    return "Fázový posun: Vodič se vrací do výchozí polohy v záporné půlvlně.";
  };

  const updateSimulationState = useCallback((rad: number) => {
    const deg = ((rad * 180 / Math.PI) % 360 + 360) % 360;
    const voltage = Math.sin(rad);
    
    let quad = "I.";
    let ph = "-";
    if (deg < 90) { quad = "I."; ph = "Kladná ↑"; }
    else if (deg < 180) { quad = "II."; ph = "Kladná ↓"; }
    else if (deg < 270) { quad = "III."; ph = "Záporná ↑"; }
    else { quad = "IV."; ph = "Záporná ↓"; }

    setCurrentStats({
      angle: Math.round(deg),
      voltage: parseFloat(voltage.toFixed(2)),
      quadrant: quad,
      phase: ph,
      explanation: getExplanation(deg)
    });
  }, []);

  const handleManualAngleChange = (newDeg: number) => {
    const rad = (newDeg * Math.PI) / 180;
    angleRef.current = rad;
    updateSimulationState(rad);
  };

  const handleManualVoltageChange = (newV: number) => {
    // Amplitude is 230
    const ratio = Math.max(-1, Math.min(1, newV / 230));
    const rad = Math.asin(ratio);
    angleRef.current = rad;
    updateSimulationState(rad);
  };

  const handleManualQuadrantChange = (q: string) => {
    let deg = 0;
    if (q === "I.") deg = 0;
    else if (q === "II.") deg = 90;
    else if (q === "III.") deg = 180;
    else if (q === "IV.") deg = 270;
    
    const rad = (deg * Math.PI) / 180;
    angleRef.current = rad;
    updateSimulationState(rad);
  };

  const drawGenerator = (ctx: CanvasRenderingContext2D, x: number, y: number, radius: number, currentAngle: number) => {
    // Magnetic pole blocks - scaled to radius
    const poleW = 60;
    const poleH = radius * 2.2;
    const poleOffset = radius + 20;

    // North (Red)
    const northGrad = ctx.createLinearGradient(x - poleOffset - poleW, y - poleH/2, x - poleOffset, y - poleH/2);
    northGrad.addColorStop(0, 'rgba(255, 75, 92, 0.2)');
    northGrad.addColorStop(1, 'rgba(255, 75, 92, 0.1)');
    ctx.fillStyle = northGrad;
    ctx.fillRect(x - poleOffset - poleW, y - poleH/2, poleW, poleH);
    ctx.strokeStyle = 'rgba(255, 75, 92, 0.4)';
    ctx.strokeRect(x - poleOffset - poleW, y - poleH/2, poleW, poleH);

    // South (Blue)
    const southGrad = ctx.createLinearGradient(x + poleOffset, y - poleH/2, x + poleOffset + poleW, y - poleH/2);
    southGrad.addColorStop(0, 'rgba(30, 144, 255, 0.1)');
    southGrad.addColorStop(1, 'rgba(30, 144, 255, 0.2)');
    ctx.fillStyle = southGrad;
    ctx.fillRect(x + poleOffset, y - poleH/2, poleW, poleH);
    ctx.strokeStyle = 'rgba(30, 144, 255, 0.4)';
    ctx.strokeRect(x + poleOffset, y - poleH/2, poleW, poleH);

    // Labels
    ctx.textAlign = 'center';
    ctx.font = 'bold 14px JetBrains Mono';
    ctx.fillStyle = '#ff4b5c';
    ctx.fillText('N', x - poleOffset - poleW/2, y - poleH/2 - 10);
    ctx.fillStyle = '#1e90ff';
    ctx.fillText('S', x + poleOffset + poleW/2, y - poleH/2 - 10);

    // Magnetic flux lines with interaction
    ctx.setLineDash([5, 5]);
    ctx.lineWidth = 1;
    for(let i = -(poleH/2 - 10); i <= (poleH/2 - 10); i += 20) {
      const distToRotor = Math.abs(i - Math.sin(currentAngle) * radius);
      const intensity = Math.max(0.05, 0.2 - distToRotor / 200);
      ctx.strokeStyle = `rgba(255,255,255,${intensity})`;
      ctx.beginPath();
      ctx.moveTo(x - poleOffset, y + i);
      ctx.lineTo(x + poleOffset, y + i);
      ctx.stroke();
    }
    ctx.setLineDash([]);

    // Rotation path
    ctx.strokeStyle = 'rgba(255,255,255,0.05)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.stroke();

    // Motion Trail (Ghosting)
    if (isRunningRef.current) {
      for (let i = 1; i <= 5; i++) {
        const trailAngle = currentAngle - i * (speedRef.current * 0.8);
        const tx = x + Math.cos(trailAngle) * radius;
        const ty = y + Math.sin(trailAngle) * radius;
        ctx.fillStyle = `rgba(0, 242, 255, ${0.15 / i})`;
        ctx.beginPath();
        ctx.arc(tx, ty, 6 - i, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // The conductor (rotor)
    const ex = x + Math.cos(currentAngle) * radius;
    const ey = y + Math.sin(currentAngle) * radius;

    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(255,255,255,0.3)';
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(ex, ey);
    ctx.stroke();

    // Conductor point with glow
    const conductorGrad = ctx.createRadialGradient(ex, ey, 0, ex, ey, 15);
    conductorGrad.addColorStop(0, '#00f2ff');
    conductorGrad.addColorStop(0.4, 'rgba(0, 242, 255, 0.4)');
    conductorGrad.addColorStop(1, 'rgba(0, 242, 255, 0)');
    
    ctx.fillStyle = conductorGrad;
    ctx.beginPath();
    ctx.arc(ex, ey, 15, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(ex, ey, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#00f2ff';
    ctx.lineWidth = 2;
    ctx.stroke();
  };

  const drawGraph = (ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number) => {
    // Axis lines
    ctx.strokeStyle = 'rgba(255,255,255,0.2)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + width, y);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(x, y - height / 2);
    ctx.lineTo(x, y + height / 2);
    ctx.stroke();

    // Waveform
    if (historyRef.current.length > 0) {
      ctx.strokeStyle = '#00f2ff';
      ctx.lineWidth = 3;
      ctx.beginPath();
      
      for(let i = 0; i < historyRef.current.length; i++) {
        const px = x + i;
        const py = y - historyRef.current[i] * (height / 2.5);
        if(i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.stroke();
      
      // Active point
      const lastVal = historyRef.current[historyRef.current.length - 1];
      const dotX = x + historyRef.current.length - 1;
      const dotY = y - lastVal * (height / 2.5);
      
      ctx.fillStyle = '#00f2ff';
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#00f2ff';
      ctx.beginPath();
      ctx.arc(dotX, dotY, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }
  };

  const render = (time: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    if (!ctxRef.current) {
      ctxRef.current = canvas.getContext('2d');
    }
    const ctx = ctxRef.current;
    if (!ctx) return;

    // Scale for DPR handle
    const dpr = window.devicePixelRatio || 1;
    const displayWidth = canvas.width / dpr;
    const displayHeight = canvas.height / dpr;

    const isMobile = displayWidth < 768;
    
    // Dynamic sizing based on height
    const drawScale = Math.min(1.2, displayHeight / 300);
    const radius = 80 * drawScale;
    
    const cx = isMobile ? displayWidth / 2 : radius + 80;
    const cy = displayHeight / 2;
    
    const gx = isMobile ? 50 : cx + radius + 80;
    const gy = cy;
    const gw = isMobile ? displayWidth - 100 : displayWidth - gx - 60;
    const gh = Math.min(200, displayHeight * 0.6);

    if (isRunningRef.current) {
      angleRef.current += speedRef.current;
      historyRef.current.push(Math.sin(angleRef.current));
      
      const maxHistory = Math.floor(gw); 
      if (historyRef.current.length > maxHistory) {
        historyRef.current.shift();
      }
    }

    // Drawing
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    drawGenerator(ctx, cx, cy, radius, angleRef.current);
    drawGraph(ctx, gx, gy, gw, gh);

    // Throttle UI state updates to reduce React overhead (every ~100ms)
    if (time - lastStateUpdateRef.current > 100) {
      updateSimulationState(angleRef.current);
      lastStateUpdateRef.current = time;
    }

    animationRef.current = requestAnimationFrame(render);
  };

  useEffect(() => {
    animationRef.current = requestAnimationFrame(render);
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current && canvasRef.current) {
        const dpr = window.devicePixelRatio || 1;
        const rect = containerRef.current.getBoundingClientRect();
        
        canvasRef.current.width = rect.width * dpr;
        canvasRef.current.height = rect.height * dpr;
        
        if (ctxRef.current) {
          ctxRef.current.scale(dpr, dpr);
        }
        
        // Update regular display size
        canvasRef.current.style.width = `${rect.width}px`;
        canvasRef.current.style.height = `${rect.height}px`;
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const shareUrl = typeof window !== 'undefined' ? window.location.href : '';

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-[1200px] mx-auto min-h-screen flex flex-col font-sans">
      <header className="py-6 px-10 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-[2px] m-0">
              SINE GEN <span className="font-light opacity-60">v1.1</span>
            </h1>
            <p className="text-[12px] opacity-50 m-0">Interaktivní simulace elektromagnetické indukce</p>
          </div>
          <button 
            onClick={() => setIsShareModalOpen(true)}
            className="glass-panel p-2 hover:bg-white/10 transition-colors text-accent/70 hover:text-accent cursor-pointer border-white/10"
            title="Sdílet se studenty"
          >
            <Share2 size={18} />
          </button>
        </div>
        <div className="glass-panel py-2 px-5 font-mono text-lg text-accent">
          U<sub>i</sub> = B · l · v · sin(α)
        </div>
      </header>

      <main className="flex-1 grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-5 px-6 md:px-10 pb-10">
        {/* Sidebar */}
        <div className="flex flex-col gap-5">
          {/* Params Panel */}
          <section className="glass-panel p-5 text-white">
            <h2 className="text-[14px] font-bold border-b border-white/15 pb-2 mb-4 tracking-wider uppercase">Parametry</h2>
            <div className="flex flex-col gap-6">
              <div className="group">
                <TooltipLabel 
                  label="Úhel (α)" 
                  info="Úhel mezi směrem pohybu vodiče a magnetickými siločárami. Určuje, jak efektivně vodič 'krájí' pole." 
                />
                <input 
                  type="number" 
                  value={currentStats.angle} 
                  onChange={(e) => handleManualAngleChange(Number(e.target.value))}
                  className="bg-transparent border-b border-transparent focus:border-accent/40 focus:bg-white/5 rounded-t-lg px-2 -mx-2 transition-all text-2xl font-light text-accent stat-glow w-full outline-none"
                />
                <div className="text-[9px] text-white/30 uppercase mt-1">Stupně [0-360°]</div>
              </div>

              <div className="group">
                <TooltipLabel 
                  label="Napětí (Ui)" 
                  info="Okamžitá hodnota napětí (Ui). Vypočítá se jako průmět rotačního pohybu do vertikální osy (Umax * sin α)." 
                />
                <div className="flex items-baseline gap-1 bg-transparent border-b border-transparent focus-within:border-accent/40 focus-within:bg-white/5 rounded-t-lg px-2 -mx-2 transition-all">
                  <input 
                    type="number" 
                    step="0.1"
                    value={(currentStats.voltage * 230).toFixed(1)} 
                    onChange={(e) => handleManualVoltageChange(Number(e.target.value))}
                    className="bg-transparent border-none text-2xl font-light text-accent stat-glow w-24 outline-none focus:ring-0"
                  />
                  <span className="text-accent text-sm font-light">V</span>
                </div>
                <div className="text-[9px] text-white/30 uppercase mt-1">Vypočteno pro 230V peak</div>
              </div>

              <div className="group">
                <TooltipLabel 
                  label="Kvadrant" 
                  info="Aktuální fáze periody. Každý kvadrant (90°) reprezentuje jinou kombinaci směru pohybu a polarity napětí." 
                />
                <select 
                  value={currentStats.quadrant}
                  onChange={(e) => handleManualQuadrantChange(e.target.value)}
                  className="bg-transparent border-b border-transparent focus:border-accent/40 focus:bg-white/5 rounded-t-lg px-2 -mx-2 transition-all text-2xl font-light text-accent stat-glow w-full outline-none appearance-none cursor-pointer"
                >
                  <option value="I." className="bg-[#1a1c2c]">I. Kvadrant</option>
                  <option value="II." className="bg-[#1a1c2c]">II. Kvadrant</option>
                  <option value="III." className="bg-[#1a1c2c]">III. Kvadrant</option>
                  <option value="IV." className="bg-[#1a1c2c]">IV. Kvadrant</option>
                </select>
                <div className="text-[9px] text-white/30 uppercase mt-1">Zvolte fázi cyklu</div>
              </div>
            </div>
          </section>

          {/* Explanation Panel */}
          <section className="glass-panel p-5 flex-1 min-h-[120px]">
            <h2 className="text-[14px] font-bold mb-3 tracking-wider uppercase">Popis stavu</h2>
            <AnimatePresence mode="wait">
              <motion.p
                key={currentStats.explanation}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.02 }}
                transition={{ 
                  duration: 0.5,
                  ease: "easeInOut"
                }}
                className="text-[13px] leading-relaxed text-white/80 m-0 italic"
              >
                {currentStats.explanation}
              </motion.p>
            </AnimatePresence>
          </section>

          {/* Controls Panel */}
          <section className="glass-panel p-5">
            <div className="mb-4">
              <div className="text-[10px] uppercase text-white/50 tracking-wider mb-2">Rychlost / Frekvence</div>
              <input 
                type="range" 
                min="0" 
                max="0.05" 
                step="0.001" 
                value={speed} 
                onChange={(e) => setSpeed(parseFloat(e.target.value))}
                className="w-full"
              />
            </div>
            <button 
              onClick={() => setIsRunning(!isRunning)}
              className="w-full bg-accent text-slate-900 border-none py-3 px-6 rounded-lg font-bold cursor-pointer uppercase tracking-[1px] text-[12px] hover:brightness-110 active:scale-95 transition-all shadow-[0_0_15px_rgba(0,242,255,0.3)]"
            >
              {isRunning ? 'Stop' : 'Start'} Simulace
            </button>
          </section>
        </div>

        {/* Main Content */}
        <div className="flex flex-col gap-5">
          {/* Canvas Panel */}
          <div ref={containerRef} className="glass-panel flex-1 relative p-0 overflow-hidden min-h-[300px] md:min-h-0 bg-white/[0.02]">
            <div className="absolute top-4 left-6 z-10 flex items-center gap-2 pointer-events-none opacity-40">
              <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
              <span className="text-[9px] font-bold uppercase tracking-[2px]">Osciloskop</span>
            </div>
            <canvas ref={canvasRef} className="w-full h-full" />
          </div>

          {/* Insight Panel */}
          <div className="glass-panel px-6 py-4 flex items-center gap-5 bg-accent/5 border-accent/20">
            <div className="text-2xl">💡</div>
            <div className="text-[13px] opacity-90 leading-normal">
              <strong>Poznámka:</strong> Maximální indukované napětí nastává v okamžiku, kdy vodič protíná magnetické siločáry pod úhlem 90°. V této poloze je efektivita přenosu energie nejvyšší.
            </div>
          </div>
        </div>
      </main>

      {/* Expanded Theory Section */}
      <section className="px-6 md:px-10 pb-10">
        <div className="glass-panel p-8 bg-white/[0.01]">
          <div className="flex items-center gap-3 mb-8 border-b border-white/10 pb-4">
            <BookOpen className="text-accent" size={24} />
            <h2 className="text-2xl font-bold tracking-tight">Hlubší teoretický pohled</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div>
              <h3 className="text-orange-400 font-bold mb-3 flex items-center gap-2">
                <Zap size={16} /> Elektromagnetická indukce
              </h3>
              <p className="text-sm text-white/70 leading-relaxed">
                Tento jev poprvé popsal <strong>Michael Faraday</strong> v roce 1831. Základní myšlenka je jednoduchá: pokud se vodič pohybuje v magnetickém poli tak, že protíná magnetické siločáry, na jeho koncích se indukuje elektrické napětí. 
                <br /><br />
                V našem generátoru je zdrojem pole statický magnet (vnější čtverce N a S) a pohyb zajišťuje rotující smyčka (rotor).
              </p>
            </div>

            <div>
              <h3 className="text-blue-400 font-bold mb-3 flex items-center gap-2">
                <RotateCw size={16} /> Proč právě SINUS?
              </h3>
              <p className="text-sm text-white/70 leading-relaxed">
                Vodič se v generátoru nepohybuje přímočaře, ale po kružnici. Pro indukci napětí je důležitá pouze ta složka pohybu, která je <strong>kolmá</strong> na magnetické siločáry.
                <br /><br />
                Při rotaci se tento kolmý průmět neustále mění podle goniometrické funkce sinus. Zatímco úhel narůstá lineárně s časem, indukované napětí kopíruje výšku průmětu vodiče do svislé osy, což vytváří charakteristickou vlnovku.
              </p>
            </div>

            <div>
              <h3 className="text-emerald-400 font-bold mb-3 flex items-center gap-2">
                <Activity size={16} /> Klíčové body cyklu
              </h3>
              <ul className="text-sm text-white/70 space-y-3">
                <li><span className="text-white font-semibold">0° (Nulový bod):</span> Vodič se pohybuje rovnoběžně se siločárami. Žádné protínání = nulové napětí.</li>
                <li><span className="text-white font-semibold">90° (Kladné maximum):</span> Vodič prořezává pole přesně kolmo. Nejvyšší efektivita indukce.</li>
                <li><span className="text-white font-semibold">180°:</span> Opět rovnoběžný pohyb, napětí prochází nulou a mění polaritu.</li>
                <li><span className="text-white font-semibold">270° (Záporné maximum):</span> Vodič krájí pole kolmo, ale v opačném směru vzhledem k siločárám.</li>
              </ul>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex gap-4">
              <div className="px-3 py-1 bg-white/5 rounded-full text-[10px] uppercase font-bold tracking-widest text-white/40 border border-white/5">Faradayův zákon</div>
              <div className="px-3 py-1 bg-white/5 rounded-full text-[10px] uppercase font-bold tracking-widest text-white/40 border border-white/5">Lenzovo pravidlo</div>
              <div className="px-3 py-1 bg-white/5 rounded-full text-[10px] uppercase font-bold tracking-widest text-white/40 border border-white/5">Vektorová fyzika</div>
            </div>
            <p className="text-[11px] text-white/30 italic">Tento model simuluje ideální generátor bez ztrát a vířivých proudů.</p>
          </div>
        </div>
      </section>

      <footer className="py-6 text-center text-white/20 text-[10px] uppercase tracking-widest">
        Design System: Frosted Glass UI • Sine Gen v1.1
      </footer>

      {/* Share Modal */}
      <AnimatePresence>
        {isShareModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsShareModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="glass-panel w-full max-w-sm relative z-10 p-8 flex flex-col items-center bg-[#1a1c2c]/95 border-accent/20"
            >
              <button 
                onClick={() => setIsShareModalOpen(false)}
                className="absolute top-4 right-4 text-white/40 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>

              <h2 className="text-xl font-bold mb-2 tracking-wide text-accent bg-clip-text">Sdílet simulaci</h2>
              <p className="text-white/60 text-sm mb-6 text-center">Naskenujte QR kód pro rychlý přístup na mobilu nebo tabletu.</p>

              <div className="bg-white p-3 rounded-xl mb-6 shadow-[0_0_20px_rgba(0,242,255,0.2)]">
                <QRCodeCanvas 
                  value={shareUrl} 
                  size={180}
                  level="H"
                  includeMargin={false}
                  imageSettings={{
                    src: "https://www.google.com/favicon.ico", // Placeholder logo or small icon
                    x: undefined,
                    y: undefined,
                    height: 24,
                    width: 24,
                    excavate: true,
                  }}
                />
              </div>

              <div className="w-full space-y-3">
                <div className="glass-panel bg-white/5 border-white/10 p-3 rounded-lg flex items-center justify-between gap-3">
                  <div className="truncate text-[10px] opacity-40 font-mono select-all">
                    {shareUrl}
                  </div>
                  <button 
                    onClick={copyToClipboard}
                    className="p-2 hover:bg-white/10 rounded transition-colors text-accent shrink-0"
                  >
                    {copied ? <Check size={16} /> : <Copy size={16} />}
                  </button>
                </div>
                
                <button 
                  onClick={() => setIsShareModalOpen(false)}
                  className="w-full py-3 text-xs font-bold uppercase tracking-widest text-white/40 hover:text-white transition-colors"
                >
                  Zavřít
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
