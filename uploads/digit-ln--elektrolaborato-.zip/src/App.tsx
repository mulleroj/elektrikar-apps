/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { 
  Zap, 
  Settings, 
  CheckCircle2, 
  Info, 
  Cpu, 
  Waves,
  HelpCircle,
  XCircle,
  RefreshCw,
  Trophy,
  Share2,
  QrCode,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeCanvas } from 'qrcode.react';

import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';

const MATERIAL_COLORS = {
  copper: {
    hex: '#F59E0B',
    tailwind: 'bg-amber-500',
    name: 'Měď (Cu)'
  },
  aluminum: {
    hex: '#94A3B8',
    tailwind: 'bg-slate-400',
    name: 'Hliník (Al)'
  }
};

const App = () => {
  const [activeTab, setActiveTab] = useState('dc_basics');
  const [score, setScore] = useState(0);
  const [scoreHistory, setScoreHistory] = useState<{time: string, score: number}[]>([]);
  const [showQr, setShowQr] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  
  // --- STAVY PRO SIMULÁTOR ---
  const [simValues, setSimValues] = useState({
    length: 50,
    crossSection: 2.5,
    material: 0.0178,
    current: 16,
    pOut: 1500,
    pIn: 1800,
    hours: 2,
    iAc: 10,
    cosPhi: 0.8,
    isThreePhase: false
  });

  // --- STAVY PRO GENERÁTOR ÚKOLŮ ---
  const [currentQuiz, setCurrentQuiz] = useState<any>(null);
  const [userAnswer, setUserAnswer] = useState("");
  const [feedback, setFeedback] = useState<any>(null);

  // --- VÝPOČTY PRO SIMULÁTOR ---
  const resSim = (simValues.material * simValues.length / simValues.crossSection).toFixed(4);
  const dropSim = (Number(resSim) * simValues.current * 2).toFixed(2);
  const effSim = ((simValues.pOut / simValues.pIn) * 100).toFixed(1);
  const workSim = (simValues.pIn * simValues.hours / 1000).toFixed(2);
  
  const factor = simValues.isThreePhase ? Math.sqrt(3) : 1;
  const sSim = ((simValues.isThreePhase ? 400 : 230) * simValues.iAc * factor).toFixed(1);
  const pSim = (Number(sSim) * simValues.cosPhi).toFixed(1);
  const qSim = (Number(sSim) * Math.sin(Math.acos(simValues.cosPhi))).toFixed(1);

  // --- GENERÁTOR ÚKOLŮ ---
  const generateNewQuiz = useCallback((tab: string) => {
    setUserAnswer("");
    setFeedback(null);
    
    const mats = [{n: "měděného", v: 0.0178}, {n: "hliníkového", v: 0.028}];
    const sections = [1.5, 2.5, 4, 6, 10, 16];
    
    let quiz: any = {};

    if (tab === 'dc_basics') {
      const m = mats[Math.floor(Math.random() * mats.length)];
      const s = sections[Math.floor(Math.random() * sections.length)];
      const l = Math.floor(Math.random() * 150) + 10;
      const r = (m.v * l / s).toFixed(3);
      
      const type = Math.random() > 0.5 ? 'R' : 'U';
      if (type === 'R') {
        quiz = {
          title: "Výpočet odporu",
          q: `Vypočítejte odpor ${m.n} vodiče o délce ${l} m a průřezu ${s} mm².`,
          ans: r,
          unit: "Ω"
        };
      } else {
        const i = [2, 6, 10, 16, 25][Math.floor(Math.random() * 5)];
        const u = (Number(r) * i * 2).toFixed(2);
        quiz = {
          title: "Úbytek napětí",
          q: `Jaký bude úbytek napětí na ${m.n}m vedení (${m.n} vodič, ${s} mm²) o délce ${l} m, pokud jím protéká proud ${i} A? (Počítejte 1-fázové vedení, tedy tam i zpět).`,
          ans: u,
          unit: "V"
        };
      }
    } else if (tab === 'eff_work') {
      const p1 = Math.floor(Math.random() * 5000) + 500;
      const type = Math.random() > 0.5 ? 'EFF' : 'W';
      
      if (type === 'EFF') {
        const eff = 0.7 + Math.random() * 0.25;
        const p2 = Math.round(p1 * eff);
        quiz = {
          title: "Výpočet účinnosti",
          q: `Elektromotor má příkon P₀ = ${p1} W a užitečný výkon na hřídeli P = ${p2} W. Vypočítejte jeho účinnost η v procentech.`,
          ans: ((p2/p1)*100).toFixed(1),
          unit: "%"
        };
      } else {
        const t = Math.floor(Math.random() * 10) + 1;
        quiz = {
          title: "Elektrická práce",
          q: `Spotřebič s příkonem ${p1} W byl v provozu ${t} hodiny. Kolik kWh elektrické energie (práce W) spotřeboval?`,
          ans: (p1 * t / 1000).toFixed(2),
          unit: "kWh"
        };
      }
    } else {
      const u = Math.random() > 0.5 ? 230 : 400;
      const i = Math.floor(Math.random() * 20) + 2;
      const cos = (0.7 + Math.random() * 0.29).toFixed(2);
      
      if (u === 230) {
        quiz = {
          title: "1-fázový činný výkon",
          q: `Vypočítejte činný výkon P jednofázového spotřebiče (U=230V), kterým protéká proud ${i} A při účiníku cos φ = ${cos}.`,
          ans: (230 * i * Number(cos)).toFixed(1),
          unit: "W"
        };
      } else {
        quiz = {
          title: "3-fázový činný výkon",
          q: `Vypočítejte činný výkon P třífázového motoru (U=400V), kterým protéká proud ${i} A při účiníku cos φ = ${cos}. (Použijte √3 ≈ 1.732)`,
          ans: (Math.sqrt(3) * 400 * i * Number(cos)).toFixed(1),
          unit: "W"
        };
      }
    }
    setCurrentQuiz(quiz);
  }, []);

  useEffect(() => {
    generateNewQuiz(activeTab);
  }, [activeTab, generateNewQuiz]);

  const checkAnswer = () => {
    const userNum = parseFloat(userAnswer.replace(',', '.'));
    const correctNum = parseFloat(currentQuiz.ans);
    const tolerance = Math.abs(correctNum * 0.02); // 2% tolerance

    if (Math.abs(userNum - correctNum) <= tolerance) {
      setFeedback({ status: 'success', msg: `Správně! Přesný výsledek je ${correctNum} ${currentQuiz.unit}.` });
      setScore(s => {
        const newScore = s + 1;
        setScoreHistory(prev => [...prev, { 
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }), 
          score: newScore 
        }]);
        return newScore;
      });
    } else {
      setFeedback({ status: 'error', msg: `Zkus to znovu. Správný výsledek je ${correctNum} ${currentQuiz.unit}.` });
    }
  };

  const getMaterialInfo = (value: number) => {
    return value === 0.0178 ? MATERIAL_COLORS.copper : MATERIAL_COLORS.aluminum;
  };

  const currentMaterial = getMaterialInfo(simValues.material);
  const appUrl = window.location.href;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 p-4 md:p-8 text-slate-900 dark:text-slate-100 font-sans">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-center md:text-left">
            <h1 className="text-3xl md:text-4xl font-black text-slate-800 dark:text-white tracking-tight">
              Digitální <span className="text-blue-600">Elektrolaboratoř</span>
            </h1>
            <p className="text-slate-500 font-medium italic">Intenzivní trénink pro budoucí mistry</p>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowHelp(true)}
              className="flex items-center gap-2 bg-white dark:bg-slate-800 px-4 py-2 rounded-xl shadow-sm border border-slate-200 hover:border-blue-400 transition-colors"
            >
              <HelpCircle size={18} className="text-blue-600" />
              <span className="text-sm font-bold">Nápověda</span>
            </button>
            <button 
              onClick={() => setShowQr(true)}
              className="flex items-center gap-2 bg-white dark:bg-slate-800 px-4 py-2 rounded-xl shadow-sm border border-slate-200 hover:border-blue-400 transition-colors"
            >
              <Share2 size={18} className="text-blue-600" />
              <span className="text-sm font-bold">Sdílet</span>
            </button>
            <div className="bg-white dark:bg-slate-800 px-6 py-3 rounded-2xl shadow-md border border-slate-200 flex items-center gap-3">
              <Trophy className="text-amber-500" />
              <div>
                <p className="text-[10px] font-black uppercase text-slate-400">Tvé skóre</p>
                <p className="text-xl font-black text-blue-600">{score} bodů</p>
              </div>
            </div>
          </div>
        </header>

        {/* Help Modal */}
        {showHelp && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-2xl max-w-2xl w-full relative animate-in zoom-in duration-200 overflow-y-auto max-h-[90vh]">
              <button 
                onClick={() => setShowHelp(false)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X size={24} />
              </button>
              <div className="space-y-6">
                <div className="flex items-center gap-3">
                  <div className="bg-blue-600 p-3 rounded-2xl">
                    <HelpCircle size={32} className="text-white" />
                  </div>
                  <h2 className="text-2xl font-black">Nápověda a instrukce</h2>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-black text-blue-600 uppercase text-xs tracking-widest">Jak používat simulátor</h3>
                    <p className="text-sm text-slate-500 leading-relaxed">
                      V levém panelu můžete měnit parametry elektrických obvodů pomocí posuvníků. Výsledky výpočtů (odpor, úbytek napětí, účinnost atd.) se okamžitě zobrazují v horní části panelu.
                    </p>
                  </div>
                  <div className="space-y-4">
                    <h3 className="font-black text-blue-600 uppercase text-xs tracking-widest">Procvičování úkolů</h3>
                    <p className="text-sm text-slate-500 leading-relaxed">
                      V pravém panelu se generují náhodné příklady. Zadejte výsledek a stiskněte "Odeslat". Tolerance pro uznání správnosti je 2 % (kvůli zaokrouhlování).
                    </p>
                  </div>
                  <div className="space-y-4">
                    <h3 className="font-black text-blue-600 uppercase text-xs tracking-widest">Důležité jednotky</h3>
                    <ul className="text-sm text-slate-500 list-disc list-inside space-y-1">
                      <li>Průřez vodiče: <strong>mm²</strong></li>
                      <li>Měrný odpor (ρ): <strong>Ω·mm²/m</strong></li>
                      <li>Elektrická práce: <strong>kWh</strong></li>
                      <li>Výkon: <strong>W</strong> nebo <strong>kW</strong></li>
                    </ul>
                  </div>
                  <div className="space-y-4">
                    <h3 className="font-black text-blue-600 uppercase text-xs tracking-widest">Tipy pro výpočet</h3>
                    <p className="text-sm text-slate-500 leading-relaxed">
                      U úbytku napětí v 1-fázovém vedení nezapomeňte, že proud teče tam i zpět (délka se násobí dvěma). U 3-fázových výkonů používejte odmocninu ze tří (√3 ≈ 1.732).
                    </p>
                  </div>
                  <div className="space-y-4">
                    <h3 className="font-black text-blue-600 uppercase text-xs tracking-widest">Účinnost a ztráty</h3>
                    <div className="text-sm text-slate-500 space-y-3 leading-relaxed">
                      <p>
                        Ztrátový výkon vypočítáte jako rozdíl příkonu a výkonu: <strong>P<sub>ztráta</sub> = P<sub>0</sub> - P</strong>.
                      </p>
                      <ul className="list-none space-y-2">
                        <li>
                          <strong className="text-slate-700">P<sub>0</sub> (Příkon):</strong> Celkový elektrický výkon odebíraný ze sítě. V simulátoru určuje množství energie vstupující do stroje.
                        </li>
                        <li>
                          <strong className="text-slate-700">P (Výkon):</strong> Užitečný výkon, který stroj skutečně odevzdá (např. mechanická práce na hřídeli).
                        </li>
                      </ul>
                      <p className="italic bg-orange-50 dark:bg-orange-950/30 p-3 rounded-xl border border-orange-100 dark:border-orange-900/50">
                        <strong>Vliv na vizualizaci:</strong> Rozdíl mezi těmito hodnotami určuje intenzitu <strong>oranžové záře</strong> kolem motoru. Čím větší jsou ztráty, tím intenzivněji motor „topí“, což simuluje reálné zahřívání stroje vlivem neúčinnosti.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-black text-blue-600 uppercase text-xs tracking-widest">Výkony v AC obvodech</h3>
                    <div className="text-sm text-slate-500 space-y-3 leading-relaxed">
                      <p>V obvodech střídavého proudu rozlišujeme tři typy výkonů:</p>
                      <ul className="list-none space-y-2">
                        <li>
                          <strong className="text-slate-700">P - Činný výkon [W]:</strong> Skutečně vykonaná práce (teplo, pohyb). Je to výkon, který platíme.
                        </li>
                        <li>
                          <strong className="text-slate-700">Q - Jalový výkon [var]:</strong> Energie potřebná pro vytvoření magnetických polí (motory, tlumivky). Nekoná práci, jen kmitá mezi zdrojem a zátěží.
                        </li>
                        <li>
                          <strong className="text-slate-700">S - Zdánlivý výkon [VA]:</strong> Celkový výkon, který musí přenést vodiče a transformátory.
                        </li>
                      </ul>
                      <p className="text-xs font-bold text-blue-600 bg-blue-50 dark:bg-blue-950/30 p-2 rounded-lg inline-block">
                        Vztah: S = √(P² + Q²)
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100 dark:border-slate-800">
                  <button 
                    onClick={() => setShowHelp(false)}
                    className="w-full py-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-2xl font-black transition-colors"
                  >
                    Rozumím, jdeme na to!
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* QR Code Modal */}
        {showQr && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-2xl max-w-sm w-full relative animate-in zoom-in duration-200">
              <button 
                onClick={() => setShowQr(false)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X size={24} />
              </button>
              <div className="text-center space-y-6">
                <div className="flex justify-center">
                  <div className="bg-blue-600 p-3 rounded-2xl">
                    <QrCode size={32} className="text-white" />
                  </div>
                </div>
                <h2 className="text-2xl font-black">Sdílet se studenty</h2>
                <p className="text-slate-500 text-sm">Naskenujte kód pro rychlý přístup k laboratoři.</p>
                <div className="bg-white p-4 rounded-2xl shadow-inner border border-slate-100 flex justify-center">
                  <QRCodeCanvas value={appUrl} size={200} level="H" />
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl text-[10px] font-mono break-all text-slate-400">
                  {appUrl}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Navigace */}
        <div className="flex flex-wrap gap-2 mb-10 justify-center">
          {[
            { id: 'dc_basics', label: 'Vedení a Odpor', icon: Zap },
            { id: 'eff_work', label: 'Účinnost a Práce', icon: Cpu },
            { id: 'ac_power', label: 'Výkony AC', icon: Waves },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
                activeTab === tab.id 
                ? 'bg-blue-600 text-white shadow-lg' 
                : 'bg-white dark:bg-slate-800 text-slate-500 hover:bg-blue-50'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Panel Simulace */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white dark:bg-slate-800 rounded-3xl shadow-xl p-6 border border-slate-200 overflow-hidden">
              <div className="flex items-center gap-2 mb-6 text-blue-600">
                <Settings size={20} />
                <h2 className="font-black uppercase tracking-wider text-sm">Interaktivní Simulátor</h2>
              </div>

              {/* Visual Feedback Area */}
              <div className="mb-8 h-32 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 flex items-center justify-center overflow-hidden relative">
                {activeTab === 'dc_basics' && (
                  <div className="flex flex-col items-center w-full px-8">
                    <div className="text-[10px] font-bold text-slate-400 mb-2 uppercase tracking-widest">Vizualizace vodiče</div>
                    <div className="relative w-full flex items-center justify-center">
                      <motion.div 
                        animate={{ 
                          height: simValues.crossSection * 2,
                          backgroundColor: currentMaterial.hex
                        }}
                        className="w-full rounded-none shadow-lg relative"
                      >
                        {/* Heat/Drop effect */}
                        <motion.div 
                          animate={{ 
                            opacity: Math.min(Number(dropSim) / 20, 0.8)
                          }}
                          className="absolute inset-0 bg-red-500 rounded-none blur-md"
                        />
                      </motion.div>
                    </div>
                    <div className="mt-4 text-[10px] font-bold italic" style={{ color: currentMaterial.hex }}>
                      {currentMaterial.name} • {simValues.crossSection} mm²
                    </div>
                  </div>
                )}

                {activeTab === 'eff_work' && (
                  <div className="flex flex-col items-center">
                    <motion.div
                      animate={{ 
                        rotate: 360 
                      }}
                      transition={{ 
                        duration: Math.max(0.2, 5 - (simValues.pOut / 2000)), 
                        repeat: Infinity, 
                        ease: "linear" 
                      }}
                      className="relative"
                    >
                      <Cpu size={48} className="text-blue-600" />
                      <motion.div 
                        animate={{ 
                          scale: [1, 1.2, 1],
                          opacity: (simValues.pIn - simValues.pOut) / 2000
                        }}
                        transition={{ repeat: Infinity, duration: 1 }}
                        className="absolute inset-0 bg-orange-500 rounded-full blur-xl -z-10"
                      />
                    </motion.div>
                    <div className="mt-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                      Ztráty: {simValues.pIn - simValues.pOut} W
                    </div>
                  </div>
                )}

                {activeTab === 'ac_power' && (
                  <div className="w-full h-full flex items-center justify-center px-4">
                    <svg viewBox="0 0 200 100" className="w-full h-20">
                      <motion.path
                        d={`M 0 50 ${Array.from({length: 20}).map((_, i) => {
                          const x = (i + 1) * 10;
                          const angle = (i + 1) * 0.5 + (Date.now() / 1000);
                          const y = 50 + Math.sin(angle) * (simValues.iAc / 2);
                          return `L ${x} ${y}`;
                        }).join(' ')}`}
                        fill="none"
                        stroke="#2563eb"
                        strokeWidth="3"
                        strokeLinecap="round"
                        animate={{
                          strokeDasharray: ["1, 0", "1, 0"],
                          opacity: [0.8, 1, 0.8]
                        }}
                        transition={{ repeat: Infinity, duration: 2 }}
                      />
                      {/* Voltage reference */}
                      <path d="M 0 50 L 200 50" stroke="#cbd5e1" strokeWidth="1" strokeDasharray="4" />
                    </svg>
                    <div className="absolute bottom-2 right-4 text-[8px] font-bold text-slate-400 uppercase">
                      f = 50 Hz • cos φ = {simValues.cosPhi}
                    </div>
                  </div>
                )}
              </div>

              {activeTab === 'dc_basics' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4 text-center mb-4">
                    <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
                      <span className="text-[10px] block text-slate-400">R = {resSim} Ω</span>
                    </div>
                    <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
                      <span className="text-[10px] block text-slate-400">ΔU = {dropSim} V</span>
                    </div>
                  </div>
                  <label className="block">
                    <span className="text-xs font-bold text-slate-400 uppercase">MATERIÁL VODIČE</span>
                    <div className="flex gap-2 mt-2">
                      <button 
                        onClick={() => setSimValues({...simValues, material: 0.0178})}
                        className={`flex-1 py-2 rounded-lg text-[10px] font-black transition-all ${simValues.material === 0.0178 ? `${MATERIAL_COLORS.copper.tailwind} text-white shadow-md` : 'bg-slate-100 text-slate-500'}`}
                      >
                        MĚĎ (Cu)
                      </button>
                      <button 
                        onClick={() => setSimValues({...simValues, material: 0.028})}
                        className={`flex-1 py-2 rounded-lg text-[10px] font-black transition-all ${simValues.material === 0.028 ? `${MATERIAL_COLORS.aluminum.tailwind} text-white shadow-md` : 'bg-slate-100 text-slate-500'}`}
                      >
                        HLINÍK (Al)
                      </button>
                    </div>
                  </label>
                  <label className="block">
                    <span className="text-xs font-bold text-slate-400 uppercase">DÉLKA (m): {simValues.length}</span>
                    <input type="range" min="1" max="500" value={simValues.length} onChange={e => setSimValues({...simValues, length: Number(e.target.value)})} className="w-full h-2 bg-blue-100 rounded-lg appearance-none cursor-pointer mt-2" />
                  </label>
                  <label className="block">
                    <span className="text-xs font-bold text-slate-400 uppercase">PRŮŘEZ (mm²): {simValues.crossSection}</span>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {[1.5, 2.5, 4, 6, 10, 16].map(v => (
                        <button key={v} onClick={() => setSimValues({...simValues, crossSection: v})} className={`px-3 py-1 rounded-md text-xs font-bold ${simValues.crossSection === v ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>{v}</button>
                      ))}
                    </div>
                  </label>
                </div>
              )}

              {activeTab === 'eff_work' && (
                <div className="space-y-6">
                   <div className="grid grid-cols-2 gap-4 text-center mb-4">
                    <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
                      <span className="text-[10px] block text-slate-400">η = {effSim} %</span>
                    </div>
                    <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
                      <span className="text-[10px] block text-slate-400">W = {workSim} kWh</span>
                    </div>
                  </div>
                  <label className="block">
                    <span className="text-xs font-bold text-slate-400 uppercase">PŘÍKON P₀ (W): {simValues.pIn}</span>
                    <input type="range" min="100" max="10000" step="100" value={simValues.pIn} onChange={e => setSimValues({...simValues, pIn: Number(e.target.value)})} className="w-full h-2 bg-blue-100 rounded-lg appearance-none cursor-pointer mt-2" />
                  </label>
                  <label className="block">
                    <span className="text-xs font-bold text-slate-400 uppercase">VÝKON P (W): {simValues.pOut}</span>
                    <input type="range" min="50" max={simValues.pIn} step="50" value={simValues.pOut} onChange={e => setSimValues({...simValues, pOut: Number(e.target.value)})} className="w-full h-2 bg-blue-100 rounded-lg appearance-none cursor-pointer mt-2" />
                  </label>
                </div>
              )}

              {activeTab === 'ac_power' && (
                <div className="space-y-6">
                  <div className="p-4 bg-slate-900 text-blue-400 rounded-xl font-mono text-xs space-y-1">
                    <p>S = {sSim} VA</p>
                    <p>P = {pSim} W</p>
                    <p>Q = {qSim} VAr</p>
                  </div>
                  <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-xl">
                    <button onClick={() => setSimValues({...simValues, isThreePhase: false})} className={`flex-1 py-2 rounded-lg text-xs font-black transition-all ${!simValues.isThreePhase ? 'bg-white shadow text-blue-600' : 'text-slate-400'}`}>1-FÁZE</button>
                    <button onClick={() => setSimValues({...simValues, isThreePhase: true})} className={`flex-1 py-2 rounded-lg text-xs font-black transition-all ${simValues.isThreePhase ? 'bg-white shadow text-blue-600' : 'text-slate-400'}`}>3-FÁZE</button>
                  </div>
                  <label className="block">
                    <span className="text-xs font-bold text-slate-400 uppercase">PROUD I (A): {simValues.iAc}</span>
                    <input type="range" min="1" max="63" value={simValues.iAc} onChange={e => setSimValues({...simValues, iAc: Number(e.target.value)})} className="w-full h-2 bg-blue-100 rounded-lg appearance-none cursor-pointer mt-2" />
                  </label>
                  <label className="block">
                    <span className="text-xs font-bold text-slate-400 uppercase">ÚČINÍK cos φ: {simValues.cosPhi}</span>
                    <input type="range" min="0.1" max="1" step="0.01" value={simValues.cosPhi} onChange={e => setSimValues({...simValues, cosPhi: Number(e.target.value)})} className="w-full h-2 bg-blue-100 rounded-lg appearance-none cursor-pointer mt-2" />
                  </label>
                </div>
              )}
            </div>
            
            <div className="bg-blue-600 rounded-3xl p-6 text-white shadow-xl shadow-blue-200 dark:shadow-none">
               <h3 className="font-black text-xl mb-2 flex items-center gap-2">
                 <Info size={24}/> Tahák: Vzorce
               </h3>
               {activeTab === 'dc_basics' && (
                 <>
                   <div className="text-sm space-y-3 opacity-90 italic">
                     <p>R = ρ · (l / S)</p>
                     <p>ΔU = 2 · R · I (pro 1-fázi)</p>
                   </div>
                   <div className="flex gap-4 mt-6 pt-4 border-t border-white/20">
                     <div className="flex items-center gap-2">
                       <div className={`w-3 h-3 rounded-full ${MATERIAL_COLORS.copper.tailwind}`}></div>
                       <span className="text-[10px] font-bold uppercase tracking-wider">Měď</span>
                     </div>
                     <div className="flex items-center gap-2">
                       <div className={`w-3 h-3 rounded-full ${MATERIAL_COLORS.aluminum.tailwind}`}></div>
                       <span className="text-[10px] font-bold uppercase tracking-wider">Hliník</span>
                     </div>
                   </div>
                 </>
               )}
               {activeTab === 'eff_work' && (
                 <div className="text-sm space-y-3 opacity-90 italic">
                   <p>η = (P / P₀) · 100 [%]</p>
                   <p>W = P₀ · t [Wh, kWh]</p>
                 </div>
               )}
               {activeTab === 'ac_power' && (
                 <div className="text-sm space-y-3 opacity-90 italic">
                   <p>1f: P = U · I · cos φ</p>
                   <p>3f: P = √3 · U · I · cos φ</p>
                 </div>
               )}
            </div>
          </div>

          {/* Panel Generátoru Procvičování */}
          <div className="lg:col-span-7">
            <div className="bg-white dark:bg-slate-800 rounded-3xl shadow-xl p-8 border-2 border-slate-100 dark:border-slate-800 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4">
                <button 
                  onClick={() => generateNewQuiz(activeTab)}
                  className="p-2 text-slate-400 hover:text-blue-600 transition-colors"
                  title="Nový příklad"
                >
                  <RefreshCw size={24} />
                </button>
              </div>

              <div className="mb-8">
                <span className="px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-[10px] font-black uppercase mb-4 inline-block tracking-widest">
                  {currentQuiz?.title || "Načítání..."}
                </span>
                <h3 className="text-2xl font-bold text-slate-800 dark:text-white leading-tight">
                  {currentQuiz?.q}
                </h3>
              </div>

              <div className="space-y-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1 relative">
                    <input 
                      type="text" 
                      value={userAnswer}
                      onChange={(e) => setUserAnswer(e.target.value)}
                      placeholder="Tvá odpověď..."
                      className="w-full p-5 rounded-2xl bg-slate-50 dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-700 text-xl font-black focus:border-blue-500 outline-none transition-all"
                    />
                    <span className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">
                      {currentQuiz?.unit}
                    </span>
                  </div>
                  <button 
                    onClick={checkAnswer}
                    disabled={!userAnswer}
                    className="px-10 py-5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-2xl font-black text-lg shadow-lg shadow-blue-200 dark:shadow-none transition-all active:scale-95"
                  >
                    Odeslat
                  </button>
                </div>

                {feedback && (
                  <motion.div 
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`p-6 rounded-2xl flex items-start gap-4 border ${
                    feedback.status === 'success' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-red-50 text-red-700 border-red-200'
                  }`}>
                    {feedback.status === 'success' ? (
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 0.5 }}
                      >
                        <CheckCircle2 className="shrink-0" size={24}/>
                      </motion.div>
                    ) : (
                      <XCircle className="shrink-0" size={24}/>
                    )}
                    <div>
                      <p className="font-black text-lg">{feedback.status === 'success' ? 'Skvělá práce!' : 'Chyba v měření'}</p>
                      <p className="text-sm font-medium opacity-80">{feedback.msg}</p>
                      {feedback.status === 'success' && (
                        <button 
                          onClick={() => generateNewQuiz(activeTab)}
                          className="mt-3 flex items-center gap-1 text-xs font-black uppercase tracking-wider text-blue-600 hover:text-blue-700"
                        >
                          Další příklad <ArrowRight size={14}/>
                        </button>
                      )}
                    </div>
                  </motion.div>
                )}

                {scoreHistory.length > 0 && (
                  <div className="mt-8 p-6 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-700">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-xs font-black uppercase tracking-widest text-slate-400">Historie tvého pokroku</h4>
                      <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-md">Real-time data</span>
                    </div>
                    <div className="h-40 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={scoreHistory}>
                          <defs>
                            <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#2563eb" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                          <XAxis 
                            dataKey="time" 
                            hide 
                          />
                          <YAxis 
                            domain={['dataMin - 1', 'dataMax + 1']} 
                            hide
                          />
                          <Tooltip 
                            contentStyle={{ 
                              borderRadius: '12px', 
                              border: 'none', 
                              boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                              fontSize: '10px',
                              fontWeight: 'bold'
                            }}
                          />
                          <Area 
                            type="monotone" 
                            dataKey="score" 
                            stroke="#2563eb" 
                            strokeWidth={3}
                            fillOpacity={1} 
                            fill="url(#colorScore)" 
                            animationDuration={1000}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="mt-12 pt-8 border-t border-slate-100 dark:border-slate-700">
                <div className="flex items-center gap-2 text-slate-400 mb-4">
                  <HelpCircle size={16}/>
                  <span className="text-xs font-bold uppercase tracking-widest">Postup řešení</span>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-xl italic text-slate-500 text-sm">
                  Dosadíš známé hodnoty do vzorce, dáš pozor na převody jednotek (např. mm² u průřezu nebo kWh u práce) a zaokrouhlíš na 2 desetinná místa.
                </div>
              </div>
            </div>
          </div>
        </div>

        <footer className="mt-16 pb-12 text-center text-slate-400 text-xs border-t border-slate-200 dark:border-slate-800 pt-8">
          <p className="font-bold mb-2 uppercase">Digitální Elektrolaboratoř v2.0</p>
          <p>Tato aplikace generuje unikátní praktické příklady pro intenzivní procvičování elektrotechnických výpočtů.</p>
        </footer>
      </div>
    </div>
  );
};

// Pomocná komponenta šipky
const ArrowRight = ({ size }: { size: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
);

export default App;

