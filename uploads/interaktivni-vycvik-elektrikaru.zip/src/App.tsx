import { useState, useMemo, useEffect, useRef, FormEvent } from 'react';
import { 
  motion, 
  AnimatePresence 
} from 'motion/react';
import { 
  HardHat, 
  GraduationCap, 
  Wrench, 
  Bolt, 
  ArrowLeft, 
  Cpu, 
  Shield, 
  ShieldAlert, 
  LifeBuoy, 
  ToggleLeft, 
  ToggleRight, 
  Cog, 
  AlertTriangle, 
  RefreshCw, 
  Undo2, 
  Trash2, 
  Info, 
  CircleDot, 
  Check, 
  X, 
  RotateCcw, 
  Sparkles, 
  Zap, 
  Award, 
  Flame,
  HelpCircle,
  Calculator,
  Grid,
  Share2,
  Copy
} from 'lucide-react';

import { fullDatabase } from './questions';
import { Question, UserAnswer, ComponentItem } from './types';
import QRCode from 'qrcode';

// Helper to get N random questions
const getRandomQuestions = (count: number): Question[] => {
  const shuffled = [...fullDatabase].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
};

export default function App() {
  const [appState, setAppState] = useState<'intro' | 'quiz' | 'results' | 'theory'>('intro');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQIdx, setCurrentQIdx] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [feedback, setFeedback] = useState<'correct' | 'incorrect' | null>(null);
  const [answers, setAnswers] = useState<UserAnswer[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Candidate and certificate states
  const [userName, setUserName] = useState<string>('');
  const [certificateCode, setCertificateCode] = useState<string>('');
  const [verifiedCert, setVerifiedCert] = useState<{ cert: string; name: string; date?: string; score?: string } | null>(null);

  // Share app state
  const [copiedAppUrl, setCopiedAppUrl] = useState<boolean>(false);
  const [shareQrCodeDataUrl, setShareQrCodeDataUrl] = useState<string>('');

  useEffect(() => {
    const url = typeof window !== 'undefined' ? window.location.origin + window.location.pathname : 'https://ais-dev-jor64vj3in7z3drcvlakmk-285356984179.europe-west2.run.app/';
    QRCode.toDataURL(url, {
      margin: 1,
      width: 256,
      color: {
        dark: '#000000',
        light: '#ffffff'
      }
    })
      .then((dataUrl) => setShareQrCodeDataUrl(dataUrl))
      .catch((err) => console.error('Error generating offline QR code:', err));
  }, []);

  // Responsive window tracker
  const [windowSize, setWindowSize] = useState({
    width: typeof window !== 'undefined' ? window.innerWidth : 1024,
    height: typeof window !== 'undefined' ? window.innerHeight : 768
  });

  // Track size of browser window for responsiveness indicator
  useEffect(() => {
    const handleResize = () => {
      setWindowSize({ width: window.innerWidth, height: window.innerHeight });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Check URL query parameters for external QR certificate verification on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const certParam = params.get('cert');
    const nameParam = params.get('name');
    const dateParam = params.get('date');
    const scoreParam = params.get('score');
    if (certParam && nameParam) {
      setVerifiedCert({
        cert: certParam,
        name: nameParam,
        date: dateParam || new Date().toLocaleDateString('cs-CZ'),
        score: scoreParam || '100'
      });
    }
  }, []);

  const handleCopyAppUrl = () => {
    const url = window.location.origin + window.location.pathname;
    navigator.clipboard.writeText(url).then(() => {
      setCopiedAppUrl(true);
      setTimeout(() => setCopiedAppUrl(false), 2000);
    });
  };

  // Interactive theory states
  const [rcdState, setRcdState] = useState<'on' | 'off' | 'tripped'>('on');
  const [mcbState, setMcbState] = useState<'on' | 'off' | 'tripped'>('on');
  const [controlBtn, setControlBtn] = useState<boolean>(false); // Start button state
  const [activeFault, setActiveFault] = useState<string | null>(null);
  const [faultLog, setFaultLog] = useState<string[]>(['Soustava je připravena k provozu.']);

  // Dynamic feedback texts for the simulated panel
  const hasPower = rcdState === 'on' && mcbState === 'on';
  const isContactorClosed = hasPower && controlBtn;
  const isMotorRunning = hasPower && isContactorClosed;

  // Logging utility for simulator
  const addLog = (msg: string) => {
    const time = new Date().toLocaleTimeString('cs-CZ');
    setFaultLog(prev => [`[${time}] ${msg}`, ...prev.slice(0, 4)]);
  };

  const handleSimulatedFault = (type: 'short' | 'overload' | 'leakage') => {
    setActiveFault(type);
    if (type === 'short') {
      addLog('⚠️ DETEKCE: Tvrdý mezifázový zkrat (L-N)!');
      setTimeout(() => {
        setMcbState('tripped');
        setControlBtn(false);
        setActiveFault(null);
        addLog('💥 Jistič B16 okamžitě vybavil zkratovou spouští (elektromagnet)!');
      }, 600);
    } else if (type === 'overload') {
      addLog('⚠️ DETEKCE: Motor je mechanicky zablokován. Proud roste na 45 A!');
      setTimeout(() => {
        setMcbState('tripped');
        setControlBtn(false);
        setActiveFault(null);
        addLog('🔥 Jistič B16 vybavil po zpoždění bimetalovou tepelnou spouští!');
      }, 2000);
    } else if (type === 'leakage') {
      addLog('⚠️ DETEKCE: Unikající proud do ochranného PE vodiče (32 mA)!');
      setTimeout(() => {
        setRcdState('tripped');
        setControlBtn(false);
        setActiveFault(null);
        addLog('⚡ Proudový chránič (RCD) zaznamenal asymetrii a odpojil obvod za 25 ms!');
      }, 500);
    }
  };

  const resetSimulator = () => {
    setRcdState('off');
    setMcbState('off');
    setControlBtn(false);
    setActiveFault(null);
    setProbeRed(null);
    setProbeBlack(null);
    setActiveProbePlacement(null);
    setFaultLog(['Soustava byla bezpečně vypnuta a resetována. Měřicí hroty byly odpojeny.']);
  };

  // Multimeter states
  const [multimeterActive, setMultimeterActive] = useState<boolean>(false);
  const [multimeterMode, setMultimeterMode] = useState<'V_AC' | 'continuity' | 'off'>('V_AC');
  const [probeRed, setProbeRed] = useState<string | null>(null);
  const [probeBlack, setProbeBlack] = useState<string | null>(null);
  const [activeProbePlacement, setActiveProbePlacement] = useState<'red' | 'black' | null>(null);
  const [activeSlot, setActiveSlot] = useState<'red' | 'black'>('red');
  const [flickerVal, setFlickerVal] = useState<number>(0);

  // Decimals flicker simulation for realistic visual feedback
  useEffect(() => {
    if (!multimeterActive) return;
    const interval = setInterval(() => {
      setFlickerVal((Math.random() - 0.5) * 0.6);
    }, 450);
    return () => clearInterval(interval);
  }, [multimeterActive]);

  // Node Potential Function (returns absolute voltage reference relative to N/PE)
  const getNodePotential = (nodeId: string | null): number => {
    if (!nodeId) return 0;
    switch (nodeId) {
      case 'TP1': // Source Line
        return 230;
      case 'TP2': // After RCD
        return rcdState === 'on' ? 230 : 0;
      case 'TP3': // After MCB
        return (rcdState === 'on' && mcbState === 'on') ? 230 : 0;
      case 'TP4': // After Contactor
        return (rcdState === 'on' && mcbState === 'on' && isContactorClosed) ? 230 : 0;
      case 'TP5': // Neutral Rail
        return 0;
      case 'TP6': // PE Ground Rail
        return 0;
      default:
        return 0;
    }
  };

  // Measured Voltage between red and black probes
  const measuredVoltage = useMemo(() => {
    if (!probeRed || !probeBlack) return null;
    if (multimeterMode === 'off') return null;
    const potRed = getNodePotential(probeRed);
    const potBlack = getNodePotential(probeBlack);
    return Math.abs(potRed - potBlack);
  }, [probeRed, probeBlack, rcdState, mcbState, isContactorClosed, multimeterMode]);

  // Transitive metallic continuity calculation
  const checkContinuity = (nodeA: string | null, nodeB: string | null): boolean => {
    if (!nodeA || !nodeB) return false;
    if (nodeA === nodeB) return true;
    
    // Build temporary adjacency list based on switches/contactor states
    const adj: Record<string, string[]> = {
      'TP1': [], 'TP2': [], 'TP3': [], 'TP4': [], 'TP5': [], 'TP6': []
    };
    
    const addEdge = (u: string, v: string) => {
      adj[u].push(v);
      adj[v].push(u);
    };
    
    if (rcdState === 'on') addEdge('TP1', 'TP2');
    if (mcbState === 'on') addEdge('TP2', 'TP3');
    if (isContactorClosed) addEdge('TP3', 'TP4');
    
    const visited = new Set<string>();
    const queue = [nodeA];
    visited.add(nodeA);
    
    while (queue.length > 0) {
      const curr = queue.shift()!;
      if (curr === nodeB) return true;
      for (const neighbor of adj[curr] || []) {
        if (!visited.has(neighbor)) {
          visited.add(neighbor);
          queue.push(neighbor);
        }
      }
    }
    return false;
  };

  const isContinuous = useMemo(() => {
    if (!probeRed || !probeBlack) return false;
    return checkContinuity(probeRed, probeBlack);
  }, [probeRed, probeBlack, rcdState, mcbState, isContactorClosed]);

  const handleConnectProbe = (id: string) => {
    if (activeProbePlacement === 'red') {
      if (probeBlack === id) setProbeBlack(null);
      setProbeRed(id);
      addLog(`Multimetr: Červený hrot (V) připojen k bodu ${id === 'TP1' ? 'TP1 (Rozvodná síť)' : id === 'TP2' ? 'TP2 (Za chráničem)' : id === 'TP3' ? 'TP3 (Za jističem)' : id === 'TP4' ? 'TP4 (Vstup motoru)' : id === 'TP5' ? 'TP5 (Nulový můstek)' : 'TP6 (PE svorkovnice)'}`);
      setActiveProbePlacement(null);
    } else if (activeProbePlacement === 'black') {
      if (probeRed === id) setProbeRed(null);
      setProbeBlack(id);
      addLog(`Multimetr: Černý hrot (COM) připojen k bodu ${id === 'TP1' ? 'TP1 (Rozvodná síť)' : id === 'TP2' ? 'TP2 (Za chráničem)' : id === 'TP3' ? 'TP3 (Za jističem)' : id === 'TP4' ? 'TP4 (Vstup motoru)' : id === 'TP5' ? 'TP5 (Nulový můstek)' : 'TP6 (PE svorkovnice)'}`);
      setActiveProbePlacement(null);
    } else {
      // Direct click on node assign based on active slot
      if (activeSlot === 'red') {
        if (probeBlack === id) setProbeBlack(null);
        setProbeRed(id);
        addLog(`Multimetr: Červený hrot (V) připojen k bodu ${id === 'TP1' ? 'TP1 (Rozvodná síť)' : id === 'TP2' ? 'TP2 (Za chráničem)' : id === 'TP3' ? 'TP3 (Za jističem)' : id === 'TP4' ? 'TP4 (Vstup motoru)' : id === 'TP5' ? 'TP5 (Nulový můstek)' : 'TP6 (PE svorkovnice)'}`);
      } else {
        if (probeRed === id) setProbeRed(null);
        setProbeBlack(id);
        addLog(`Multimetr: Černý hrot (COM) připojen k bodu ${id === 'TP1' ? 'TP1 (Rozvodná síť)' : id === 'TP2' ? 'TP2 (Za chráničem)' : id === 'TP3' ? 'TP3 (Za jističem)' : id === 'TP4' ? 'TP4 (Vstup motoru)' : id === 'TP5' ? 'TP5 (Nulový můstek)' : 'TP6 (PE svorkovnice)'}`);
      }
    }
  };

  const getTPLabel = (id: string | null) => {
    if (!id) return 'Odpojeno';
    switch (id) {
      case 'TP1': return 'TP1 (Rozvodná síť L1)';
      case 'TP2': return 'TP2 (Za chráničem RCD)';
      case 'TP3': return 'TP3 (Za jističem MCB)';
      case 'TP4': return 'TP4 (Vstup do motoru)';
      case 'TP5': return 'TP5 (Nulová sběrnice N)';
      case 'TP6': return 'TP6 (Ochranná svorka PE)';
      default: return id;
    }
  };

  const renderTestPoint = (id: string) => {
    const isRed = probeRed === id;
    const isBlack = probeBlack === id;
    const label = id === 'TP1' ? 'L1' :
                  id === 'TP2' ? 'RCD' :
                  id === 'TP3' ? 'MCB' :
                  id === 'TP4' ? 'MOT' :
                  id === 'TP5' ? 'N' : 'PE';

    return (
      <button
        onClick={(e) => {
          e.stopPropagation();
          handleConnectProbe(id);
        }}
        className={`group relative w-6 h-6 rounded-full border flex items-center justify-center transition-all duration-200 z-30 ${
          isRed ? 'border-red-500 bg-red-600 text-white shadow-[0_0_8px_rgba(239,68,68,0.8)] test-point-glow-red' :
          isBlack ? 'border-zinc-400 bg-zinc-700 text-white shadow-[0_0_8px_rgba(228,228,231,0.8)] test-point-glow-black' :
          activeProbePlacement === 'red' ? 'border-red-500/80 bg-red-950/40 hover:border-red-500 hover:scale-110 animate-pulse test-point-glow-red' :
          activeProbePlacement === 'black' ? 'border-zinc-400/80 bg-zinc-800 hover:border-zinc-400 hover:scale-110 animate-pulse test-point-glow-black' :
          'border-[#c5a059]/40 bg-zinc-950 hover:border-[#c5a059] text-zinc-400 test-point-glow'
        }`}
        title={`Měřicí bod ${label}`}
      >
        {isRed ? (
          <span className="text-[9px] font-black font-mono">V</span>
        ) : isBlack ? (
          <span className="text-[9px] font-black font-mono">C</span>
        ) : (
          <span className="text-[8px] font-mono font-bold group-hover:text-white">{label}</span>
        )}
        
        {activeProbePlacement && !isRed && !isBlack && (
          <span className={`absolute -inset-1 rounded-full border animate-ping pointer-events-none ${
            activeProbePlacement === 'red' ? 'border-red-500/40' : 'border-zinc-400/40'
          }`}></span>
        )}
      </button>
    );
  };

  const startQuiz = () => {
    // Filter by type if wanted, currently random 10
    const selected = getRandomQuestions(10);
    setQuestions(selected);
    setCurrentQIdx(0);
    setScore(0);
    setAnswers([]);
    setFeedback(null);
    setAppState('quiz');
    // Generate fresh certificate code for this session
    setCertificateCode('NV194-' + Math.random().toString(36).substring(2, 6).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase());
  };

  const handleQuizAnswerSubmit = (isCorrect: boolean, userVal?: string) => {
    if (feedback) return;
    const currentQ = questions[currentQIdx];
    setAnswers(prev => [...prev, { question: currentQ, isCorrect, userValue: userVal }]);
    if (isCorrect) {
      setScore(prev => prev + 1);
      setFeedback('correct');
    } else {
      setFeedback('incorrect');
    }
  };

  const nextQuestion = () => {
    if (currentQIdx < questions.length - 1) {
      setCurrentQIdx(prev => prev + 1);
      setFeedback(null);
    } else {
      setAppState('results');
      if (!certificateCode) {
        setCertificateCode('NV194-' + Math.random().toString(36).substring(2, 6).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase());
      }
    }
  };

  // Helper score text
  const scorePercent = questions.length > 0 ? Math.round((score / questions.length) * 100) : 0;
  const masterRating = useMemo(() => {
    if (scorePercent === 100) {
      return {
        title: "Mistr oboru (Paragraf 6+)",
        msg: "Chlape, klobouk dolů! Odpověděl jsi bez jediné chyby. Ty bys mohl revidovat i atomovku. Jsi naprostá elita a hrdost naší dílny!",
        color: "text-emerald-400 border-emerald-500 bg-emerald-950/40"
      };
    } else if (scorePercent >= 80) {
      return {
        title: "Zkušený elektrikář",
        msg: "Výborná práce! Máš skvělý přehled, ČSN normy ti nejsou cizí a zapojení zvládáš levou zadní. Pár drobných mušek tam bylo, ale na stavbu tě pustím s klidným svědomím.",
        color: "text-teal-400 border-teal-500 bg-teal-950/40"
      };
    } else if (scorePercent >= 50) {
      return {
        title: "Učeň v zácviku",
        msg: "No, přežil jsi to, ale žádná sláva. S tímhle výsledkem tě nechám tahat leda tak kabely pod dozorem. Raději si ještě jednou prostuduj teorii, než na něco sáhneš!",
        color: "text-amber-400 border-amber-500 bg-amber-950/40"
      };
    } else {
      return {
        title: "Nebezpečí pro okolí",
        msg: "Katastrofa! Okamžitě odlož to nářadí, nebo někoho zabiješ! Vyhodil jsi pojistky v půlce okresu a zapojil fázi na kolík. Zpátky do lavic a šrotit teorii!",
        color: "text-rose-400 border-rose-500 bg-rose-950/40"
      };
    }
  }, [scorePercent]);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f5f5f5] flex flex-col justify-between selection:bg-[#c5a059] selection:text-black">
      
      {/* Header */}
      <header className="border-b border-white/10 bg-[#0a0a0a] sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-6 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="border border-[#c5a059] p-2 rounded-full text-[#c5a059] shadow-sm">
              <HardHat className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-light tracking-[0.2em] uppercase text-white font-sans">
                AURELIUS <span className="text-[#c5a059] font-serif italic text-sm font-light tracking-normal lowercase ml-1">elektro</span>
              </h1>
              <p className="text-[10px] text-zinc-500 uppercase tracking-[0.15em] font-mono hidden sm:block">Zkušební trenažér & simulace • ČSN EN 50110-1</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <span className="text-[10px] font-mono tracking-widest uppercase px-3 py-1 bg-zinc-900 border border-white/10 text-[#c5a059] flex items-center gap-1.5 rounded-none">
              <span className="w-1.5 h-1.5 rounded-full bg-[#c5a059] animate-pulse"></span>
              AKTIVNÍ TRÉNINK
            </span>
            <div className="w-8 h-8 border border-white/10 rounded-full flex items-center justify-center text-xs text-zinc-400 font-mono">
              CZ
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Workspace */}
      <main className="flex-grow max-w-6xl w-full mx-auto px-6 py-10">
        <AnimatePresence mode="wait">
          
          {/* INTRO SCREEN */}
          {appState === 'intro' && (
            <motion.div
              key="intro"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="space-y-10"
            >
              {/* QR Verification Banner if active */}
              {verifiedCert && (
                <div className="bg-[#121212] border-2 border-[#c5a059] p-5 rounded-none flex flex-col md:flex-row items-center justify-between gap-4 shadow-2xl relative overflow-hidden animate-[pulse_2s_infinite]">
                  <div className="absolute top-0 left-0 w-1.5 h-full bg-[#c5a059]"></div>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-[#c5a059]/10 border border-[#c5a059]/20 flex items-center justify-center text-[#c5a059] rounded-none">
                      <Award className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="text-[9px] font-mono text-[#c5a059] font-bold tracking-widest uppercase">SYSTÉM OVĚŘENÍ DIGITÁLNÍHO CERTIFIKÁTU</div>
                      <h4 className="text-white font-serif italic text-lg leading-snug">
                        Držitel: <strong className="text-[#c5a059] font-bold not-italic">{verifiedCert.name}</strong> • NV 194/2022 Sb.
                      </h4>
                      <p className="text-zinc-400 text-[11px] font-mono mt-0.5">
                        Kód osvědčení: <strong className="text-zinc-200">{verifiedCert.cert}</strong> • Datum: {verifiedCert.date} • Skóre: {verifiedCert.score}%
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setVerifiedCert(null)}
                    className="px-4 py-2 bg-zinc-900 border border-white/5 text-zinc-400 hover:text-white transition font-mono text-[9px] tracking-widest uppercase rounded-none"
                  >
                    Zavřít ověření [X]
                  </button>
                </div>
              )}

              {/* Hero Master Section */}
              <div className="bg-zinc-950 rounded-none border border-white/10 p-8 md:p-12 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-96 h-96 bg-[#c5a059]/5 rounded-full blur-3xl -z-10"></div>
                
                <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
                  {/* Left block with Georgia text */}
                  <div className="max-w-2xl space-y-6">
                    <div className="text-[10px] text-[#c5a059] uppercase tracking-[0.3em] font-mono">
                      ODBORNÁ ZPŮSOBILOST • ESTABLISHMENT MMXXVI
                    </div>
                    <h2 className="text-4xl md:text-5xl font-light leading-[1.15] text-white" style={{ fontFamily: 'Georgia, serif' }}>
                      Formujeme <span className="italic">napětí</span> v tichu a bezpečí.
                    </h2>
                    <p className="text-zinc-400 text-sm md:text-base leading-relaxed max-w-xl">
                      „Bezpečnost je na prvním místě, kluci! Dnes si proklepneme, jak zvládáte zapojení elektrických obvodů nízkého napětí (nn), legislativu, výpočty zátěže a rychlé reakce na krizové stavy. Žádné zčernalé kabely a spálené cívky nechci vidět!“
                    </p>
                    <div className="w-36 h-[1px] bg-[#c5a059]"></div>
                  </div>

                  {/* Right Block - Master Avatar in Sophisticated Dark look */}
                  <div className="flex-shrink-0 bg-[#121212] border border-white/10 p-6 rounded-none w-full lg:w-72 flex items-center gap-4">
                    <div className="w-14 h-14 rounded-full border border-[#c5a059]/40 flex items-center justify-center text-[#c5a059] bg-[#0a0a0a]">
                      <HardHat className="w-7 h-7" />
                    </div>
                    <div>
                      <div className="text-[9px] uppercase tracking-widest text-zinc-500 font-mono">DOZORUJÍCÍ MISTR</div>
                      <div className="font-serif italic text-lg text-white">Mistr Jan</div>
                      <div className="text-[10px] font-mono text-[#c5a059]">Paragraf 8 • Revizní specialista</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Routes - Dual Mode Card Layout */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* 1. Theory Simulator Card */}
                <div className="group bg-[#121212] rounded-none border border-white/5 hover:border-[#c5a059]/50 p-8 transition-all duration-300 flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="border border-white/10 p-3 rounded-none text-zinc-400 group-hover:text-[#c5a059] group-hover:border-[#c5a059]/50 transition-colors duration-300">
                        <Cpu className="w-6 h-6" />
                      </div>
                      <span className="text-[10px] tracking-widest font-mono text-zinc-500">SIMULÁTOR NN</span>
                    </div>
                    <h3 className="text-xl font-light text-white group-hover:text-[#c5a059] transition-colors" style={{ fontFamily: 'Georgia, serif' }}>
                      1. Interaktivní učebna přístrojů
                    </h3>
                    <p className="text-zinc-400 text-sm leading-relaxed">
                      Prohlédněte si zapojení a funkčnost ochranných a spínacích prvků: proudového chrániče (RCD), 
                      jističe (MCB) a stykače. Nasimulujte mezifázový zkrat, přetížení motoru nebo únik proudu 
                      do kostry a pozorujte fyzické reakce spouští.
                    </p>
                    <div className="flex flex-wrap gap-2 pt-2">
                      <span className="text-[10px] font-mono bg-[#0a0a0a] border border-white/5 text-zinc-400 px-2.5 py-1 rounded-none">RCD Chránič</span>
                      <span className="text-[10px] font-mono bg-[#0a0a0a] border border-white/5 text-zinc-400 px-2.5 py-1 rounded-none">MCB B16</span>
                      <span className="text-[10px] font-mono bg-[#0a0a0a] border border-white/5 text-zinc-400 px-2.5 py-1 rounded-none">Stykač KM1</span>
                    </div>
                  </div>
                  <div className="pt-8">
                    <button 
                      onClick={() => setAppState('theory')}
                      className="w-full py-3.5 px-4 border border-white/20 text-white text-xs uppercase tracking-widest hover:border-white hover:bg-white hover:text-black font-bold transition duration-200 flex items-center justify-center gap-2"
                    >
                      <Wrench className="w-4 h-4" /> Vstoupit do učebny
                    </button>
                  </div>
                </div>

                {/* 2. Test Card */}
                <div className="group bg-[#121212] rounded-none border border-white/5 hover:border-[#c5a059]/50 p-8 transition-all duration-300 flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="border border-[#c5a059]/20 p-3 rounded-none text-[#c5a059] group-hover:text-white group-hover:border-white transition-colors duration-300">
                        <GraduationCap className="w-6 h-6" />
                      </div>
                      <span className="text-[10px] tracking-widest font-mono text-[#c5a059]">ZKUŠEBNÍ SADA</span>
                    </div>
                    <h3 className="text-xl font-light text-white group-hover:text-[#c5a059] transition-colors" style={{ fontFamily: 'Georgia, serif' }}>
                      2. Zkouška odborné způsobilosti
                    </h3>
                    <p className="text-zinc-400 text-sm leading-relaxed">
                      Ostrý test obsahující <strong>10 náhodných otázek a úkolů</strong> vybraných z komplexní databáze 
                      80 schválených otázek. Čekají vás teoretické otázky, výpočty parametrů, vyhledávání správných 
                      vodičů i interaktivní zapojování zásuvek a spínačů.
                    </p>
                    <div className="flex flex-wrap gap-2 pt-2">
                      <span className="text-[10px] font-mono bg-[#0a0a0a] border border-white/5 text-zinc-400 px-2.5 py-1 rounded-none">80 otázek v db</span>
                      <span className="text-[10px] font-mono bg-[#0a0a0a] border border-white/5 text-zinc-400 px-2.5 py-1 rounded-none">Praktické zapojování</span>
                      <span className="text-[10px] font-mono bg-[#0a0a0a] border border-white/5 text-zinc-400 px-2.5 py-1 rounded-none">Závazné vyhodnocení</span>
                    </div>
                  </div>
                  <div className="pt-8">
                    <button 
                      onClick={startQuiz}
                      className="w-full py-3.5 px-4 bg-white text-black text-xs uppercase tracking-widest font-bold hover:bg-[#c5a059] hover:text-white transition duration-200 flex items-center justify-center gap-2 shadow-lg"
                    >
                      <Bolt className="w-4 h-4" /> Spustit test zručnosti
                    </button>
                  </div>
                </div>

              </div>

              {/* Share QR Code & Link Section */}
              <div className="bg-zinc-950 p-6 md:p-8 border border-white/10 rounded-none relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-[#c5a059]/[0.02] rounded-full blur-2xl pointer-events-none"></div>
                
                <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
                  <div className="space-y-3 text-left max-w-xl">
                    <div className="flex items-center gap-2">
                      <Share2 className="w-5 h-5 text-[#c5a059]" />
                      <h4 className="text-sm font-mono text-[#c5a059] uppercase tracking-widest font-bold">Sdílení trenažéru se studenty</h4>
                    </div>
                    <p className="text-xs text-zinc-400 leading-relaxed">
                      Chcete tento interaktivní trenažér a zkušební sadu sdílet se svými studenty nebo kolegy? 
                      Naskenujte QR kód mobilním telefonem nebo zkopírujte přímý odkaz níže. Studentům se okamžitě zobrazí plná verze trenažéru připravená k výuce.
                    </p>
                    
                    <div className="flex flex-col sm:flex-row gap-2 pt-2">
                      <div className="px-3 py-2.5 bg-[#0a0a0a] border border-white/5 rounded-none font-mono text-xs text-zinc-400 select-all truncate flex-grow flex items-center">
                        {typeof window !== 'undefined' ? window.location.origin + window.location.pathname : 'https://ais-dev-jor64vj3in7z3drcvlakmk-285356984179.europe-west2.run.app/'}
                      </div>
                      <button
                        onClick={handleCopyAppUrl}
                        className="px-4 py-2.5 bg-[#c5a059]/10 border border-[#c5a059]/30 hover:bg-[#c5a059] hover:text-black text-[#c5a059] font-bold text-xs uppercase tracking-widest rounded-none transition flex items-center justify-center gap-2 cursor-pointer"
                      >
                        {copiedAppUrl ? (
                          <>
                            <Check className="w-4 h-4" /> Zkopírováno!
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4" /> Kopírovat odkaz
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* QR Code Container */}
                  <div className="flex flex-col items-center gap-2 bg-[#121212] p-4 border border-white/10 rounded-none flex-shrink-0">
                    <div className="bg-white p-1.5 inline-block border border-zinc-800">
                      {shareQrCodeDataUrl ? (
                        <img 
                          src={shareQrCodeDataUrl}
                          alt="QR Kód pro sdílení"
                          className="w-28 h-28 block"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-28 h-28 bg-zinc-900 animate-pulse flex items-center justify-center">
                          <span className="text-[10px] text-zinc-500 font-mono">Generuji...</span>
                        </div>
                      )}
                    </div>
                    <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest text-center">Naskenovat k otevření</span>
                  </div>
                </div>
              </div>

              {/* CSN Guidelines Note */}
              <div className="bg-[#121212]/50 p-5 rounded-none border border-white/10 flex items-start gap-4">
                <Info className="w-5 h-5 text-[#c5a059] flex-shrink-0 mt-0.5" />
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Metodika trenažéru odpovídá nařízením vlády <strong>NV 194/2022 Sb.</strong> (dříve Vyhláška 50/1978 Sb.) 
                  a ČSN standardům pro domovní elektroinstalace nízkého napětí. Veškerá simulovaná měření a barevné 
                  značení vodičů jsou plně v souladu s evropskou normou <strong>ČSN EN 50110-1</strong>.
                </p>
              </div>
            </motion.div>
          )}


          {/* THEORY AND SIMULATOR SECTION */}
          {appState === 'theory' && (
            <motion.div
              key="theory"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="space-y-10"
            >
              {/* Back & Breadcrumb */}
              <div className="flex justify-between items-center border-b border-white/10 pb-4">
                <button 
                  onClick={() => setAppState('intro')}
                  className="px-5 py-2.5 bg-zinc-900 hover:bg-white hover:text-black text-zinc-200 font-bold transition flex items-center gap-2 text-xs uppercase tracking-widest border border-white/10 rounded-none"
                >
                  <ArrowLeft className="w-4 h-4" /> Zpět do rozcestníku
                </button>
                <span className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase">MÍSTNOST: ROZVODNÁ DESKA NN</span>
              </div>

              {/* Intro explanation from Master */}
              <div className="bg-[#121212] rounded-none border border-white/10 border-l-2 border-l-[#c5a059] p-6 shadow-lg">
                <div className="flex gap-4 items-start">
                  <div className="border border-[#c5a059]/30 p-2.5 rounded-none text-[#c5a059]">
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-serif italic text-[#c5a059] text-base">Teoretické minimum od Mistra:</h4>
                    <p className="text-zinc-300 text-sm leading-relaxed font-sans">
                      „Pamatujte si: <strong>Proudový chránič (RCD)</strong> chrání lidský život před probíjením (měří asymetrii mezi L a N). 
                      <strong>Jistič (MCB)</strong> zase chrání samotné vedení a kabely před shořením při zkratu nebo přetížení. 
                      A <strong>stykač</strong> je silové relé, kterým bezpečně spínáme těžký motor malým proudem tlačítka.“
                    </p>
                  </div>
                </div>
              </div>

              {/* Three Column Physical Device Configurator */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                
                {/* Device 1: Proudový Chránič */}
                <div className={`p-6 rounded-none border transition-all duration-300 ${rcdState === 'tripped' ? 'bg-[#1b1710] border-[#c5a059]' : 'bg-[#121212] border-white/10'}`}>
                  <div className="flex items-center justify-between mb-4">
                    <span className="px-2.5 py-1 bg-zinc-900 text-[#c5a059] font-mono text-[9px] rounded-none border border-[#c5a059]/20 tracking-wider uppercase">FI CHRÁNIČ</span>
                    <span className="text-[10px] text-zinc-500 font-mono">2P / 25A / 30mA</span>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-serif italic text-white text-base">RCD (Proudový chránič)</h4>
                        <p className="text-xs text-zinc-400 mt-1 leading-relaxed">Hlídá rozdíl mezi odchozím a příchozím proudem. Odpojí obvod při úniku nad 30 mA.</p>
                      </div>
                      <div className={`w-3.5 h-3.5 rounded-full ${rcdState === 'on' ? 'bg-[#c5a059] shadow-[0_0_8px_rgba(197,160,89,0.5)]' : rcdState === 'tripped' ? 'bg-yellow-500 shadow-[0_0_8px_rgba(234,179,8,0.5)]' : 'bg-zinc-800'}`}></div>
                    </div>

                    <div className="bg-[#0a0a0a] p-4 rounded-none border border-white/10 space-y-3">
                      <div className="flex justify-between items-center text-xs font-mono">
                        <span className="text-zinc-500">Páčka vypínače:</span>
                        <button
                          onClick={() => {
                            setRcdState(prev => prev === 'on' ? 'off' : 'on');
                            if (rcdState === 'on') setControlBtn(false);
                            addLog(`Ruční přepnutí RCD do polohy ${rcdState === 'on' ? 'VYPNUTO (O)' : 'ZAPNUTO (I)'}`);
                          }}
                          className={`px-3 py-1.5 rounded-none text-xs font-bold transition-all duration-150 ${
                            rcdState === 'on' ? 'bg-white text-black hover:bg-[#c5a059] hover:text-white' :
                            rcdState === 'tripped' ? 'bg-yellow-500 text-black' : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'
                          }`}
                        >
                          {rcdState === 'on' ? 'I (ZAP)' : rcdState === 'tripped' ? 'VYBAVEN' : 'O (VYP)'}
                        </button>
                      </div>

                      <button
                        disabled={rcdState !== 'on'}
                        onClick={() => handleSimulatedFault('leakage')}
                        className="w-full py-2 bg-zinc-900 hover:bg-white hover:text-black text-[#c5a059] font-bold font-mono text-[10px] uppercase tracking-widest rounded-none border border-white/10 transition-all disabled:opacity-30 disabled:pointer-events-none flex items-center justify-center gap-1.5"
                      >
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Ruční TEST tlačítko (T)
                      </button>
                    </div>
                  </div>
                </div>

                {/* Device 2: Jistič */}
                <div className={`p-6 rounded-none border transition-all duration-300 ${mcbState === 'tripped' ? 'bg-[#1e1313] border-rose-900' : 'bg-[#121212] border-white/10'}`}>
                  <div className="flex items-center justify-between mb-4">
                    <span className="px-2.5 py-1 bg-zinc-900 text-[#c5a059] font-mono text-[9px] rounded-none border border-[#c5a059]/20 tracking-wider uppercase">JISTIČ B16</span>
                    <span className="text-[10px] text-zinc-500 font-mono">1P / B / 16A</span>
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-serif italic text-white text-base">Jistič (MCB Jistič)</h4>
                        <p className="text-xs text-zinc-400 mt-1 leading-relaxed">Chrání kabely před nadproudy. Bimetal na přetížení, elektromagnet na tvrdý zkrat.</p>
                      </div>
                      <div className={`w-3.5 h-3.5 rounded-full ${mcbState === 'on' ? 'bg-[#c5a059] shadow-[0_0_8px_rgba(197,160,89,0.5)]' : mcbState === 'tripped' ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.5)]' : 'bg-zinc-800'}`}></div>
                    </div>

                    <div className="bg-[#0a0a0a] p-4 rounded-none border border-white/10 flex justify-between items-center text-xs font-mono">
                      <span className="text-zinc-500">Páčka jističe:</span>
                      <button
                        onClick={() => {
                          setMcbState(prev => prev === 'on' ? 'off' : 'on');
                          if (mcbState === 'on') setControlBtn(false);
                          addLog(`Ruční přepnutí Jističe do polohy ${mcbState === 'on' ? 'VYPNUTO (O)' : 'ZAPNUTO (I)'}`);
                        }}
                        className={`px-3 py-1.5 rounded-none text-xs font-bold transition-all duration-150 ${
                          mcbState === 'on' ? 'bg-white text-black hover:bg-[#c5a059] hover:text-white' :
                          mcbState === 'tripped' ? 'bg-rose-500 text-white' : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300'
                        }`}
                      >
                        {mcbState === 'on' ? 'I (ZAP)' : mcbState === 'tripped' ? 'VYBAVEN' : 'O (VYP)'}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Device 3: Stykač */}
                <div className={`p-6 rounded-none border bg-[#121212] border-white/10`}>
                  <div className="flex items-center justify-between mb-4">
                    <span className="px-2.5 py-1 bg-zinc-900 text-zinc-400 font-mono text-[9px] rounded-none border border-white/10 tracking-wider uppercase">ŘÍZENÍ</span>
                    <span className="text-[10px] text-zinc-500 font-mono">A1-A2 / 230V</span>
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-serif italic text-white text-base">Stykač (Silové relé)</h4>
                        <p className="text-xs text-zinc-400 mt-1 leading-relaxed">Spíná napájení motoru pomocí řídicího obvodu cívky. Přisaje se magnetem.</p>
                      </div>
                      <div className={`w-3.5 h-3.5 rounded-full ${isContactorClosed ? 'bg-[#c5a059] shadow-[0_0_8px_rgba(197,160,89,0.5)]' : 'bg-zinc-800'}`}></div>
                    </div>

                    <div className="bg-[#0a0a0a] p-4 rounded-none border border-white/10 space-y-3">
                      <div className="flex justify-between items-center text-xs font-mono">
                        <span className="text-zinc-500">Tlačítko START/STOP:</span>
                        <button
                          disabled={!hasPower}
                          onClick={() => {
                            setControlBtn(prev => !prev);
                            addLog(`Ovládací tlačítko stisknuto: ${!controlBtn ? 'ZAPNUTÍ CÍVKY' : 'VYPNUTÍ CÍVKY'}`);
                          }}
                          className={`px-4 py-1.5 rounded-none text-xs font-bold transition-all duration-150 disabled:opacity-30 disabled:pointer-events-none ${
                            controlBtn ? 'bg-zinc-800 hover:bg-zinc-700 text-rose-400' : 'bg-white text-black hover:bg-[#c5a059]'
                          }`}
                        >
                          {controlBtn ? 'STOP (0)' : 'START (I)'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              {/* LIVE SCHEMATIC BOARD WITH MOTIONS AND CURRENT FLOWS */}
              <div className={multimeterActive ? "grid grid-cols-1 lg:grid-cols-12 gap-8" : "w-full"}>
                
                <div className={`bg-zinc-950 border border-white/10 rounded-none p-6 md:p-8 lg:p-4 xl:p-10 relative overflow-hidden shadow-2xl ${multimeterActive ? 'lg:col-span-8' : 'w-full'}`}>
                  
                  <div className="absolute top-2 left-3 right-3 flex items-center justify-between z-20">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#c5a059] animate-ping"></span>
                      <span className="text-[10px] font-mono text-zinc-500 tracking-widest uppercase">ŽIVÉ SCHÉMA PROUDU</span>
                    </div>

                    <button
                      onClick={() => {
                        setMultimeterActive(prev => !prev);
                        if (!multimeterActive) {
                          addLog("Multimetr zapnut. Kliknutím na body TP na schématu můžete měřit.");
                        } else {
                          addLog("Multimetr vypnut.");
                        }
                      }}
                      className={`px-3 py-1 text-[9px] font-mono tracking-widest uppercase transition flex items-center gap-1.5 border rounded-none ${
                        multimeterActive 
                          ? 'bg-[#c5a059] text-black border-[#c5a059] font-bold' 
                          : 'bg-zinc-900 text-zinc-400 border-white/10 hover:text-white hover:bg-zinc-800'
                      }`}
                    >
                      <Zap className="w-3 h-3" />
                      {multimeterActive ? 'Vypnout měření' : 'Měřit multimetrem'}
                    </button>
                  </div>

                  <div className="mt-10 flex flex-col lg:flex-row items-center justify-between gap-6 lg:gap-2 xl:gap-8 relative">
                    
                    {/* Grid overlay for tech design */}
                    <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '24px 24px'}}></div>

                    {/* 1. SOURCE BLOCK */}
                    <div className="flex flex-col items-center z-10 flex-shrink-0">
                      <div className="w-16 h-16 rounded-none bg-zinc-900 border border-white/10 flex flex-col items-center justify-center shadow-lg relative">
                        {multimeterActive && (
                          <div className="absolute -top-3 -right-3">
                            {renderTestPoint('TP1')}
                          </div>
                        )}
                        <span className="text-xs font-bold text-[#c5a059]">230V</span>
                        <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-tighter">L1 + N</span>
                      </div>
                      <div className="text-[10px] uppercase font-mono text-zinc-400 mt-2 font-semibold">Rozvodná síť</div>
                    </div>

                    {/* Flow line 1 */}
                    <div className="hidden lg:block flex-grow relative h-1 min-w-[15px] lg:min-w-[10px] xl:min-w-[30px] bg-zinc-900">
                      <div className={`absolute inset-0 bg-[#c5a059]/40 transition-opacity duration-300 ${hasPower || rcdState === 'on' ? 'opacity-100' : 'opacity-0'}`}></div>
                      {/* Animated pulse dots */}
                      {(hasPower || rcdState === 'on') && (
                        <span className="absolute w-1.5 h-1.5 rounded-full bg-[#c5a059] top-1/2 -translate-y-1/2 left-0 animate-[ping_1.5s_infinite]"></span>
                      )}
                    </div>

                    {/* Flow line 1 (Mobile vertical) */}
                    <div className="block lg:hidden w-1 h-8 bg-zinc-900 relative my-1">
                      <div className={`absolute inset-0 bg-[#c5a059]/40 transition-opacity duration-300 ${hasPower || rcdState === 'on' ? 'opacity-100' : 'opacity-0'}`}></div>
                      {(hasPower || rcdState === 'on') && (
                        <span className="absolute w-1.5 h-1.5 rounded-full bg-[#c5a059] left-1/2 -translate-x-1/2 top-0 animate-[ping_1.5s_infinite]"></span>
                      )}
                    </div>

                    {/* 2. RCD BLOCK */}
                    <div className="flex flex-col items-center z-10 flex-shrink-0">
                      <div className={`p-4 lg:p-2 xl:p-4 rounded-none border transition-all duration-300 text-center w-36 lg:w-28 xl:w-36 relative ${
                        rcdState === 'on' ? 'bg-zinc-900 border-[#c5a059]/40 text-white' :
                        rcdState === 'tripped' ? 'bg-[#1b1710] border-yellow-500/50 text-yellow-500 animate-pulse' :
                        'bg-zinc-900/40 border-white/5 text-zinc-500'
                      }`}>
                        {multimeterActive && (
                          <div className="absolute -top-3 -right-3">
                            {renderTestPoint('TP2')}
                          </div>
                        )}
                        <LifeBuoy className={`w-8 h-8 lg:w-6 lg:h-6 xl:w-8 xl:h-8 mx-auto mb-2 lg:mb-1 xl:mb-2 ${rcdState === 'on' ? 'text-[#c5a059]' : rcdState === 'tripped' ? 'text-yellow-400' : 'text-zinc-700'}`} />
                        <div className="text-xs font-bold font-serif italic">RCD Chránič</div>
                        <div className="text-[9px] font-mono mt-1 uppercase tracking-tight">
                          {rcdState === 'on' ? 'V pořádku (30mA)' : rcdState === 'tripped' ? '💥 VYBAVENO' : 'VYPNUTO'}
                        </div>
                      </div>
                    </div>

                    {/* Flow line 2 */}
                    <div className="hidden lg:block flex-grow relative h-1 min-w-[15px] lg:min-w-[10px] xl:min-w-[30px] bg-zinc-900">
                      <div className={`absolute inset-0 bg-[#c5a059]/40 transition-opacity duration-300 ${rcdState === 'on' ? 'opacity-100' : 'opacity-0'}`}></div>
                    </div>

                    {/* Flow line 2 (Mobile vertical) */}
                    <div className="block lg:hidden w-1 h-8 bg-zinc-900 relative my-1">
                      <div className={`absolute inset-0 bg-[#c5a059]/40 transition-opacity duration-300 ${rcdState === 'on' ? 'opacity-100' : 'opacity-0'}`}></div>
                      {rcdState === 'on' && (
                        <span className="absolute w-1.5 h-1.5 rounded-full bg-[#c5a059] left-1/2 -translate-x-1/2 top-0 animate-[ping_1.5s_infinite]"></span>
                      )}
                    </div>

                    {/* 3. MCB BLOCK */}
                    <div className="flex flex-col items-center z-10 flex-shrink-0">
                      <div className={`p-4 lg:p-2 xl:p-4 rounded-none border transition-all duration-300 text-center w-36 lg:w-28 xl:w-36 relative ${
                        mcbState === 'on' ? 'bg-zinc-900 border-[#c5a059]/40 text-white' :
                        mcbState === 'tripped' ? 'bg-[#1e1313] border-rose-500/50 text-rose-400 animate-pulse' :
                        'bg-zinc-900/40 border-white/5 text-zinc-500'
                      }`}>
                        {multimeterActive && (
                          <div className="absolute -top-3 -right-3">
                            {renderTestPoint('TP3')}
                          </div>
                        )}
                        <Shield className={`w-8 h-8 lg:w-6 lg:h-6 xl:w-8 xl:h-8 mx-auto mb-2 lg:mb-1 xl:mb-2 ${mcbState === 'on' ? 'text-[#c5a059]' : mcbState === 'tripped' ? 'text-rose-400' : 'text-zinc-700'}`} />
                        <div className="text-xs font-bold font-serif italic">Jistič B16</div>
                        <div className="text-[9px] font-mono mt-1 uppercase tracking-tight">
                          {mcbState === 'on' ? 'OK (In = 16A)' : mcbState === 'tripped' ? '💥 VYBAVENO' : 'VYPNUTO'}
                        </div>
                      </div>
                    </div>

                    {/* Flow line 3 */}
                    <div className="hidden lg:block flex-grow relative h-1 min-w-[15px] lg:min-w-[10px] xl:min-w-[30px] bg-zinc-900">
                      <div className={`absolute inset-0 bg-[#c5a059]/40 transition-opacity duration-300 ${hasPower ? 'opacity-100' : 'opacity-0'}`}></div>
                    </div>

                    {/* Flow line 3 (Mobile vertical) */}
                    <div className="block lg:hidden w-1 h-8 bg-zinc-900 relative my-1">
                      <div className={`absolute inset-0 bg-[#c5a059]/40 transition-opacity duration-300 ${hasPower ? 'opacity-100' : 'opacity-0'}`}></div>
                      {hasPower && (
                        <span className="absolute w-1.5 h-1.5 rounded-full bg-[#c5a059] left-1/2 -translate-x-1/2 top-0 animate-[ping_1.5s_infinite]"></span>
                      )}
                    </div>

                    {/* 4. CONTACT BLOCK */}
                    <div className="flex flex-col items-center z-10 flex-shrink-0">
                      <div className={`p-4 lg:p-2 xl:p-4 rounded-none border transition-all duration-300 text-center w-36 lg:w-28 xl:w-36 relative ${
                        isContactorClosed ? 'bg-zinc-900 border-[#c5a059]/40 text-white' :
                        'bg-zinc-900/40 border-white/5 text-zinc-500'
                      }`}>
                        {multimeterActive && (
                          <div className="absolute -top-3 -right-3">
                            {renderTestPoint('TP4')}
                          </div>
                        )}
                        <div className="flex justify-center gap-1.5 mb-2 lg:mb-1 xl:mb-2">
                          <span className={`w-2 h-6 lg:h-4 xl:h-6 border transition-colors ${isContactorClosed ? 'bg-[#c5a059] border-[#c5a059]' : 'bg-zinc-800 border-zinc-700'}`}></span>
                          <span className={`w-2 h-6 lg:h-4 xl:h-6 border transition-colors ${isContactorClosed ? 'bg-[#c5a059] border-[#c5a059]' : 'bg-zinc-800 border-zinc-700'}`}></span>
                        </div>
                        <div className="text-xs font-bold font-serif italic">Stykač KM1</div>
                        <div className="text-[9px] font-mono mt-1 uppercase tracking-tight">{isContactorClosed ? 'SEPNUTO' : 'OTEVŘENO'}</div>
                      </div>
                    </div>

                    {/* Flow line 4 */}
                    <div className="hidden lg:block flex-grow relative h-1 min-w-[15px] lg:min-w-[10px] xl:min-w-[30px] bg-zinc-900">
                      <div className={`absolute inset-0 bg-[#c5a059]/40 transition-opacity duration-300 ${isMotorRunning ? 'opacity-100' : 'opacity-0'}`}></div>
                    </div>

                    {/* Flow line 4 (Mobile vertical) */}
                    <div className="block lg:hidden w-1 h-8 bg-zinc-900 relative my-1">
                      <div className={`absolute inset-0 bg-[#c5a059]/40 transition-opacity duration-300 ${isMotorRunning ? 'opacity-100' : 'opacity-0'}`}></div>
                      {isMotorRunning && (
                        <span className="absolute w-1.5 h-1.5 rounded-full bg-[#c5a059] left-1/2 -translate-x-1/2 top-0 animate-[ping_1.5s_infinite]"></span>
                      )}
                    </div>

                    {/* 5. MOTOR / LOAD BLOCK */}
                    <div className="flex flex-col items-center z-10 flex-shrink-0">
                      <div className={`p-5 lg:p-3 xl:p-5 rounded-none border transition-all duration-300 text-center w-40 lg:w-32 xl:w-40 relative overflow-hidden ${
                        isMotorRunning ? 'bg-[#1b1710] border-[#c5a059] text-white shadow-[0_0_25px_rgba(197,160,89,0.1)]' :
                        'bg-zinc-900/40 border-white/5 text-zinc-500'
                      }`}>
                        {/* Active gold overlay */}
                        {isMotorRunning && (
                          <div className="absolute inset-0 bg-gradient-to-t from-[#c5a059]/5 to-transparent animate-pulse pointer-events-none"></div>
                        )}
                        
                        <div className="relative mx-auto mb-3 lg:mb-1.5 xl:mb-3 w-14 h-14 lg:w-10 lg:h-10 xl:w-14 xl:h-14 flex items-center justify-center rounded-full bg-black border border-white/10 shadow-inner">
                          <Cog className={`w-9 h-9 lg:w-6 lg:h-6 xl:w-9 xl:h-9 ${isMotorRunning ? 'text-[#c5a059] animate-spin' : 'text-zinc-700'}`} />
                        </div>
                        <div className="text-xs font-bold uppercase tracking-wider font-serif italic">Asynchron. motor</div>
                        <div className="text-[9px] font-mono mt-1">
                          {isMotorRunning ? '⚡ V PROVOZU (2910 ot/min)' : '🔴 VYPNUTO'}
                        </div>
                      </div>
                    </div>

                  </div>

                  {/* Rails Section (N and PE) */}
                  {multimeterActive && (
                    <div className="mt-8 pt-6 border-t border-white/10 grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* N Rail */}
                      <div className="bg-zinc-900/50 border border-blue-900/20 p-3 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-2.5 h-10 bg-blue-600 rounded-none"></div>
                          <div>
                            <div className="text-xs font-bold text-white uppercase tracking-wider">Nulová sběrnice (N)</div>
                            <div className="text-[10px] font-mono text-blue-400">Potenciál: 0 V (Neutral)</div>
                          </div>
                        </div>
                        {renderTestPoint('TP5')}
                      </div>

                      {/* PE Rail */}
                      <div className="bg-zinc-900/50 border border-emerald-900/20 p-3 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-2.5 h-10 bg-gradient-to-b from-green-500 via-yellow-400 to-green-500 rounded-none"></div>
                          <div>
                            <div className="text-xs font-bold text-white uppercase tracking-wider">Ochranná sběrnice (PE)</div>
                            <div className="text-[10px] font-mono text-emerald-400">Potenciál: 0 V (Earth)</div>
                          </div>
                        </div>
                        {renderTestPoint('TP6')}
                      </div>
                    </div>
                  )}

                </div>

                {/* MULTIMETER INSTRUMENT PANEL */}
                {multimeterActive && (
                  <div className="lg:col-span-4 bg-[#121212] border border-white/10 rounded-none p-5 shadow-2xl flex flex-col justify-between space-y-5 relative">
                    
                    {/* Industrial/Fluke Branding strip */}
                    <div className="flex justify-between items-center pb-2 border-b border-white/5">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2.5 h-2.5 bg-[#c5a059] rounded-none"></div>
                        <span className="text-[10px] font-mono tracking-widest font-black text-[#c5a059]">VOLT-CRAFTER 3000</span>
                      </div>
                      <span className="text-[8px] font-mono text-zinc-500">CAT III 600V</span>
                    </div>

                    {/* Digital LED screen */}
                    <div className="bg-black/80 border border-zinc-800 p-4 rounded-none relative shadow-inner flex flex-col justify-between h-28">
                      <div className="flex justify-between items-center">
                        <span className="text-[8px] font-mono text-zinc-500 uppercase tracking-widest">
                          {multimeterMode === 'V_AC' ? 'Střídavé napětí (AC)' : multimeterMode === 'continuity' ? 'Měření spojitosti' : 'VYPNUTO'}
                        </span>
                        {multimeterMode === 'continuity' && isContinuous && (
                          <span className="text-[9px] font-mono text-emerald-400 animate-pulse flex items-center gap-1">
                            🔊 PROPOJENO
                          </span>
                        )}
                      </div>

                      <div className="flex items-baseline justify-end gap-1.5 font-mono text-right mt-2 select-none">
                        {multimeterMode === 'off' ? (
                          <span className="text-3xl text-zinc-800 tracking-widest font-light">OFF</span>
                        ) : (!probeRed || !probeBlack) ? (
                          <span className="text-3xl text-zinc-600 tracking-widest font-light">---.-</span>
                        ) : (
                          <span className={`text-4xl font-bold tracking-widest ${measuredVoltage !== null && measuredVoltage > 50 ? 'text-[#ff9900] drop-shadow-[0_0_10px_rgba(255,153,0,0.3)]' : 'text-zinc-300'}`}>
                            {multimeterMode === 'V_AC' ? (
                              measuredVoltage !== null ? (measuredVoltage > 50 ? (measuredVoltage + flickerVal) : measuredVoltage).toFixed(1) : '0.0'
                            ) : (
                              isContinuous ? '0.1' : 'O.L'
                            )}
                          </span>
                        )}
                        <span className="text-xs text-zinc-500 font-bold uppercase">
                          {multimeterMode === 'V_AC' ? 'V~' : multimeterMode === 'continuity' ? 'Ω' : ''}
                        </span>
                      </div>

                      <div className="flex justify-between items-center border-t border-white/5 pt-1 text-[8px] font-mono text-zinc-500">
                        <span>AUTO RANGE</span>
                        <span>
                          {!probeRed && !probeBlack ? 'Bez hrotů' : (probeRed && probeBlack) ? 'Měření aktivní' : 'Chybí hrot'}
                        </span>
                      </div>
                    </div>

                    {/* Mode Selector (Dial simulation as sleek buttons) */}
                    <div className="space-y-2">
                      <label className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest block">Otočný volič funkcí:</label>
                      <div className="grid grid-cols-3 gap-1.5">
                        <button
                          onClick={() => setMultimeterMode('V_AC')}
                          className={`py-1.5 text-[9px] font-mono font-bold uppercase rounded-none border transition-all ${
                            multimeterMode === 'V_AC'
                              ? 'bg-[#c5a059] border-[#c5a059] text-black'
                              : 'bg-zinc-950 border-white/5 text-zinc-400 hover:text-white hover:border-white/10'
                          }`}
                        >
                          Napětí V~
                        </button>
                        <button
                          onClick={() => setMultimeterMode('continuity')}
                          className={`py-1.5 text-[9px] font-mono font-bold uppercase rounded-none border transition-all ${
                            multimeterMode === 'continuity'
                              ? 'bg-[#c5a059] border-[#c5a059] text-black'
                              : 'bg-zinc-950 border-white/5 text-zinc-400 hover:text-white hover:border-white/10'
                          }`}
                        >
                          Spojitost 🔊
                        </button>
                        <button
                          onClick={() => setMultimeterMode('off')}
                          className={`py-1.5 text-[9px] font-mono font-bold uppercase rounded-none border transition-all ${
                            multimeterMode === 'off'
                              ? 'bg-zinc-800 border-zinc-700 text-zinc-300'
                              : 'bg-zinc-950 border-white/5 text-zinc-400 hover:text-white hover:border-white/10'
                          }`}
                        >
                          Vypnout
                        </button>
                      </div>
                    </div>

                    {/* Probes Connection & Placement Panel */}
                    <div className="space-y-3 bg-black/40 border border-white/5 p-3 rounded-none">
                      <div className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest border-b border-white/5 pb-1 flex justify-between">
                        <span>Připojení měřicích hrotů</span>
                        <button
                          onClick={() => {
                            setProbeRed(null);
                            setProbeBlack(null);
                            setActiveProbePlacement(null);
                            addLog('Multimetr: Oba hroty byly odpojeny.');
                          }}
                          className="text-[8px] text-[#c5a059] hover:underline uppercase"
                        >
                          Odpojit oba
                        </button>
                      </div>

                      {/* Red Probe (V/Ohm) Slot */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <span className="w-1.5 h-4 bg-red-600"></span>
                          <div className="text-left">
                            <span className="text-[10px] text-zinc-400 font-bold block leading-none">Hrot V / Ω</span>
                            <span className="text-[9px] text-zinc-500 font-mono">{getTPLabel(probeRed)}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setActiveProbePlacement(activeProbePlacement === 'red' ? null : 'red');
                              setActiveSlot('red');
                            }}
                            className={`px-2 py-1 text-[8px] font-mono uppercase border rounded-none transition-all ${
                              activeProbePlacement === 'red'
                                ? 'bg-red-950 text-red-400 border-red-500 animate-pulse'
                                : activeSlot === 'red'
                                ? 'bg-zinc-900 border-red-600 text-red-500 hover:bg-zinc-800'
                                : 'bg-zinc-950 border-white/5 text-zinc-400 hover:text-white hover:border-white/10'
                            }`}
                          >
                            {activeProbePlacement === 'red' ? 'Klikni na uzel...' : 'Zvolit / Umístit'}
                          </button>
                          {probeRed && (
                            <button
                              onClick={() => {
                                setProbeRed(null);
                                addLog('Multimetr: Červený hrot odpojen.');
                              }}
                              className="p-1 bg-zinc-900 text-zinc-500 hover:text-white border border-white/5"
                              title="Odpojit červený hrot"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Black Probe (COM) Slot */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <span className="w-1.5 h-4 bg-zinc-500"></span>
                          <div className="text-left">
                            <span className="text-[10px] text-zinc-400 font-bold block leading-none">Hrot COM</span>
                            <span className="text-[9px] text-zinc-500 font-mono">{getTPLabel(probeBlack)}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setActiveProbePlacement(activeProbePlacement === 'black' ? null : 'black');
                              setActiveSlot('black');
                            }}
                            className={`px-2 py-1 text-[8px] font-mono uppercase border rounded-none transition-all ${
                              activeProbePlacement === 'black'
                                ? 'bg-zinc-900 text-zinc-400 border-zinc-500 animate-pulse'
                                : activeSlot === 'black'
                                ? 'bg-zinc-900 border-zinc-500 text-zinc-300 hover:bg-zinc-800'
                                : 'bg-zinc-950 border-white/5 text-zinc-400 hover:text-white hover:border-white/10'
                            }`}
                          >
                            {activeProbePlacement === 'black' ? 'Klikni na uzel...' : 'Zvolit / Umístit'}
                          </button>
                          {probeBlack && (
                            <button
                              onClick={() => {
                                setProbeBlack(null);
                                addLog('Multimetr: Černý hrot odpojen.');
                              }}
                              className="p-1 bg-zinc-900 text-zinc-500 hover:text-white border border-white/5"
                              title="Odpojit černý hrot"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Educational feedback text from Master */}
                    <div className="text-[10px] text-zinc-400 leading-relaxed bg-[#1b1710] border border-[#c5a059]/10 p-3 rounded-none">
                      <span className="font-mono text-[#c5a059] uppercase tracking-wider block font-bold mb-1">Rada pro měření:</span>
                      {multimeterMode === 'off' ? (
                        <p>Zapněte multimetr stisknutím tlačítka „Napětí V~“ pro měření napětí v obvodu.</p>
                      ) : (!probeRed || !probeBlack) ? (
                        <p>Chcete-li měřit napětí, umístěte <strong>červený hrot</strong> na měřený bod (L) a <strong>černý hrot</strong> na nulovou sběrnici (N) nebo kostru (PE).</p>
                      ) : multimeterMode === 'V_AC' ? (
                        measuredVoltage !== null && measuredVoltage > 50 ? (
                          <p className="text-yellow-400 font-bold">⚠️ Vodič je ŽIVÝ! Naměřeno {measuredVoltage} V AC. Nebezpečí úrazu proudem! Před prací vypněte jistič nebo chránič.</p>
                        ) : (
                          <p className="text-emerald-400">🟢 Bez napětí (0.0 V AC). Na tomto úseku můžete bezpečně pracovat. Obvod je bezpečně izolován od sítě.</p>
                        )
                      ) : (
                        isContinuous ? (
                          <p className="text-emerald-400">🔊 Okruh je celistvý (Odpor je téměř nulový). Proud může volně téci mezi vybranými body.</p>
                        ) : (
                          <p>❌ Otevřený obvod (O.L). Mezi těmito dvěma body není elektrické spojení. Rozepnuté kontakty spínače nebo přerušený vodič.</p>
                        )
                      )}
                    </div>

                  </div>
                )}
              </div>

              {/* CRITICAL ACTIONS & FAULT LOGS PANEL */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Simulated Fault triggers */}
                <div className="lg:col-span-7 bg-[#121212] border border-white/10 rounded-none p-6 space-y-4">
                  <h3 className="text-lg font-light text-white flex items-center gap-2" style={{ fontFamily: 'Georgia, serif' }}>
                    <AlertTriangle className="w-5 h-5 text-[#c5a059]" />
                    Zkratové a poruchové stavy k otestování
                  </h3>
                  <p className="text-xs text-zinc-400 leading-relaxed">
                    Ujistěte se, že je motor v chodu (RCD zapnutý, Jistič zapnutý, a stisknuté tlačítko START), 
                    poté klikněte na libovolnou poruchu a sledujte, který z prvků okamžitě zareaguje.
                  </p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                    <button
                      disabled={!hasPower}
                      onClick={() => handleSimulatedFault('short')}
                      className="p-3.5 bg-zinc-900 hover:bg-rose-950/40 text-rose-400 hover:text-white font-bold text-xs rounded-none border border-white/10 transition-all disabled:opacity-20 disabled:pointer-events-none text-center"
                    >
                      💥 Zkrat L-N (Tvrdý)
                    </button>
                    <button
                      disabled={!isMotorRunning}
                      onClick={() => handleSimulatedFault('overload')}
                      className="p-3.5 bg-zinc-900 hover:bg-orange-950/40 text-orange-400 hover:text-white font-bold text-xs rounded-none border border-white/10 transition-all disabled:opacity-20 disabled:pointer-events-none text-center"
                    >
                      🔥 Zablokování motoru
                    </button>
                    <button
                      disabled={rcdState !== 'on'}
                      onClick={() => handleSimulatedFault('leakage')}
                      className="p-3.5 bg-zinc-900 hover:bg-yellow-950/40 text-yellow-400 hover:text-white font-bold text-xs rounded-none border border-white/10 transition-all disabled:opacity-20 disabled:pointer-events-none text-center"
                    >
                      ⚡ Dotyk na kostru (Únik PE)
                    </button>
                  </div>
                </div>

                {/* Realtime diagnostic and console log */}
                <div className="lg:col-span-5 bg-[#121212] border border-white/10 rounded-none p-6 flex flex-col justify-between space-y-4">
                  <div>
                    <h3 className="text-[10px] font-mono text-[#c5a059] uppercase tracking-widest flex items-center justify-between">
                      <span>Provozní hlášení rozvaděče</span>
                      <button onClick={resetSimulator} className="text-zinc-600 hover:text-white transition">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </h3>
                    
                    <div className="mt-3 bg-black p-4 rounded-none border border-white/5 font-mono text-xs space-y-2.5 min-h-[120px]">
                      {faultLog.map((log, i) => (
                        <div key={i} className={`truncate ${i === 0 ? 'text-[#c5a059] font-bold' : 'text-zinc-500'}`}>
                          {log}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => {
                        setRcdState('on');
                        setMcbState('on');
                        setControlBtn(false);
                        setFaultLog(['Všechny jisticí prvky byly úspěšně natáhnuty.']);
                      }}
                      className="flex-grow py-2.5 px-3 bg-[#c5a059] hover:bg-white text-black font-bold rounded-none text-xs uppercase tracking-wider transition"
                    >
                      Nahodit přístroje (I)
                    </button>
                    <button
                      onClick={resetSimulator}
                      className="py-2.5 px-3 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-bold rounded-none text-xs uppercase tracking-wider transition border border-white/10"
                    >
                      Bezpečné vypnutí (0)
                    </button>
                  </div>
                </div>

              </div>


            </motion.div>
          )}

          {/* ACTIVE QUIZ WORKSPACE */}
          {appState === 'quiz' && questions.length > 0 && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {/* Progress & Current Status Bar */}
              <div className="flex justify-between items-center bg-[#121212] p-5 rounded-none border border-white/10">
                <div className="space-y-1">
                  <span className="text-[10px] font-mono text-zinc-500 font-bold tracking-widest uppercase">ZKUŠEBNÍ PROTOKOL</span>
                  <div className="text-base font-light text-white flex items-center gap-2">
                    Otázka {currentQIdx + 1} z {questions.length}
                    <span className="text-xs text-zinc-400 font-normal">({Math.round((currentQIdx/questions.length)*100)}% dokončeno)</span>
                  </div>
                </div>
                
                <div className="text-right">
                  <span className="text-[10px] font-mono text-zinc-500 font-bold tracking-widest uppercase">DOSAVADNÍ SKÓRE</span>
                  <div className="text-base font-light text-[#c5a059] flex items-center gap-1.5 justify-end">
                    <Check className="w-4 h-4" /> {score} / {questions.length}
                  </div>
                </div>
              </div>

              {/* Horizontal Progress bar */}
              <div className="w-full bg-zinc-950 h-1.5 rounded-none overflow-hidden border border-white/10">
                <div 
                  className="bg-[#c5a059] h-full transition-all duration-300"
                  style={{ width: `${((currentQIdx + 1) / questions.length) * 100}%` }}
                ></div>
              </div>

              {/* THE QUESTIONS INTERACTIVE WRAPPER */}
              <div className="bg-[#121212] border border-white/10 rounded-none p-8 md:p-12 space-y-8 relative">
                
                {/* Floating category badge */}
                <div className="flex flex-wrap gap-2 items-center justify-between border-b border-white/5 pb-4">
                  <span className="px-3 py-1 bg-zinc-900 text-[#c5a059] border border-[#c5a059]/20 rounded-none font-mono text-[10px] uppercase tracking-widest">
                    {questions[currentQIdx].type === 'multiple-choice' && 'Teorie • Výběr z možností'}
                    {questions[currentQIdx].type === 'true-false' && 'Teorie • Pravda / Lež'}
                    {questions[currentQIdx].type === 'calculation' && 'Praktický výpočet'}
                    {questions[currentQIdx].type === 'identification' && 'Určení vodičů'}
                    {questions[currentQIdx].type === 'circuit-build' && 'Praktické zapojení'}
                  </span>

                  <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">KÓD OTÁZKY: #EL{questions[currentQIdx].id}</span>
                </div>

                {/* Core Question text */}
                <h2 className="text-2xl md:text-3xl font-light tracking-tight text-white leading-normal" style={{ fontFamily: 'Georgia, serif' }}>
                  {questions[currentQIdx].text}
                </h2>

                {/* RENDER DYNAMIC ANSWER PANEL */}
                {!feedback ? (
                  <div className="pt-4">
                    
                    {/* TYPE 1: MULTIPLE CHOICE */}
                    {questions[currentQIdx].type === 'multiple-choice' && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {(questions[currentQIdx] as any).options.map((option: string, idx: number) => (
                          <button
                            key={idx}
                            onClick={() => handleQuizAnswerSubmit(idx === (questions[currentQIdx] as any).correct, option)}
                            className="p-5 text-left bg-zinc-950 hover:bg-zinc-900 text-zinc-300 hover:text-white rounded-none border border-white/10 hover:border-[#c5a059]/50 font-medium text-sm md:text-base transition duration-200 flex items-center justify-between group"
                          >
                            <span>{option}</span>
                            <span className="w-7 h-7 rounded-none bg-zinc-900 group-hover:bg-[#c5a059]/10 text-zinc-500 group-hover:text-[#c5a059] font-mono text-xs flex items-center justify-center border border-white/10">
                              {String.fromCharCode(65 + idx)}
                            </span>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* TYPE 2: TRUE FALSE */}
                    {questions[currentQIdx].type === 'true-false' && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <button
                          onClick={() => handleQuizAnswerSubmit(true === (questions[currentQIdx] as any).correct, "PRAVDA")}
                          className="p-6 bg-zinc-950 hover:bg-[#1b1710] hover:border-[#c5a059] text-[#c5a059] font-bold rounded-none border border-white/10 transition text-base uppercase tracking-widest flex flex-col items-center gap-3"
                        >
                          <Check className="w-6 h-6" />
                          <span>TO JE PRAVDA</span>
                        </button>
                        <button
                          onClick={() => handleQuizAnswerSubmit(false === (questions[currentQIdx] as any).correct, "LEŽ")}
                          className="p-6 bg-zinc-950 hover:bg-rose-950/20 hover:border-rose-900 text-rose-400 hover:text-rose-300 font-bold rounded-none border border-white/10 transition text-base uppercase tracking-widest flex flex-col items-center gap-3"
                        >
                          <X className="w-6 h-6" />
                          <span>TO JE NESMYSL / LEŽ</span>
                        </button>
                      </div>
                    )}

                    {/* TYPE 3: CALCULATION INPUT */}
                    {questions[currentQIdx].type === 'calculation' && (
                      <CalculationAnswerForm 
                        expectedValue={(questions[currentQIdx] as any).expectedValue}
                        onSubmit={(isCorrect, val) => handleQuizAnswerSubmit(isCorrect, val)}
                      />
                    )}

                    {/* TYPE 4: IDENTIFICATION CHOOSE */}
                    {questions[currentQIdx].type === 'identification' && (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {(questions[currentQIdx] as any).options.map((option: any) => (
                          <button
                            key={option.id}
                            onClick={() => handleQuizAnswerSubmit(option.id === (questions[currentQIdx] as any).target, option.label)}
                            className={`p-6 text-center border rounded-none transition font-bold text-base flex flex-col items-center gap-3 bg-zinc-950 ${
                              option.id === 'brown-wire' ? 'border-amber-700/60 hover:border-amber-500 text-amber-300' :
                              option.id === 'blue-wire' ? 'border-blue-600/60 hover:border-blue-500 text-blue-300' :
                              option.id === 'green-yellow-wire' ? 'border-emerald-500/60 hover:border-emerald-400 text-emerald-300' :
                              'border-white/10 hover:border-white text-zinc-300'
                            }`}
                          >
                            <div className={`w-8 h-8 rounded-full ${
                              option.id === 'brown-wire' ? 'bg-amber-800' :
                              option.id === 'blue-wire' ? 'bg-blue-600' :
                              option.id === 'green-yellow-wire' ? 'bg-gradient-to-br from-green-500 via-yellow-400 to-green-500' :
                              'bg-zinc-700'
                            }`}></div>
                            <span>{option.label}</span>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* TYPE 5: INTERACTIVE CIRCUIT BUILDER */}
                    {questions[currentQIdx].type === 'circuit-build' && (
                      <CircuitBuilderWorkspace 
                        task={questions[currentQIdx] as any}
                        onSubmit={(isCorrect, summary) => handleQuizAnswerSubmit(isCorrect, summary)}
                      />
                    )}

                  </div>
                ) : (
                  
                  /* FEEDBACK STATE: Correct / Incorrect explanation from Master */
                  <div className={`mt-6 p-6 rounded-none border ${
                    feedback === 'correct' ? 'border-[#c5a059] bg-[#1b1710]' : 'border-rose-900 bg-[#1e1313]'
                  } space-y-5`}>
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-black ${
                        feedback === 'correct' ? 'bg-[#c5a059]' : 'bg-rose-500'
                      }`}>
                        {feedback === 'correct' ? <Check className="w-5 h-5 font-bold" /> : <X className="w-5 h-5 font-bold" />}
                      </div>
                      <div>
                        <h4 className="font-serif italic text-lg text-white">
                          {feedback === 'correct' ? 'Skvěle! Správná odpověď.' : 'Pozor chlapče, tohle je špatně!'}
                        </h4>
                        <p className="text-xs text-zinc-400 mt-0.5">Tvoje odpověď byla vyhodnocena mistrem.</p>
                      </div>
                    </div>

                    <div className="bg-black p-5 rounded-none border border-white/5">
                      <div className="text-[#c5a059] text-[10px] font-mono mb-2 flex items-center gap-1.5 uppercase font-bold tracking-widest">
                        <GraduationCap className="w-4 h-4" /> Vysvětlení od Mistra:
                      </div>
                      <p className="text-zinc-200 text-sm md:text-base leading-relaxed font-sans">
                        {questions[currentQIdx].explanation}
                      </p>
                    </div>

                    <button
                      onClick={nextQuestion}
                      className="w-full sm:w-auto px-6 py-3.5 bg-white text-black font-bold text-xs uppercase tracking-widest rounded-none hover:bg-[#c5a059] hover:text-white transition duration-150 flex items-center justify-center gap-2 shadow-md"
                    >
                      {currentQIdx < questions.length - 1 ? 'Další otázka' : 'Zobrazit celkové výsledky'} <ArrowLeft className="w-4 h-4 rotate-180" />
                    </button>
                  </div>

                )}


              </div>

            </motion.div>
          )}

          {/* RESULTS DISPLAY SCREEN */}
          {appState === 'results' && (
            <motion.div
              key="results"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-10"
            >
              {/* Header result */}
              <div className="text-center space-y-3">
                <span className="px-3 py-1 bg-zinc-900 text-[#c5a059] border border-[#c5a059]/20 rounded-none text-[10px] font-mono uppercase tracking-widest font-bold">
                  ZKOUŠKA ELEKTRO ODPOVĚDNOSTI DOKONČENA
                </span>
                <h2 className="text-3xl md:text-5xl font-light text-white tracking-tight" style={{ fontFamily: 'Georgia, serif' }}>Osobní zkušební protokol</h2>
              </div>

              {/* Master Verdict Block */}
              <div className={`p-6 md:p-10 rounded-none border ${masterRating.color || 'border-white/10 bg-[#121212]'} flex flex-col md:flex-row gap-8 items-center shadow-xl`}>
                <div className="relative">
                  {/* Visual Circle Gauge */}
                  <div className="w-36 h-36 rounded-full flex items-center justify-center bg-zinc-950 border border-white/10 shadow-inner">
                    <div className="text-center">
                      <div className="text-4xl font-light text-white font-serif">{scorePercent}%</div>
                      <div className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest mt-1">Úspěšnost</div>
                    </div>
                  </div>
                  <div className="absolute -bottom-1 -right-1 bg-zinc-900 p-2 border border-white/10 rounded-none">
                    <Award className="w-5 h-5 text-[#c5a059]" />
                  </div>
                </div>

                <div className="space-y-3 text-center md:text-left flex-grow">
                  <h3 className="text-2xl font-light text-white" style={{ fontFamily: 'Georgia, serif' }}>{masterRating.title}</h3>
                  <p className="text-zinc-300 text-sm md:text-base leading-relaxed font-sans italic">
                    "{masterRating.msg}"
                  </p>
                  <div className="flex gap-3 items-center justify-center md:justify-start font-mono text-[10px] text-zinc-500 uppercase tracking-wider pt-1">
                    <span>Celkem bodů: <strong className="text-white">{score} z {questions.length}</strong></span>
                    <span>•</span>
                    <span>Zkoušeno v: <strong className="text-[#c5a059]">nn 230/400V</strong></span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center border-t border-b border-white/10 py-6">
                <button
                  onClick={startQuiz}
                  className="px-6 py-3.5 bg-white hover:bg-[#c5a059] text-black hover:text-white font-bold text-xs uppercase tracking-widest rounded-none transition duration-200 flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" /> Spustit zcela nový test
                </button>
                <button
                  onClick={() => setAppState('theory')}
                  className="px-6 py-3.5 bg-zinc-900 hover:bg-white hover:text-black text-zinc-200 font-bold text-xs uppercase tracking-widest rounded-none transition duration-200 flex items-center justify-center gap-2 border border-white/10"
                >
                  <Wrench className="w-4 h-4" /> Procvičovat trenažér
                </button>
                <button
                  onClick={() => setAppState('intro')}
                  className="px-6 py-3.5 bg-zinc-950 hover:bg-zinc-900 text-zinc-400 font-bold text-xs uppercase tracking-widest rounded-none transition duration-200 flex items-center justify-center gap-2 border border-white/5"
                >
                  <ArrowLeft className="w-4 h-4" /> Hlavní rozcestník
                </button>
              </div>

              {/* Detailed Question Review List */}
              <div className="space-y-6">
                <h3 className="text-xs font-mono text-zinc-400 uppercase tracking-widest flex items-center gap-2">
                  <Grid className="w-4 h-4 text-[#c5a059]" />
                  PROHLÍDKA PROTOKOLU ODPOVĚDÍ
                </h3>

                <div className="space-y-6">
                  {answers.map((answer, index) => (
                    <div 
                      key={index} 
                      className={`p-6 rounded-none border bg-[#121212] ${
                        answer.isCorrect ? 'border-[#c5a059]/40' : 'border-rose-950/70'
                      } space-y-4`}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="space-y-1">
                          <span className="text-[9px] font-mono text-zinc-500 font-bold uppercase tracking-widest">OTÁZKA {index + 1}</span>
                          <h4 className="font-light text-white text-base font-serif">
                            {answer.question.text}
                          </h4>
                        </div>
                        <span className={`px-2.5 py-1 rounded-none text-[10px] font-mono font-bold tracking-wider flex items-center gap-1.5 flex-shrink-0 ${
                          answer.isCorrect ? 'bg-[#c5a059]/10 text-[#c5a059] border border-[#c5a059]/20' : 'bg-rose-950/40 text-rose-400 border border-rose-900/40'
                        }`}>
                          {answer.isCorrect ? <Check className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
                          {answer.isCorrect ? 'SPRÁVNĚ' : 'CHYBA'}
                        </span>
                      </div>

                      {answer.userValue && (
                        <div className="text-xs font-mono text-zinc-400 bg-black p-3 rounded-none border border-white/5">
                          Zadaná odpověď: <strong className="text-white">{answer.userValue}</strong>
                        </div>
                      )}

                      <div className="bg-[#0a0a0a] p-4 rounded-none border border-white/5 text-xs text-zinc-300 leading-relaxed space-y-1">
                        <span className="text-[10px] font-mono text-[#c5a059] font-bold uppercase tracking-wider block">RADA MISTRA:</span>
                        <p className="font-sans">{answer.question.explanation}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* Footer & Responsiveness monitor */}
      <footer className="border-t border-white/10 bg-black py-8 mt-16">
        <div className="max-w-6xl mx-auto px-6 space-y-6">
          
          {/* Realtime Window Size & Responsiveness Monitor Panel */}
          <div className="bg-zinc-950 p-4 border border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="w-2 h-2 rounded-full bg-[#c5a059] animate-pulse"></span>
              <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">
                MONITOR RESPONSIVITY PROHLÍŽEČE:
              </span>
              <span className="px-2.5 py-0.5 bg-zinc-900 border border-white/10 text-white font-mono text-[10px] rounded-none">
                {windowSize.width} × {windowSize.height} PX
              </span>
            </div>
            
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest">Aktivní režim rozhraní:</span>
              <span className={`px-2 py-0.5 font-mono text-[9px] uppercase font-bold border ${
                windowSize.width < 640 
                  ? 'bg-amber-950/40 border-amber-500 text-amber-400' 
                  : windowSize.width < 1024 
                  ? 'bg-blue-950/40 border-blue-500 text-blue-400'
                  : 'bg-emerald-950/40 border-emerald-500 text-emerald-400'
              }`}>
                {windowSize.width < 640 
                  ? 'Mobilní rozhraní (< 640px)' 
                  : windowSize.width < 1024 
                  ? 'Tablet / Střední displej (640px - 1024px)'
                  : 'Desktop / Velký displej (>= 1024px)'
                }
              </span>
              <span className="text-emerald-500 font-mono text-[9px] tracking-wider font-bold flex items-center gap-1">
                <span>●</span> 100% OPTIMALIZOVÁNO
              </span>
            </div>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] font-mono text-zinc-500 uppercase tracking-widest">
            <div>
              © 2026 Interaktivní výcvik elektrikářů nn • NV 194/2022 Sb.
            </div>
            <div className="flex items-center gap-4">
              <span className="text-[#c5a059]">Měřicí trenažér v1.4.0</span>
              <span className="text-zinc-800">|</span>
              <span>ČSN EN 50110-1 kompatibilní</span>
            </div>
          </div>
        </div>
      </footer>


    </div>
  );
}

// ==========================================
// SUB-COMPONENT: CALCULATION ANSWER FORM
// ==========================================
interface CalculationFormProps {
  expectedValue: number;
  onSubmit: (isCorrect: boolean, value: string) => void;
}

function CalculationAnswerForm({ expectedValue, onSubmit }: CalculationFormProps) {
  const [val, setVal] = useState<string>('');
  
  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!val.trim()) return;
    const cleaned = val.replace(',', '.');
    const parsed = parseFloat(cleaned);
    
    // Check with tolerance
    const isCorrect = Math.abs(parsed - expectedValue) < 0.01;
    onSubmit(isCorrect, val);
  };

  return (
    <form onSubmit={handleSubmit} className="p-6 bg-black rounded-none border border-white/10 space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-stretch">
        <div className="relative flex-grow">
          <input 
            type="text" 
            value={val}
            onChange={(e) => setVal(e.target.value)}
            className="w-full px-4 py-3 bg-zinc-950 border border-white/10 rounded-none text-lg font-mono text-white focus:outline-none focus:border-[#c5a059] placeholder-zinc-700 transition"
            placeholder="Zadej pouze vypočítané číslo..."
            required
            autoFocus
          />
          <Calculator className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500 pointer-events-none" />
        </div>
        <button 
          type="submit" 
          className="px-6 py-3 bg-[#c5a059] hover:bg-white hover:text-black text-black font-bold rounded-none transition flex items-center justify-center gap-2 text-xs uppercase tracking-widest"
        >
          Odevzdat výpočet <Check className="w-4 h-4" />
        </button>
      </div>
      <p className="text-[10px] font-mono text-zinc-500">Tip: Pokud vychází desetinné číslo, zapište ho pomocí tečky nebo čárky (např. 2.5 nebo 2,5).</p>
    </form>
  );
}

// ==========================================
// SUB-COMPONENT: CIRCUIT BUILDER WORKSPACE
// ==========================================
interface CircuitBuilderProps {
  task: {
    components: ComponentItem[];
    correctConnections: [string, string][];
  };
  onSubmit: (isCorrect: boolean, summary: string) => void;
}

function CircuitBuilderWorkspace({ task, onSubmit }: CircuitBuilderProps) {
  const [connections, setConnections] = useState<[string, string][]>([]);
  const [selectedTerminal, setSelectedTerminal] = useState<string | null>(null);

  const handleTerminalClick = (terminalId: string) => {
    if (!selectedTerminal) {
      setSelectedTerminal(terminalId);
    } else {
      if (selectedTerminal !== terminalId) {
        // Prevent duplicating same link
        const exists = connections.some(c => 
          (c[0] === selectedTerminal && c[1] === terminalId) ||
          (c[1] === selectedTerminal && c[0] === terminalId)
        );
        if (!exists) {
          setConnections(prev => [...prev, [selectedTerminal, terminalId]]);
        }
      }
      setSelectedTerminal(null);
    }
  };

  const undoLastConnection = () => {
    setConnections(prev => prev.slice(0, -1));
  };

  const clearAllConnections = () => {
    setConnections([]);
    setSelectedTerminal(null);
  };

  const checkBuildSolution = () => {
    let isCorrect = true;
    if (connections.length !== task.correctConnections.length) {
      isCorrect = false;
    } else {
      const expectedSorted = task.correctConnections.map(arr => [...arr].sort().join('-'));
      const actualSorted = connections.map(arr => [...arr].sort().join('-'));
      
      isCorrect = expectedSorted.every(exp => actualSorted.includes(exp)) &&
                  actualSorted.every(act => expectedSorted.includes(act));
    }

    const summaryStr = connections.map(pair => {
      const c1 = task.components.find(c => c.id === pair[0]);
      const c2 = task.components.find(c => c.id === pair[1]);
      return `${c1?.label} <-> ${c2?.label}`;
    }).join('; ');

    onSubmit(isCorrect, summaryStr || "Žádné vodiče zapojeny");
  };

  return (
    <div className="bg-black p-6 rounded-none border border-white/10 space-y-6">
      
      {/* Workspace Panel instructions */}
      <div className="flex items-start gap-3 text-xs text-zinc-400 font-mono bg-zinc-950 p-4 rounded-none border border-white/5">
        <Info className="w-4 h-4 text-[#c5a059] flex-shrink-0 mt-0.5" />
        <p>Kliknutím vyberte první svorku nebo vodič, poté klikněte na druhou cílovou svorku, čímž mezi nimi natáhnete drát.</p>
      </div>

      {/* Grid of terminal nodes to click */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {task.components.map((comp) => {
          const isSelected = selectedTerminal === comp.id;
          
          // Custom color classes for wires
          let borderTheme = "border-white/10 hover:border-[#c5a059]/60 bg-zinc-950";
          let labelBadge = "text-zinc-500 bg-black border border-white/5";
          
          if (isSelected) {
            borderTheme = "border-[#c5a059] bg-[#1b1710] shadow-[0_0_12px_rgba(197,160,89,0.15)]";
          } else if (comp.type === 'wire_brown') {
            borderTheme = "border-amber-700/60 hover:border-amber-600 bg-amber-950/10";
            labelBadge = "text-amber-400 bg-black border border-amber-900/10";
          } else if (comp.type === 'wire_blue') {
            borderTheme = "border-blue-600/60 hover:border-blue-500 bg-blue-950/10";
            labelBadge = "text-blue-400 bg-black border border-blue-900/10";
          } else if (comp.type === 'wire_gy') {
            borderTheme = "border-emerald-500/40 hover:border-emerald-400 bg-emerald-950/10";
            labelBadge = "text-emerald-400 bg-black border border-emerald-900/10";
          }

          return (
            <button
              key={comp.id}
              onClick={() => handleTerminalClick(comp.id)}
              className={`p-4 rounded-none border transition-all duration-200 text-center flex flex-col items-center justify-between cursor-pointer min-h-[120px] ${borderTheme}`}
            >
              <div className="text-2xl mb-1 text-zinc-500">
                {comp.type === 'switch' && <ToggleLeft className="w-7 h-7 text-[#c5a059]" />}
                {comp.type === 'load' && <Bolt className="w-7 h-7 text-[#c5a059]" />}
                {comp.type === 'source' && <Cpu className="w-7 h-7 text-[#c5a059]" />}
                {comp.type === 'terminal' && <CircleDot className="w-7 h-7 text-zinc-500" />}
                {comp.type.startsWith('wire_') && <CircleDot className="w-7 h-7 text-[#c5a059]" />}
              </div>
              <div className="space-y-1.5">
                <div className="font-bold text-xs text-white leading-tight">{comp.label}</div>
                <div className={`text-[8px] font-mono px-1.5 py-0.5 rounded-none uppercase font-bold inline-block tracking-wider ${labelBadge}`}>
                  {comp.type.startsWith('wire_') ? 'VODIČ' : 'SVORKA'}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Visual rendering of connections */}
      <div className="bg-zinc-950 p-4 rounded-none border border-white/5 space-y-2">
        <h4 className="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-widest">Natahnuté vodiče:</h4>
        {connections.length === 0 ? (
          <p className="text-xs text-zinc-600 italic font-mono">Zatím žádné dráty. Začni klikat na svorky nahoře...</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {connections.map((pair, idx) => {
              const c1 = task.components.find(c => c.id === pair[0]);
              const c2 = task.components.find(c => c.id === pair[1]);
              return (
                <div key={idx} className="bg-black px-3 py-1.5 rounded-none border border-white/10 text-xs text-zinc-300 flex items-center gap-2 font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#c5a059] animate-pulse"></span>
                  <strong>{c1?.label}</strong> ⇄ <strong>{c2?.label}</strong>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Connection Actions */}
      <div className="flex flex-wrap gap-2.5 pt-2">
        <button 
          onClick={undoLastConnection}
          disabled={connections.length === 0}
          className="px-4 py-2 bg-zinc-900 text-zinc-400 hover:bg-white hover:text-black transition font-bold text-xs uppercase tracking-wider rounded-none flex items-center gap-1.5 border border-white/10 disabled:opacity-25 disabled:pointer-events-none"
        >
          <Undo2 className="w-3.5 h-3.5" /> Odstranit poslední drát
        </button>
        <button 
          onClick={clearAllConnections}
          disabled={connections.length === 0}
          className="px-4 py-2 bg-zinc-950 text-rose-400 hover:text-rose-300 transition font-bold text-xs uppercase tracking-wider rounded-none flex items-center gap-1.5 border border-white/5 disabled:opacity-25 disabled:pointer-events-none"
        >
          <Trash2 className="w-3.5 h-3.5" /> Smazat všechno
        </button>
        
        <button 
          onClick={checkBuildSolution}
          className="ml-auto px-5 py-2.5 bg-white hover:bg-[#c5a059] hover:text-white text-black font-bold rounded-none text-xs uppercase tracking-widest transition"
        >
          Zkontrolovat zapojení
        </button>
      </div>

    </div>
  );
}
