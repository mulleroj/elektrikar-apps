import { Question } from './types';

export const fullDatabase: Question[] = [
  // 1-10: Základy elektrotechniky & Teorie
  {
    id: 1,
    type: 'multiple-choice',
    text: 'Jaká je základní jednotka elektrického proudu?',
    options: ['Volt (V)', 'Ampér (A)', 'Ohm (Ω)', 'Watt (W)'],
    correct: 1,
    explanation: 'Elektrický proud se měří v Ampérech (A).'
  },
  {
    id: 2,
    type: 'multiple-choice',
    text: 'Jak zní Ohmův zákon?',
    options: ['U = R / I', 'I = U * R', 'U = I * R', 'R = U * I'],
    correct: 2,
    explanation: 'Napětí (U) se rovná součinu proudu (I) a odporu (R): U = I * R.'
  },
  {
    id: 3,
    type: 'multiple-choice',
    text: 'Jaký je vzorec pro výpočet elektrického výkonu stejnosměrného proudu?',
    options: ['P = U * I', 'P = I / U', 'P = R * I^2', 'P = U^2 / R'],
    correct: 0,
    explanation: 'Základní vzorec pro elektrický výkon je P = U * I (napětí krát proud).'
  },
  {
    id: 4,
    type: 'true-false',
    text: 'Při sériovém zapojení rezistorů je celkový odpor roven součtu jednotlivých odporů (R = R1 + R2 + ...).',
    correct: true,
    explanation: 'V sériovém obvodu se odpory sčítají, protože proud musí projít všemi rezistory po sobě.'
  },
  {
    id: 5,
    type: 'true-false',
    text: 'Při paralelním zapojení zdrojů (např. baterií) se zvyšuje celkové napětí.',
    correct: false,
    explanation: 'Při paralelním zapojení zdrojů zůstává napětí stejné (musí mít stejné jmenovité napětí), zvyšuje se však celková kapacita a dostupný proud. Napětí se sčítá při sériovém zapojení.'
  },
  {
    id: 6,
    type: 'multiple-choice',
    text: 'Která součástka propouští proud pouze jedním směrem?',
    options: ['Kondenzátor', 'Cívka', 'Rezistor', 'Dioda'],
    correct: 3,
    explanation: 'Dioda funguje jako jednosměrný ventil pro elektrický proud (v propustném směru).'
  },
  {
    id: 7,
    type: 'multiple-choice',
    text: 'K čemu slouží kondenzátor v obvodu střídavého proudu?',
    options: ['Zvyšuje napětí', 'Vytváří fázový posun mezi napětím a proudem', 'Mění střídavý proud na stejnosměrný', 'Chrání obvod před zkratem'],
    correct: 1,
    explanation: 'Kondenzátor v obvodu střídavého proudu způsobuje fázový posun, kdy proud předbíhá napětí o 90 stupňů.'
  },
  {
    id: 8,
    type: 'multiple-choice',
    text: 'Jaká je frekvence střídavého proudu v běžné rozvodné síti v ČR?',
    options: ['60 Hz', '50 Hz', '100 Hz', '400 Hz'],
    correct: 1,
    explanation: 'V Evropě včetně České republiky je standardní síťová frekvence 50 Hz.'
  },
  {
    id: 9,
    type: 'multiple-choice',
    text: 'Jak se nazývá vodič spojující nulový bod zdroje s neživými částmi spotřebiče v síti TN-C?',
    options: ['Fázový vodič (L)', 'Ochranný vodič (PE)', 'Střední vodič (N)', 'Kombinovaný vodič (PEN)'],
    correct: 3,
    explanation: 'V síti TN-C plní jeden společný vodič (PEN) funkci ochranného (PE) i pracovního nulového (N) vodiče.'
  },
  {
    id: 10,
    type: 'multiple-choice',
    text: 'Co znamená zkratka RCD v elektrotechnice?',
    options: ['Rotary Current Device', 'Residual Current Device (Proudový chránič)', 'Resistance Control Display', 'Relay Circuit Direct'],
    correct: 1,
    explanation: 'RCD (Residual Current Device) je mezinárodní označení pro proudový chránič, který chrání před nebezpečným dotykem.'
  },

  // 11-20: Bezpečnost a legislativa (NV 194/2022 Sb.)
  {
    id: 11,
    type: 'true-false',
    text: 'Osoba poučená (§ 4 NV 194/2022 Sb.) smí samostatně pracovat na vypnutém zařízení vysokého napětí (vn).',
    correct: false,
    explanation: 'Na zařízeních vn smí samostatně pracovat pouze osoba znalá (elektrotechnik) po zaškolení. Osoba poučená může na vn pracovat pouze pod dohledem osoby znalé.'
  },
  {
    id: 12,
    type: 'multiple-choice',
    text: 'Kdo určuje vnější vlivy působící na elektrické zařízení podle norem ČSN?',
    options: ['Revizní technik', 'Odborná komise', 'Majitel objektu', 'Elektrikář na stavbě'],
    correct: 1,
    explanation: 'O určení vnějších vlivů rozhoduje komise složená z odborníků (projektant, technolog, bezpečnostní technik atd.) a vypracovává o tom závazný protokol.'
  },
  {
    id: 13,
    type: 'multiple-choice',
    text: 'Jaký je bezpečný střídavý proud (mez uvolnění) pro člověka při frekvenci 50Hz?',
    options: ['Cca 10 mA', 'Cca 30 mA', 'Cca 50 mA', 'Cca 100 mA'],
    correct: 0,
    explanation: 'Při proudech nad 10 mA střídavých nastávají svalové křeče a postižený se často nedokáže sám uvolnit od zdroje.'
  },
  {
    id: 14,
    type: 'multiple-choice',
    text: 'Jaká barva se používá výhradně pro ochranný vodič (PE)?',
    options: ['Modrá', 'Zeleno-žlutá', 'Hnědá', 'Černá'],
    correct: 1,
    explanation: 'Zeleno-žlutá kombinace je mezinárodně vyhrazena výhradně pro ochranné vodiče (PE).'
  },
  {
    id: 15,
    type: 'multiple-choice',
    text: 'Která zóna v koupelně označuje vnitřní prostor koupací vany nebo sprchové vaničky?',
    options: ['Zóna 0', 'Zóna 1', 'Zóna 2', 'Zóna 3'],
    correct: 0,
    explanation: 'Zóna 0 je přímo vnitřní prostor vany nebo sprchové vaničky. Platí zde nejpřísnější omezení na napětí a krytí.'
  },
  {
    id: 16,
    type: 'true-false',
    text: 'Běžná zásuvka 230V může být umístěna v Zóně 1 v koupelně.',
    correct: false,
    explanation: 'V zóně 1 nesmí být běžné zásuvky. Povoleny jsou pouze spínače obvodů SELV/PELV s bezpečným napětím do 12V střídavých.'
  },
  {
    id: 17,
    type: 'multiple-choice',
    text: 'Co musí být bezpodmínečně uvedeno na výrobním štítku elektrického stroje?',
    options: ['Pouze jméno výrobce', 'Jmenovité napětí, proud, kmitočet a výkon', 'Jméno elektrikáře, který stroj zapojil', 'Datum poslední revize'],
    correct: 1,
    explanation: 'Výrobní štítek musí uvádět jmenovité hodnoty (napětí, proud, frekvenci, výkon/příkon, krytí IP) pro bezpečné zapojení a provoz.'
  },
  {
    id: 18,
    type: 'true-false',
    text: 'Při poskytování první pomoci při úrazu el. proudem je nutné nejdříve odpojit postiženého od zdroje napětí nebo vypnout proud.',
    correct: true,
    explanation: 'Vždy dbejte na vlastní bezpečnost. Odpojte přívod, vypněte jistič, nebo použijte suchý nevodivý předmět k odtažení vodiče z dosahu postiženého.'
  },
  {
    id: 19,
    type: 'multiple-choice',
    text: 'K čemu slouží pět bezpečnostních pravidel před zahájením práce na elektrickém zařízení?',
    options: ['K zajištění beznapěťového stavu a bezpečnosti práce', 'K urychlení montážních prací', 'K určení odpovědnosti při nehodě', 'Je to pouze formální doporučení bez právní váhy'],
    correct: 0,
    explanation: 'Pět základních pravidel (odpojit, zajistit proti zapnutí, ověřit beznapěťový stav, uzemnit a zkratovat, ohradit živé části) zajišťuje bezpečné pracovní prostředí.'
  },
  {
    id: 20,
    type: 'multiple-choice',
    text: 'Osoba znalá v elektrotechnice (elektrotechnik podle § 6 NV 194/2022 Sb.) smí:',
    options: ['Sama provádět revize vyhrazených el. zařízení', 'Samostatně vykonávat činnosti na elektrických zařízeních v rozsahu své kvalifikace', 'Projektovat složitá přenosová vedení vvn', 'Pracovat na živých částech vn bez ochranných pomůcek'],
    correct: 1,
    explanation: 'Elektrotechnik (§ 6) má odbornou způsobilost pro samostatnou činnost na elektrických zařízeních v rozsahu svého osvědčení.'
  },

  // 21-27: Měření a výpočty (Calculations)
  {
    id: 21,
    type: 'calculation',
    text: 'Máš v sérii zapojené tři rezistory: R1 = 10 Ω, R2 = 15 Ω, R3 = 25 Ω. Vypočítej celkový odpor v Ohmech.',
    expectedValue: 50,
    explanation: 'U sériového zapojení se odpory jednoduše sčítají: R = R1 + R2 + R3 = 10 + 15 + 25 = 50 Ω.'
  },
  {
    id: 22,
    type: 'calculation',
    text: 'Žárovka má odpor 115 Ω a je připojena na síťové napětí 230 V. Jaký proud jí protéká v Ampérech?',
    expectedValue: 2,
    explanation: 'Podle Ohmova zákona: I = U / R = 230 / 115 = 2 A.'
  },
  {
    id: 23,
    type: 'calculation',
    text: 'Topné těleso odebírá proud 10 A při napětí 230 V. Jaký je jeho příkon ve Wattech?',
    expectedValue: 2300,
    explanation: 'Výkon/příkon stejnosměrného nebo jednofázového odporového spotřebiče vypočítáme jako P = U * I = 230 * 10 = 2300 W.'
  },
  {
    id: 24,
    type: 'multiple-choice',
    text: 'Jakým přístrojem se měří izolační odpor kabelu?',
    options: ['Multimetrem na rozsahu Ohm', 'Megmetem (měřič izolačního stavu)', 'Osciloskopem', 'Ampérmetrem'],
    correct: 1,
    explanation: 'Izolační odpor dosahuje desítek až stovek Megaohmů. Měří se megmetem, který k testování používá vysoké stejnosměrné napětí (např. 500 V).'
  },
  {
    id: 25,
    type: 'true-false',
    text: 'Ampérmetr se do měřeného obvodu zapojuje vždy paralelně k zátěži.',
    correct: false,
    explanation: 'Ampérmetr se zapojuje zásadně do SÉRIE se zátěží, aby jím protékal měřený proud. Paralelní zapojení by způsobilo zkrat (ampérmetr má extrémně malý vnitřní odpor).'
  },
  {
    id: 26,
    type: 'multiple-choice',
    text: 'Co znamená hodnota IP44 u elektrického zařízení?',
    options: ['Napětí maximálně 44 V', 'Chráněno před vniknutím pevných těles > 1 mm a proti stříkající vodě', 'Maximální provozní proud 44 A', 'Izolační pevnost izolantu 44 kV'],
    correct: 1,
    explanation: 'První číslice (4) značí ochranu před tělesy > 1 mm (nástrojem či drátem). Druhá číslice (4) značí ochranu proti stříkající vodě ze všech směrů.'
  },
  {
    id: 27,
    type: 'multiple-choice',
    text: 'Jaký je maximální povolený vypínací čas proudového chrániče (RCD) 30mA v síti TN pro zásuvkové obvody do 32A při střídavém napětí 230V?',
    options: ['Do 5 sekund', 'Do 1 sekundy', 'Do 0,4 sekundy', 'Do 0,2 sekundy'],
    correct: 2,
    explanation: 'Podle ČSN 33 2000-4-41 je maximální doba odpojení v síti TN pro koncové obvody do 32A rovna 0,4 s.'
  },

  // 28-31: Identifikace a zapojení (Identification & Circuit Build)
  {
    id: 28,
    type: 'identification',
    text: 'Označ na obrázku (symbolicky) Nulový pracovní vodič (N).',
    target: 'blue-wire',
    options: [
      { id: 'brown-wire', label: 'Hnědý drát (Fáze L)' },
      { id: 'blue-wire', label: 'Modrý drát (Střední N)' },
      { id: 'green-yellow-wire', label: 'Zelenožlutý drát (Ochranný PE)' }
    ],
    explanation: 'Střední (nulový pracovní) vodič N má podle norem jasně předepsanou světle modrou barvu.'
  },
  {
    id: 29,
    type: 'identification',
    text: 'Jakou barvu má vodič první fáze (L1) v běžném ohebném přívodním kabelu?',
    target: 'brown-wire',
    options: [
      { id: 'brown-wire', label: 'Hnědá' },
      { id: 'blue-wire', label: 'Modrá' },
      { id: 'green-yellow-wire', label: 'Zelenožlutá' }
    ],
    explanation: 'Fázový vodič L1 má standardně hnědou barvu (u vícefázových pevných kabelů černou nebo šedou).'
  },
  {
    id: 30,
    type: 'circuit-build',
    text: 'Sestav správné jednofázové zapojení jednopólového spínače (řazení 1) pro žárovku.',
    components: [
      { id: 'L', label: 'Fáze (L)', type: 'source' },
      { id: 'N', label: 'Nulák (N)', type: 'source' },
      { id: 'switch', label: 'Vypínač', type: 'switch' },
      { id: 'bulb', label: 'Žárovka', type: 'load' }
    ],
    correctConnections: [['L', 'switch'], ['switch', 'bulb'], ['bulb', 'N']],
    explanation: 'Fázový vodič (L) přivedeme na vstup vypínače, ze spínaného kontaktu vypínače pokračujeme na žárovku, a z druhého pólu žárovky vedeme střední nulový vodič (N) zpět.'
  },
  {
    id: 31,
    type: 'circuit-build',
    text: 'Zapojení běžné jednofázové zásuvky 230V podle českých zvyklostí. Který vodič zapojíš na ochranný kolík, levou a pravou zdířku?',
    components: [
      { id: 'L', label: 'L (Fázový - Hnědý)', type: 'wire_brown' },
      { id: 'N', label: 'N (Střední - Modrý)', type: 'wire_blue' },
      { id: 'PE', label: 'PE (Ochranný - Zelenožlutý)', type: 'wire_gy' },
      { id: 'pin_left', label: 'Levá zdířka', type: 'terminal' },
      { id: 'pin_right', label: 'Pravá zdířka', type: 'terminal' },
      { id: 'pin_earth', label: 'Ochranný kolík', type: 'terminal' }
    ],
    correctConnections: [['L', 'pin_left'], ['N', 'pin_right'], ['PE', 'pin_earth']],
    explanation: 'U české zásuvky platí pravidlo: Fáze vlevo, nulák vpravo, ochranný vodič (PE) nahoře na kolíku.'
  },

  // 32-40: Pokročilé otázky nn
  {
    id: 32,
    type: 'multiple-choice',
    text: 'Který prvek jistí obvod primárně proti zkratu a nadproudu (přetížení)?',
    options: ['Proudový chránič', 'Jistič', 'Vypínač', 'Stykač'],
    correct: 1,
    explanation: 'Jistič chrání elektrické vedení před poškozením způsobeným zkratem (elektromagnetická spoušť) a dlouhodobým přetížením (bimetal).'
  },
  {
    id: 33,
    type: 'true-false',
    text: 'Proudový chránič (RCD) omezuje velikost zkratového proudu.',
    correct: false,
    explanation: 'Proudový chránič reaguje pouze na reziduální (unikající) proud do země. Neomezuje zkratový proud mezi fází a nulákem. K tomu slouží jistič nebo pojistka.'
  },
  {
    id: 34,
    type: 'multiple-choice',
    text: 'Co znamená v elektrotechnice zkratka SELV?',
    options: ['Safety Extra Low Voltage (Bezpečné velmi malé napětí)', 'System Earth Low Voltage', 'Safe Electrical Limit Value', 'Short Earth Link Voltage'],
    correct: 0,
    explanation: 'SELV (Safety Extra Low Voltage) označuje ochranné opatření s bezpečným malým napětím, kdy je obvod zcela elektricky oddělen od sítě i od země.'
  },
  {
    id: 35,
    type: 'multiple-choice',
    text: 'Jaký průřez měděného vodiče se obvykle používá pro standardní bytové zásuvkové obvody (jištěné 16A)?',
    options: ['1.5 mm²', '2.5 mm²', '4.0 mm²', '6.0 mm²'],
    correct: 1,
    explanation: 'Pro standardní zásuvkové obvody jištěné jističem 16A se používá měděný kabel s průřezem vodičů 2.5 mm².'
  },
  {
    id: 36,
    type: 'multiple-choice',
    text: 'Jaké je jmenovité sdružené napětí (mezi dvěma fázemi) v české třífázové síti nízkého napětí (nn)?',
    options: ['230 V', '400 V', '500 V', '690 V'],
    correct: 1,
    explanation: 'Fázové napětí (mezi fází a N) je 230 V. Sdružené napětí (mezi dvěma fázemi L1 a L2) je 400 V (což odpovídá 230 V * √3).'
  },
  {
    id: 37,
    type: 'multiple-choice',
    text: 'Jak se zapojuje elektroměr pro přímé měření spotřeby?',
    options: ['Paralelně ke zátěži', 'Do série s nulovým vodičem', 'Proudová cívka sériově, napěťová cívka paralelně', 'Pouze přes měřicí transformátory proudu'],
    correct: 2,
    explanation: 'U přímého elektroměru prochází fázový proud sériově zapojenou proudovou cívkou a napěťová cívka je zapojena paralelně mezi fázi a nulu.'
  },
  {
    id: 38,
    type: 'true-false',
    text: 'Při zapojování svítidla se fáze vede přes vypínač přímo na závit objímky žárovky E27.',
    correct: false,
    explanation: 'Fáze musí z bezpečnostních důvodů vždy směřovat na spodní (středový) kontakt objímky. Závit objímky musí být zapojen na střední vodič (N), aby se zabránilo dotyku živé části při výměně žárovky.'
  },
  {
    id: 39,
    type: 'multiple-choice',
    text: 'Co je to impedance vypínací smyčky?',
    options: ['Vnitřní odpor baterie', 'Celkový odpor střídavého obvodu tvořeného fázovým a ochranným vodičem z místa poruchy ke zdroji a zpět', 'Kapacita kondenzátoru v obvodu střídavého proudu', 'Odpor cívky proti stejnosměrnému proudu'],
    correct: 1,
    explanation: 'Impedance smyčky je klíčový parametr pro ochranu samočinným odpojením od zdroje (jističem) při porušení izolace.'
  },
  {
    id: 40,
    type: 'calculation',
    text: 'Máme dvě cívky zapojené v sérii: L1 = 10 mH, L2 = 20 mH. Jaká je celková indukčnost v mH (bez vzájemné vazby)?',
    expectedValue: 30,
    explanation: 'Při sériovém zapojení bez vzájemné vazby se indukčnosti sčítají přímo: L_celk = L1 + L2 = 10 + 20 = 30 mH.'
  },

  // 41-50: Dodatečná Teorie, ČSN Normy & Bezpečnost
  {
    id: 41,
    type: 'multiple-choice',
    text: 'Podle ČSN 33 2000-4-41, jaký je limit bezpečného dotykového napětí v prostorech normálních u střídavého napětí?',
    options: ['12 V', '24 V', '50 V', '110 V'],
    correct: 2,
    explanation: 'Bezpečné dotykové střídavé napětí pro normální (suché) prostory je 50 V efektivní hodnoty.'
  },
  {
    id: 42,
    type: 'multiple-choice',
    text: 'Jaké bezpečné dotykové střídavé napětí platí pro nebezpečné prostory (vlhko, prach)?',
    options: ['12 V', '24 V', '50 V', '110 V'],
    correct: 1,
    explanation: 'V prostorách nebezpečných se snižuje bezpečné dotykové střídavé napětí na 24 V.'
  },
  {
    id: 43,
    type: 'true-false',
    text: 'Podle NV 194/2022 Sb., osoba bez elektrotechnické kvalifikace (osoba neseznámená/laik) smí sama obsluhovat jednoduchá elektrická zařízení nn pod napětím.',
    correct: true,
    explanation: 'Laici smí obsluhovat jednoduchá elektrická zařízení malého a nízkého napětí, která jsou chráněna před dotykem, např. zapínat vypínače, zapojovat spotřebiče do zásuvky.'
  },
  {
    id: 44,
    type: 'multiple-choice',
    text: 'Která třída ochrany elektrických spotřebičů používá jako hlavní způsob ochrany dvojitou nebo zesílenou izolaci a nemá ochranný vodič?',
    options: ['Třída ochrany 0', 'Třída ochrany I', 'Třída ochrany II', 'Třída ochrany III'],
    correct: 2,
    explanation: 'Spotřebiče třídy ochrany II (např. fén, ruční nářadí) mají dvojitou nebo zesílenou izolaci a nepotřebují ochranný vodič (mají plochou vidlici).'
  },
  {
    id: 45,
    type: 'multiple-choice',
    text: 'Která třída ochrany elektrických spotřebičů je napájena ze zdroje bezpečného malého napětí (SELV/PELV)?',
    options: ['Třída ochrany I', 'Třída ochrany II', 'Třída ochrany III', 'Třída ochrany IV'],
    correct: 2,
    explanation: 'Spotřebiče třídy ochrany III využívají ochranu malým bezpečným napětím (SELV nebo PELV).'
  },
  {
    id: 46,
    type: 'true-false',
    text: 'Fázový posun vyvolaný ideálním induktivním spotřebičem (např. čistou cívkou) způsobuje, že proud předbíhá napětí o 90 stupňů.',
    correct: false,
    explanation: 'U cívky (indukčnosti) se proud zpožďuje za napětím o 90 stupňů. Proud předbíhá napětí u kapacity (kondenzátoru).'
  },
  {
    id: 47,
    type: 'calculation',
    text: 'Vypočítej odpor měděného drátu v Ohmech, který má délku 100 m a odpor R = 2 Ω, pokud jej zkrátíš přesně na polovinu (50 m).',
    expectedValue: 1,
    explanation: 'Odpor vodiče je přímo úměrný jeho délce (R = ρ * l / S). Poloviční délka znamená přesně poloviční odpor: R = 1 Ω.'
  },
  {
    id: 48,
    type: 'multiple-choice',
    text: 'Co je to jalový výkon střídavého proudu a jaká je jeho jednotka?',
    options: ['Výkon užitečný pro konání mechanické práce, jednotka Watt (W)', 'Výkon kmitající mezi zdrojem a spotřebičem, jednotka Volt-Ampér reaktanční (var)', 'Celkový zdánlivý výkon v síti, jednotka Volt-Ampér (VA)', 'Ztrátový výkon přeměněný na teplo, jednotka Joule (J)'],
    correct: 1,
    explanation: 'Jalový výkon reprezentuje energii, která pulzuje mezi indukčností/kapacitou a zdrojem a nekoná užitečnou práci. Jednotkou je var.'
  },
  {
    id: 49,
    type: 'calculation',
    text: 'Elektrický bojler o příkonu 2 kW běží nepřetržitě 5 hodin. Kolik elektrické energie spotřebuje v kWh?',
    expectedValue: 10,
    explanation: 'E = P * t = 2 kW * 5 h = 10 kWh.'
  },
  {
    id: 50,
    type: 'true-false',
    text: 'Hromosvod (LPS) slouží výhradně k zachycení a bezpečnému svedení bleskového proudu do země, čímž chrání stavbu před požárem a mechanickými účinky.',
    correct: true,
    explanation: 'Správně, LPS (Lightning Protection System) zachytí blesk a bezpečně ho svede uzemňovací soustavou do země.'
  },

  // 51-60: Praktické zapojování, stroje, měření
  {
    id: 51,
    type: 'multiple-choice',
    text: 'Jaký je hlavní rozdíl mezi sítí TN-C a TN-S?',
    options: [
      'TN-C používá stejnosměrný proud, TN-S střídavý',
      'TN-C má sloučený ochranný a nulový vodič (PEN), TN-S je má oddělené (PE + N)',
      'TN-C je vysokonapěťová síť, TN-S je nízkonapěťová',
      'V síti TN-S se nepoužívají jističe, pouze chrániče'
    ],
    correct: 1,
    explanation: 'V síti TN-C je nulový a ochranný vodič sloučen do PEN. V bezpečnější síti TN-S jsou vodiče PE a N vedeny samostatně.'
  },
  {
    id: 52,
    type: 'multiple-choice',
    text: 'Který typ jističe zvolíte pro spouštění motoru s těžkým rozběhem?',
    options: ['Charakteristika A', 'Charakteristika B (pro světla a zásuvky)', 'Charakteristika C nebo D (pro indukční zátěže)', 'Charakteristika Z'],
    correct: 2,
    explanation: 'Motory mají při rozběhu vysoké rázové proudy. Jističe typu C a D mají vyšší práh elektromagnetické spouště, což zabraňuje nechtěnému vypnutí.'
  },
  {
    id: 53,
    type: 'true-false',
    text: 'Transformátor pracuje na principu elektromagnetické indukce a dokáže transformovat jak střídavé, tak stejnosměrné napětí.',
    correct: false,
    explanation: 'Transformátor funguje pouze na střídavý proud, protože k indukci je potřeba časově proměnný magnetický tok. Stejnosměrný proud netransformuje.'
  },
  {
    id: 54,
    type: 'multiple-choice',
    text: 'Jaká barva se podle norem používá pro označení druhé fáze (L2) v pevných instalacích?',
    options: ['Černá', 'Červená', 'Šedá', 'Modrá'],
    correct: 0,
    explanation: 'Tradiční sled barev pro 3-fázový kabel je: L1 = hnědá, L2 = černá, L3 = šedá.'
  },
  {
    id: 55,
    type: 'calculation',
    text: 'Vypočítej zdánlivý výkon jednofázového transformátoru ve VA, jestliže sekundární napětí je 24 V a sekundární proud je 5 A.',
    expectedValue: 120,
    explanation: 'Zdánlivý výkon S = U * I = 24 * 5 = 120 VA.'
  },
  {
    id: 56,
    type: 'true-false',
    text: 'Ochranné pospojování (hlavní uzemňovací přípojnice) slouží ke sjednocení potenciálů kovových částí budovy za účelem snížení dotykového napětí.',
    correct: true,
    explanation: 'Ano, pospojováním kovových trubek, konstrukcí a rámů se zamezí nebezpečným rozdílům napětí mezi nimi.'
  },
  {
    id: 57,
    type: 'multiple-choice',
    text: 'Jaký jmenovitý reziduální proud musí mít proudový chránič pro doplňkovou ochranu zásuvek určených pro všeobecné použití laiky?',
    options: ['10 mA', '30 mA', '100 mA', '300 mA'],
    correct: 1,
    explanation: 'Pro doplňkovou ochranu před úrazem el. proudem se standardně předepisuje citlivý chránič s IΔn nepřesahujícím 30 mA.'
  },
  {
    id: 58,
    type: 'calculation',
    text: 'Vypočítej odpor topné spirály v Ohmech, která při napětí 200 V odebírá proud 5 A.',
    expectedValue: 40,
    explanation: 'R = U / I = 200 / 5 = 40 Ω.'
  },
  {
    id: 59,
    type: 'multiple-choice',
    text: 'Jaký je princip fungování bimetalové spouště v jističi?',
    options: [
      'Reaguje na magnetické pole zkratu',
      'Využívá rozdílnou tepelnou roztažnost dvou spojených kovů zahřívaných protékajícím proudem',
      'Pracuje na principu piezoelektrického jevu',
      'Měří frekvenci sítě elektronicky'
    ],
    correct: 1,
    explanation: 'Bimetal se při průchodu nadproudu zahřívá a ohýbá v důsledku rozdílné roztažnosti kovů, což po určitém čase mechanicky vybaví jistič.'
  },
  {
    id: 60,
    type: 'true-false',
    text: 'Vodič PEN se v domovním rozvaděči smí rozdělit na PE a N. Po tomto rozdělení se však tyto vodiče již nesmí nikde v instalaci znovu spojit.',
    correct: true,
    explanation: 'Přesně tak. Po rozdělení PEN na PE a N získáme síť TN-S. Jakékoliv opětovné spojení by vyřadilo z provozu proudové chrániče a způsobilo nebezpečné bludné proudy.'
  },

  // 61-70: Fotovoltaika, baterie, moderní technologie
  {
    id: 61,
    type: 'multiple-choice',
    text: 'Jaký proud produkují samotné solární fotovoltaické články?',
    options: ['Vždy střídavý (AC)', 'Vždy stejnosměrný (DC)', 'Vysokofrekvenční střídavý', 'Pulzní třífázový'],
    correct: 1,
    explanation: 'Fotovoltaické panely generují přímým dopadem světla stejnosměrný (DC) proud.'
  },
  {
    id: 62,
    type: 'multiple-choice',
    text: 'Které zařízení přeměňuje stejnosměrný proud z baterií nebo solárních panelů na střídavý proud 230V/400V?',
    options: ['Transformátor', 'Střídač (Invertor)', 'Usměrňovač', 'Frekvenční měnič'],
    correct: 1,
    explanation: 'Střídač (nebo invertor) má za úkol převést stejnosměrné napětí na střídavé synchronizované se sítí.'
  },
  {
    id: 63,
    type: 'true-false',
    text: 'Při hašení požáru elektrického zařízení pod napětím se smí použít vodní hasicí přístroj s roztříštěným proudem, pokud dodržíme bezpečnou vzdálenost.',
    correct: false,
    explanation: 'Běžné vodní hasicí přístroje se na zařízení pod napětím nesmí použít kvůli vodivosti vody. Pro hašení elektrických zařízení pod napětím se používají přístroje sněhové (CO2) nebo práškové.'
  },
  {
    id: 64,
    type: 'multiple-choice',
    text: 'Co je to krokové napětí?',
    options: [
      'Napětí naměřené při chůzi na koberci ze statické elektřiny',
      'Napětí mezi dvěma body na zemi ve vzdálenosti jednoho kroku (cca 1m) při průchodu poruchového proudu zemí',
      'Napětí, kterým krokový motor napájí své cívky',
      'Napětí regulované v postupných krocích'
    ],
    correct: 1,
    explanation: 'Krokové napětí vzniká při úniku proudu do země (např. při spadlém vodiči vn). Vytváří se tzv. potenciálový trychtýř a napětí mezi nohama člověka může být smrtelné.'
  },
  {
    id: 65,
    type: 'calculation',
    text: 'Vypočítej odpor rezistoru v Ohmech, kterým protéká proud 0.5 A při napětí 12 V.',
    expectedValue: 24,
    explanation: 'R = U / I = 12 / 0.5 = 24 Ω.'
  },
  {
    id: 66,
    type: 'true-false',
    text: 'Při paralelním zapojení dvou identických žárovek svítí obě stejně jasně jako jedna samostatná, pokud je napájecí napětí konstantní.',
    correct: true,
    explanation: 'Ano, obě žárovky mají na sobě plné napájecí napětí a odebírají svůj jmenovitý proud, takže svítí naplno.'
  },
  {
    id: 67,
    type: 'multiple-choice',
    text: 'Který přístroj se používá ke zjištění přítomnosti napětí bez nutnosti galvanického kontaktu s vodičem?',
    options: ['Klešťový ampérmetr', 'Bezdotyková zkoušečka (indukční)', 'Megmet', 'Dvojpólová zkoušečka (Vadaska)'],
    correct: 1,
    explanation: 'Bezdotyková zkoušečka detekuje střídavé elektrické pole v blízkosti fázového vodiče bez přímého dotyku kovu.'
  },
  {
    id: 68,
    type: 'calculation',
    text: 'Třífázový spotřebič odebírá proud 10 A v každé fázi. Pokud je napětí 230 V (fázové) a účiník cos φ = 1, jaký je celkový činný výkon ve Wattech (P = 3 * U_faz * I * cos φ)?',
    expectedValue: 6900,
    explanation: 'Činný výkon třífázové souměrné zátěže: P = 3 * 230 V * 10 A * 1 = 6900 W (neboli 6.9 kW).'
  },
  {
    id: 69,
    type: 'true-false',
    text: 'Přepěťová ochrana typu T1 (hrubá ochrana / svodič bleskových proudů) se instaluje co nejblíže ke spotřebičům, např. do zásuvek.',
    correct: false,
    explanation: 'Ochrana typu T1 (svodič bleskových proudů) se instaluje na vstupu do objektu (hlavní rozvaděč). Do zásuvek se dává jemná ochrana typu T3.'
  },
  {
    id: 70,
    type: 'multiple-choice',
    text: 'Jaká je hlavní výhoda stykače oproti běžnému vypínači?',
    options: [
      'Stykač má nulový přechodový odpor',
      'Umožňuje dálkové ovládání a spínání velkých proudů malým řídicím proudem',
      'Stykač funguje i bez elektrického napájení',
      'Chrání obvod před zkratem lépe než jistič'
    ],
    correct: 1,
    explanation: 'Stykač umožňuje bezpečně ovládat vysokovýkonové obvody (např. motory) pomocí nízkonapěťového nebo slaboproudého řídicího signálu.'
  },

  // 71-80: Závěrečné procvičení
  {
    id: 71,
    type: 'multiple-choice',
    text: 'Který z následujících materiálů má nejvyšší elektrickou vodivost při pokojové teplotě?',
    options: ['Měď (Cu)', 'Hliník (Al)', 'Stříbro (Ag)', 'Zlato (Au)'],
    correct: 2,
    explanation: 'Stříbro (Ag) má nejlepší elektrickou vodivost ze všech kovů, avšak pro vysokou cenu se v běžné elektrotechnice nepoužívá.'
  },
  {
    id: 72,
    type: 'true-false',
    text: 'Při úrazu elektrickým proudem se nesmíme dotýkat těla postiženého, dokud si nejsme stoprocentně jistí, že již není v kontaktu s aktivním vodičem pod napětím.',
    correct: true,
    explanation: 'Správně. Lidské tělo je vodivé a dotykem s postiženým pod napětím by se zachránce sám stal další obětí.'
  },
  {
    id: 73,
    type: 'multiple-choice',
    text: 'Co značí zkratka PELV?',
    options: [
      'Power Earth Low Voltage',
      'Protective Extra Low Voltage (Bezpečné malé napětí s uzemněným obvodem)',
      'Phase Earth Limit Volume',
      'Passive Electrical Link Valve'
    ],
    correct: 1,
    explanation: 'PELV (Protective Extra Low Voltage) je bezpečné malé napětí, které je na rozdíl od SELV funkčně uzemněno.'
  },
  {
    id: 74,
    type: 'calculation',
    text: 'Třífázový asynchronní motor má na štítku otáčky 1440 ot/min. Kolik pólů má jeho statorové vinutí, pokud je připojen na síť 50 Hz (synchronní otáčky pro 4 póly jsou 1500 ot/min)?',
    expectedValue: 4,
    explanation: 'Synchronní otáčky n_s = 60 * f / p. Pro frekvenci f = 50 Hz a počet dvojic pólů p = 2 (tzn. 4 póly) jsou synchronní otáčky 1500 ot/min. Motor má skluz a točí se rychlostí 1440 ot/min. Počet pólů je tedy 4.'
  },
  {
    id: 75,
    type: 'true-false',
    text: 'Kondenzátory zapojené paralelně se sčítají podle vzorce C = C1 + C2.',
    correct: true,
    explanation: 'Ano, kapacita paralelně zapojených kondenzátorů se sčítá, což je opačně než u rezistorů.'
  },
  {
    id: 76,
    type: 'multiple-choice',
    text: 'Co je účelem tlumivky v zářivkovém svítidle s klasickým startérem?',
    options: [
      'Způsobuje blikání světla',
      'Zajišťuje vysokonapěťový ráz pro zapálení výboje a následně omezuje protékající proud',
      'Mění střídavý proud na stejnosměrný',
      'Slouží jako pojistka při přetížení'
    ],
    correct: 1,
    explanation: 'Tlumivka díky indukčnosti vygeneruje při rozepnutí startéru napěťovou špičku nutnou pro zapálení plynu v trubici a poté tlumí (omezuje) pracovní proud.'
  },
  {
    id: 77,
    type: 'calculation',
    text: 'Vypočítej celkový odpor v Ohmech dvou paralelně zapojených identických rezistorů R1 = 20 Ω a R2 = 20 Ω.',
    expectedValue: 10,
    explanation: 'U paralelního zapojení dvou stejných odporů je celkový odpor poloviční: R = R1 / 2 = 10 Ω.'
  },
  {
    id: 78,
    type: 'true-false',
    text: 'Klešťový ampérmetr umožňuje měřit střídavý proud protékající vodičem bez nutnosti rozpojení obvodu, a to na základě principu měření magnetického pole.',
    correct: true,
    explanation: 'Ano, kleště tvoří otevíratelné magnetické jádro, které snímá střídavé magnetické pole vodiče a indukuje měřitelný proud.'
  },
  {
    id: 79,
    type: 'multiple-choice',
    text: 'Jaký je nejčastější důvod vzniku přechodového odporu na svorkovnicích?',
    options: [
      'Použití příliš silného vodiče',
      'Nedostatečně utažený šroubový spoj nebo oxidace kontaktních ploch',
      'Příliš vysoké napětí v síti',
      'Příliš nízká teplota okolí'
    ],
    correct: 1,
    explanation: 'Nedotažený šroubek nebo zoxidovaný kontakt vytváří přechodový odpor. Při průchodu proudu se toto místo zahřívá, což může vést až k požáru.'
  },
  {
    id: 80,
    type: 'calculation',
    text: 'Na spotřebiči s odporem 10 Ω naměříme proud 3 A. Jaké napětí na něm je ve Voltech?',
    expectedValue: 30,
    explanation: 'Podle Ohmova zákona: U = I * R = 3 * 10 = 30 V.'
  }
];
