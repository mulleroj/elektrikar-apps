export type QuestionType = 'multiple-choice' | 'true-false' | 'calculation' | 'identification' | 'circuit-build';

export interface ComponentItem {
  id: string;
  label: string;
  type: 'source' | 'load' | 'switch' | 'terminal' | 'wire_brown' | 'wire_blue' | 'wire_gy';
}

export interface IdentificationOption {
  id: string;
  label: string;
}

export interface BaseQuestion {
  id: number;
  type: QuestionType;
  text: string;
  explanation: string;
}

export interface MultipleChoiceQuestion extends BaseQuestion {
  type: 'multiple-choice';
  options: string[];
  correct: number;
}

export interface TrueFalseQuestion extends BaseQuestion {
  type: 'true-false';
  correct: boolean;
}

export interface CalculationQuestion extends BaseQuestion {
  type: 'calculation';
  expectedValue: number;
}

export interface IdentificationQuestion extends BaseQuestion {
  type: 'identification';
  target: string;
  options: IdentificationOption[];
}

export interface CircuitBuildQuestion extends BaseQuestion {
  type: 'circuit-build';
  components: ComponentItem[];
  correctConnections: [string, string][]; // e.g., [['L', 'switch'], ...]
}

export type Question = 
  | MultipleChoiceQuestion 
  | TrueFalseQuestion 
  | CalculationQuestion 
  | IdentificationQuestion 
  | CircuitBuildQuestion;

export interface UserAnswer {
  question: Question;
  isCorrect: boolean;
  userValue?: string; // stored value if calculation or choice
}
