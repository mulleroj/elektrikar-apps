import React, { useState } from 'react';
import { Bolt, BookOpen, Cloud, CircleDot, Magnet, GraduationCap, Info } from 'lucide-react';
import { TabId } from './types';
import TheorySection from './components/TheorySection';
import SF6Simulation from './components/SF6Simulation';
import VacuumSimulation from './components/VacuumSimulation';
import MagneticSimulation from './components/MagneticSimulation';
import QuizSection from './components/QuizSection';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('intro');

  const renderActiveSection = () => {
    switch (activeTab) {
      case 'intro':
        return <TheorySection onSwitchTab={setActiveTab} />;
      case 'sf6':
        return <SF6Simulation />;
      case 'vacuum':
        return <VacuumSimulation />;
      case 'magnetic':
        return <MagneticSimulation />;
      case 'quiz':
        return <QuizSection />;
      default:
        return <TheorySection onSwitchTab={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans bg-[#0A0A0B] text-[#EDEDEF] selection:bg-[#3E63DD] selection:text-white">
      {/* HEADER */}
      <header className="bg-[#111112]/95 border-b border-[#1F1F21] py-3 px-4 md:px-8 flex justify-between items-center z-20 shadow-lg sticky top-0 backdrop-filter backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-[#3E63DD] to-[#8E4EC6] rounded-xl flex items-center justify-center text-xl shadow-[0_0_20px_rgba(62,99,221,0.25)] hover:rotate-12 transition-transform duration-300">
            <Bolt className="w-5.5 h-5.5 text-white fill-current" />
          </div>
          <div>
            <h1 className="text-base md:text-lg font-bold tracking-tight text-white flex items-center gap-1.5">
              Spínací Přístroje VN a VVN
            </h1>
            <p className="text-[11px] text-[#9BA1A6] hidden sm:block">
              Interaktivní výuková aplikace pro elektrotechnické obory
            </p>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1.5">
          <button
            onClick={() => setActiveTab('intro')}
            className={`px-4 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'intro'
                ? 'bg-[#3E63DD] text-white shadow-[0_0_15px_rgba(62,99,221,0.45)] border border-[#3E63DD]'
                : 'text-[#9BA1A6] hover:bg-[#1B1B1F] hover:text-[#EDEDEF] border border-transparent'
            }`}
          >
            <BookOpen className="w-4 h-4" /> Úvod & Teorie
          </button>
          <button
            onClick={() => setActiveTab('sf6')}
            className={`px-4 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'sf6'
                ? 'bg-[#3E63DD] text-white shadow-[0_0_15px_rgba(62,99,221,0.45)] border border-[#3E63DD]'
                : 'text-[#9BA1A6] hover:bg-[#1B1B1F] hover:text-[#EDEDEF] border border-transparent'
            }`}
          >
            <Cloud className="w-4 h-4" /> Vypínač SF₆
          </button>
          <button
            onClick={() => setActiveTab('vacuum')}
            className={`px-4 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'vacuum'
                ? 'bg-[#3E63DD] text-white shadow-[0_0_15px_rgba(62,99,221,0.45)] border border-[#3E63DD]'
                : 'text-[#9BA1A6] hover:bg-[#1B1B1F] hover:text-[#EDEDEF] border border-transparent'
            }`}
          >
            <CircleDot className="w-4 h-4" /> Vakuový vypínač
          </button>
          <button
            onClick={() => setActiveTab('magnetic')}
            className={`px-4 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'magnetic'
                ? 'bg-[#3E63DD] text-white shadow-[0_0_15px_rgba(62,99,221,0.45)] border border-[#3E63DD]'
                : 'text-[#9BA1A6] hover:bg-[#1B1B1F] hover:text-[#EDEDEF] border border-transparent'
            }`}
          >
            <Magnet className="w-4 h-4" /> Magnetické vyfukování
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`px-4 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'quiz'
                ? 'bg-[#8E4EC6] text-white shadow-[0_0_15px_rgba(142,78,198,0.45)] border border-[#8E4EC6]'
                : 'text-[#9BA1A6] hover:bg-[#1B1B1F] hover:text-[#EDEDEF] border border-transparent'
            }`}
          >
            <GraduationCap className="w-4 h-4" /> Ověření (Test)
          </button>
        </nav>

        {/* Simple status hint on Desktop / Tablet */}
        <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-[#9BA1A6] font-mono bg-[#0A0A0B] px-3 py-1.5 rounded-lg border border-[#1F1F21]">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Interaktivní laboratoř v1.0.0</span>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8 bg-[#0A0A0B] pb-24 lg:pb-8 flex flex-col justify-start">
        {renderActiveSection()}
      </main>

      {/* MOBILE BOTTOM NAVIGATION BAR */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-[#111112] border-t border-[#1F1F21] p-2 flex justify-around z-30 shadow-2xl backdrop-filter backdrop-blur-md">
        <button
          onClick={() => setActiveTab('intro')}
          className={`flex flex-col items-center justify-center p-1 rounded-md transition-all w-1/5 cursor-pointer ${
            activeTab === 'intro' ? 'text-[#3E63DD] scale-105 font-semibold' : 'text-[#9BA1A6]'
          }`}
        >
          <BookOpen className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-medium font-sans">Teorie</span>
        </button>
        <button
          onClick={() => setActiveTab('sf6')}
          className={`flex flex-col items-center justify-center p-1 rounded-md transition-all w-1/5 cursor-pointer ${
            activeTab === 'sf6' ? 'text-[#3E63DD] scale-105 font-semibold' : 'text-[#9BA1A6]'
          }`}
        >
          <Cloud className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-medium font-sans">SF₆ plyn</span>
        </button>
        <button
          onClick={() => setActiveTab('vacuum')}
          className={`flex flex-col items-center justify-center p-1 rounded-md transition-all w-1/5 cursor-pointer ${
            activeTab === 'vacuum' ? 'text-[#3E63DD] scale-105 font-semibold' : 'text-[#9BA1A6]'
          }`}
        >
          <CircleDot className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-medium font-sans">Vakuum</span>
        </button>
        <button
          onClick={() => setActiveTab('magnetic')}
          className={`flex flex-col items-center justify-center p-1 rounded-md transition-all w-1/5 cursor-pointer ${
            activeTab === 'magnetic' ? 'text-[#3E63DD] scale-105 font-semibold' : 'text-[#9BA1A6]'
          }`}
        >
          <Magnet className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-medium font-sans">Magnet</span>
        </button>
        <button
          onClick={() => setActiveTab('quiz')}
          className={`flex flex-col items-center justify-center p-1 rounded-md transition-all w-1/5 cursor-pointer ${
            activeTab === 'quiz' ? 'text-[#8E4EC6] scale-105 font-semibold' : 'text-[#9BA1A6]'
          }`}
        >
          <GraduationCap className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-medium font-sans">Test</span>
        </button>
      </div>
    </div>
  );
}
