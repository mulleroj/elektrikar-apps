import React, { useEffect, useRef, useState } from 'react';
import { Cloud, Link, Unlink, Zap } from 'lucide-react';
import { SimulationState } from '../types';

class Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;

  constructor(x: number, y: number, vx: number, vy: number, life: number, color: string, size: number) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.life = life;
    this.maxLife = life;
    this.color = color;
    this.size = size;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.life--;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.globalAlpha = Math.max(0, this.life / this.maxLife);
    ctx.fillStyle = this.color;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

export default function SF6Simulation() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Expose mode to React state for UI controls
  const [mode, setMode] = useState<'open' | 'closed' | 'opening' | 'closing'>('open');
  const [arcType, setArcType] = useState<'normal' | 'short'>('normal');

  // Animation values kept in ref to run 60FPS smoothly
  const stateRef = useRef<SimulationState>({
    mode: 'open',
    progress: 1.0, // 0 = closed, 1 = open
    arcIntensity: 0,
    arcType: 'normal',
  });

  const particlesRef = useRef<Particle[]>([]);

  useEffect(() => {
    stateRef.current.mode = mode;
    stateRef.current.arcType = arcType;
  }, [mode, arcType]);

  const addParticle = (x: number, y: number, vx: number, vy: number, life: number, color: string, size: number) => {
    if (particlesRef.current.length < 150) {
      particlesRef.current.push(new Particle(x, y, vx, vy, life, color, size));
    }
  };

  const drawLightning = (
    ctx: CanvasRenderingContext2D,
    startX: number,
    startY: number,
    endX: number,
    endY: number,
    segments: number,
    color: string,
    thickness: number
  ) => {
    const dx = endX - startX;
    const dy = endY - startY;
    const length = Math.sqrt(dx * dx + dy * dy);

    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = thickness;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(startX, startY);

    for (let i = 1; i <= segments; i++) {
      const targetX = startX + (dx * (i / segments));
      const targetY = startY + (dy * (i / segments));

      // Jitter
      let jitterX = (Math.random() - 0.5) * (length * 0.12);
      let jitterY = (Math.random() - 0.5) * (length * 0.12);

      if (i === segments) {
        jitterX = 0;
        jitterY = 0;
      }

      ctx.lineTo(targetX + jitterX, targetY + jitterY);
    }
    ctx.stroke();
    ctx.restore();
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        canvas.width = width || 400;
        canvas.height = height || 400;
      }
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;
      const cx = w / 2;
      const cy = h / 2 - 20;

      ctx.clearRect(0, 0, w, h);

      const state = stateRef.current;

      // Update simulation physics
      if (state.mode === 'opening') {
        state.progress += 0.015; // separates smoothly
        if (state.progress >= 0.15 && state.progress < 0.75) {
          state.arcIntensity = state.arcType === 'short' ? 1.0 : 0.6;

          // Puff gas particles
          if (Math.random() > 0.2) {
            addParticle(
              cx - 20 + Math.random() * 40,
              cy + 20,
              (Math.random() - 0.5) * 4,
              -3 - Math.random() * 5,
              25 + Math.random() * 12,
              'rgba(56, 189, 248, 0.7)', // SF6 light blue
              2 + Math.random() * 3
            );
          }
        } else if (state.progress >= 0.75) {
          state.arcIntensity *= 0.75; // rapid cooling/extinguishing
        }

        if (state.progress >= 1.0) {
          state.progress = 1.0;
          state.mode = 'open';
          state.arcIntensity = 0;
          setMode('open');
        }
      } else if (state.mode === 'closing') {
        state.progress -= 0.035; // closes fast
        if (state.progress <= 0) {
          state.progress = 0;
          state.mode = 'closed';
          setMode('closed');
        }
      }

      // Update particles
      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        particles[i].update();
        if (particles[i].life <= 0) {
          particles.splice(i, 1);
        }
      }

      // Drawing
      const scale = Math.min(1, w / 450);
      ctx.save();
      ctx.translate(cx, cy);
      ctx.scale(scale, scale);

      // Gas-tight tank outline
      ctx.strokeStyle = '#1F1F21';
      ctx.lineWidth = 4;
      ctx.fillStyle = '#111112';
      ctx.beginPath();
      ctx.roundRect(-120, -160, 240, 320, 12);
      ctx.fill();
      ctx.stroke();

      // Ambient gas overlay
      ctx.fillStyle = 'rgba(62, 99, 221, 0.05)';
      ctx.beginPath();
      ctx.roundRect(-118, -158, 236, 316, 10);
      ctx.fill();

      // Text label inside chamber
      ctx.font = '12px "JetBrains Mono", monospace';
      ctx.fillStyle = '#9BA1A6';
      ctx.textAlign = 'center';
      ctx.fillText("ZHÁŠECÍ KOMORA S PLYNEM SF6", 0, -135);

      // --- FIXED CONTACT (Top) ---
      // Silver color gradient for metal contacts
      const metalGrd = ctx.createLinearGradient(-30, 0, 30, 0);
      metalGrd.addColorStop(0, '#5A5E65');
      metalGrd.addColorStop(0.5, '#EDEDEF');
      metalGrd.addColorStop(1, '#3E4247');

      ctx.fillStyle = metalGrd;
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 2;

      // Tulip contact shape
      ctx.beginPath();
      ctx.moveTo(-25, -160);
      ctx.lineTo(-25, -50);
      ctx.lineTo(-15, -40);
      ctx.lineTo(-15, -15);
      ctx.lineTo(-6, -15);
      ctx.lineTo(-6, -35);
      ctx.lineTo(6, -35);
      ctx.lineTo(6, -15);
      ctx.lineTo(15, -15);
      ctx.lineTo(15, -40);
      ctx.lineTo(25, -50);
      ctx.lineTo(25, -160);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Red central arcing contact
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(-5, -40, 10, 25);

      // --- MOVING CONTACT & CYLINDER (Bottom) ---
      const gapY = state.progress * 105;

      // Outer puffer cylinder (attached to moving contact and moves)
      ctx.fillStyle = '#334155';
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-45, gapY + 35);
      ctx.lineTo(-45, gapY + 130);
      ctx.lineTo(45, gapY + 130);
      ctx.lineTo(45, gapY + 35);
      ctx.lineTo(25, gapY + 35);
      ctx.lineTo(25, gapY + 110); // Inner piston chamber
      ctx.lineTo(-25, gapY + 110);
      ctx.lineTo(-25, gapY + 35);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Fixed stationary piston (stays at bottom)
      const pistonGrd = ctx.createLinearGradient(-23, 0, 23, 0);
      pistonGrd.addColorStop(0, '#475569');
      pistonGrd.addColorStop(0.5, '#94a3b8');
      pistonGrd.addColorStop(1, '#334155');
      ctx.fillStyle = pistonGrd;
      ctx.fillRect(-23, 160, 46, 20); // base anchor
      ctx.fillRect(-23, gapY + 110, 46, 160 - (gapY + 110)); // piston column

      // Main Moving Contact rod (Center silver rod)
      ctx.fillStyle = metalGrd;
      ctx.strokeStyle = '#475569';
      ctx.beginPath();
      ctx.roundRect(-7, gapY - 5, 14, 140, 2);
      ctx.fill();
      ctx.stroke();

      // PTFE Nozzle (Teflon cone around contact)
      ctx.fillStyle = 'rgba(248, 250, 252, 0.85)';
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-35, gapY + 35);
      ctx.lineTo(-14, gapY - 12);
      ctx.lineTo(14, gapY - 12);
      ctx.lineTo(35, gapY + 35);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // --- ELECTRIC ARC DRAWING ---
      if (state.arcIntensity > 0.04) {
        ctx.save();
        ctx.shadowBlur = state.arcType === 'short' ? 24 : 12;
        ctx.shadowColor = state.arcType === 'short' ? '#f59e0b' : '#38bdf8';

        // Background heat blur / plasma glow
        ctx.globalAlpha = state.arcIntensity * 0.45;
        ctx.fillStyle = state.arcType === 'short' ? '#fef08a' : '#e0f2fe';
        ctx.beginPath();
        ctx.ellipse(0, -10 + gapY / 2, 24 + Math.random() * 8, gapY / 2 + 15, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // Core lightning bolts
        const segments = Math.max(3, Math.floor(gapY / 8));
        const color = state.arcType === 'short' ? '#ffffff' : '#e0f2fe';
        const thickness = (state.arcType === 'short' ? 5.5 : 2.5) * state.arcIntensity;

        if (state.arcType === 'short') {
          // Draw multiple braided arcs for heavy short circuit
          drawLightning(ctx, 0, -15, 0, gapY - 5, segments, '#f59e0b', thickness * 1.4);
          drawLightning(ctx, 0, -15, 0, gapY - 5, segments + 2, '#fff', thickness * 0.8);
        } else {
          // Standard load arc
          drawLightning(ctx, 0, -15, 0, gapY - 5, segments, color, thickness);
        }
      }

      ctx.restore();

      // Render gas particles
      particles.forEach((p) => p.draw(ctx));

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
    };
  }, []);

  const triggerOpen = (type: 'normal' | 'short') => {
    if (mode === 'closed') {
      setArcType(type);
      setMode('opening');
    }
  };

  const triggerClose = () => {
    if (mode === 'open') {
      setMode('closing');
    }
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6 flex-1 h-full">
      {/* Simulation Box */}
      <div className="lg:col-span-2 flex flex-col h-full">
        <div ref={containerRef} className="simulation-container flex-1 min-h-[400px] md:min-h-[500px]">
          <canvas ref={canvasRef}></canvas>
          
          {/* Controls Overlay */}
          <div className="overlay-controls">
            <button
              onClick={triggerClose}
              disabled={mode !== 'open'}
              className="btn-sim px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-[#161618] disabled:border-[#1F1F21] disabled:opacity-30 disabled:cursor-not-allowed text-white rounded-xl font-bold shadow-lg flex items-center gap-2 text-xs md:text-sm cursor-pointer transition-all"
            >
              <Link className="w-4 h-4" /> Zapnout
            </button>
            <button
              onClick={() => triggerOpen('normal')}
              disabled={mode !== 'closed'}
              className="btn-sim px-4 py-2.5 bg-[#1B1B1F] hover:bg-[#252529] border border-[#1F1F21] disabled:bg-[#161618] disabled:border-transparent disabled:opacity-30 disabled:cursor-not-allowed text-[#EDEDEF] rounded-xl font-bold shadow-lg flex items-center gap-2 text-xs md:text-sm cursor-pointer transition-all"
            >
              <Unlink className="w-4 h-4" /> Vypnout zátěž
            </button>
            <button
              onClick={() => triggerOpen('short')}
              disabled={mode !== 'closed'}
              className="btn-sim px-4 py-2.5 bg-red-600 hover:bg-red-500 disabled:bg-[#161618] disabled:border-transparent disabled:opacity-30 disabled:cursor-not-allowed text-white rounded-xl font-bold shadow-lg flex items-center gap-2 text-xs md:text-sm cursor-pointer transition-all"
            >
              <Zap className="w-4 h-4" /> Zkrat!
            </button>
          </div>
        </div>
      </div>

      {/* Sidebar explanation panel */}
      <div className="bg-[#161618] rounded-2xl p-5 border border-[#1F1F21] flex flex-col h-full overflow-y-auto justify-between">
        <div>
          <h3 className="text-lg font-bold text-white mb-4 border-b border-[#1F1F21] pb-2 flex items-center gap-2">
            <Cloud className="w-5 h-5 text-[#3E63DD]" /> Průběh vypnutí (Puffer)
          </h3>
          
          <div className="space-y-3 text-xs md:text-sm text-[#9BA1A6]">
            <div className={`p-3 rounded-xl border transition-all duration-300 ${mode === 'closing' ? 'bg-[#121B3A]/60 border-[#3E63DD]/40 text-[#EDEDEF]' : 'bg-[#111112] border-[#1F1F21]'}`}>
              <h4 className="font-bold text-[#3E63DD] mb-1">1. Pohyb kontaktů</h4>
              <p className="leading-normal">Silná pružina pohonu oddálí pohyblivý kontakt (vnitřní stříbrná tyč) od pevného tulipánového kontaktu.</p>
            </div>
            
            <div className={`p-3 rounded-xl border transition-all duration-300 ${mode === 'opening' ? 'bg-[#121B3A]/60 border-[#3E63DD]/40 text-[#EDEDEF]' : 'bg-[#111112] border-[#1F1F21]'}`}>
              <h4 className="font-bold text-[#3E63DD] mb-1">2. Komprese plynu (Puffing)</h4>
              <p className="leading-normal">S pohybem kontaktu je spojen válec, který stlačuje plyn SF<sub>6</sub> proti pevnému pístu.</p>
            </div>
            
            <div className={`p-3 rounded-xl border transition-all duration-300 ${mode === 'opening' && stateRef.current.progress < 0.6 ? 'bg-[#1D1204]/60 border-amber-500/30 text-[#EDEDEF]' : 'bg-[#111112] border-[#1F1F21]'}`}>
              <h4 className="font-bold text-amber-400 mb-1">3. Zapálení oblouku</h4>
              <p className="leading-normal">Oblouk hoří mezi opalovacími kontakty. Teplo ionizuje plyn, avšak SF<sub>6</sub> okamžitě pohlcuje volné elektrony.</p>
            </div>
            
            <div className={`p-3 rounded-xl border transition-all duration-300 ${mode === 'opening' && stateRef.current.progress >= 0.6 ? 'bg-[#052E21]/60 border-emerald-500/30 text-[#EDEDEF]' : 'bg-[#111112] border-[#1F1F21]'}`}>
              <h4 className="font-bold text-[#10B981] mb-1">4. Masivní ofuk tryskou</h4>
              <p className="leading-normal">Stlačený chladný SF<sub>6</sub> je hnán přes teflonovou trysku přímo do osy oblouku. Odebírá extrémní teplo a při průchodu proudu nulou oblouk uhasí.</p>
            </div>
          </div>
        </div>
        
        <div className="mt-6 pt-4 border-t border-[#1F1F21] shrink-0">
          <div className="flex items-center gap-2 mb-2">
            <span className={`w-3.5 h-3.5 rounded-full ${
              mode === 'open' ? 'bg-green-500 shadow-[0_0_12px_rgba(34,197,94,0.6)]' :
              mode === 'closed' ? 'bg-red-500 shadow-[0_0_12px_rgba(239,68,68,0.6)]' :
              'bg-amber-500 animate-pulse'
            }`}></span>
            <span className="font-bold text-white text-sm">
              Stav vypínače:{' '}
              <span className={
                mode === 'open' ? 'text-green-500' :
                mode === 'closed' ? 'text-red-500' :
                'text-amber-500'
              }>
                {mode === 'open' ? 'VYPNUTO (Bezpečný stav)' :
                 mode === 'closed' ? 'ZAPNUTO (Pod zátěží)' :
                 'V POHYBU'}
              </span>
            </span>
          </div>
          <p className="text-xs text-[#7E8085]">
            {mode === 'open' && 'Obvod je bezpečně rozpojen. Izolační síla SF6 zabraňuje samovolnému přeskoku.'}
            {mode === 'closed' && 'Jmenovitý proud bezpečně protéká kontakty.'}
            {mode === 'opening' && 'Vypínání sítě. Stlačený plyn uhasí elektrický oblouk.'}
            {mode === 'closing' && 'Uvádění kontaktů do sepnutého stavu.'}
          </p>
        </div>
      </div>
    </div>
  );
}
