import React, { useEffect, useRef, useState } from 'react';
import { Magnet, Link, Unlink, Zap } from 'lucide-react';
import { SimulationState } from '../types';

class SparkParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;

  constructor(x: number, y: number, vx: number, vy: number, life: number, color: string, size: number) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.life = life;
    this.maxLife = life;
    this.color = color;
    this.size = size;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.life--;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.globalAlpha = Math.max(0, this.life / this.maxLife);
    ctx.fillStyle = this.color;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

export default function MagneticSimulation() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [mode, setMode] = useState<'open' | 'closed' | 'opening' | 'closing'>('open');
  const [arcType, setArcType] = useState<'normal' | 'short'>('normal');

  const stateRef = useRef<SimulationState & { arcY: number }>({
    mode: 'open',
    progress: 1.0,
    arcIntensity: 0,
    arcType: 'normal',
    arcY: 0, // goes from 0 down to -180
  });

  const particlesRef = useRef<SparkParticle[]>([]);

  useEffect(() => {
    stateRef.current.mode = mode;
    stateRef.current.arcType = arcType;
  }, [mode, arcType]);

  const addParticle = (x: number, y: number, vx: number, vy: number, life: number, color: string, size: number) => {
    if (particlesRef.current.length < 100) {
      particlesRef.current.push(new SparkParticle(x, y, vx, vy, life, color, size));
    }
  };

  const drawLightning = (
    ctx: CanvasRenderingContext2D,
    startX: number,
    startY: number,
    endX: number,
    endY: number,
    segments: number,
    color: string,
    thickness: number
  ) => {
    const dx = endX - startX;
    const dy = endY - startY;
    const length = Math.sqrt(dx * dx + dy * dy);

    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = thickness;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(startX, startY);

    for (let i = 1; i <= segments; i++) {
      const targetX = startX + (dx * (i / segments));
      const targetY = startY + (dy * (i / segments));

      let jitterX = (Math.random() - 0.5) * (length * 0.15);
      let jitterY = (Math.random() - 0.5) * (length * 0.15);

      if (i === segments) {
        jitterX = 0;
        jitterY = 0;
      }

      ctx.lineTo(targetX + jitterX, targetY + jitterY);
    }
    ctx.stroke();
    ctx.restore();
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        canvas.width = width || 400;
        canvas.height = height || 400;
      }
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;
      const cx = w / 2;
      const cy = h / 2 + 50; // shift down for blowout upwards

      ctx.clearRect(0, 0, w, h);

      const state = stateRef.current;

      // Update simulation physics
      if (state.mode === 'opening') {
        if (state.progress < 1.0) {
          state.progress += 0.015; // smooth upward blow
          state.arcIntensity = state.arcType === 'short' ? 1.0 : 0.65;

          // Arc goes upwards (towards the top plates)
          state.arcY = -(state.progress * 195);

          // Add thermal / spark particles around arc
          if (Math.random() > 0.4) {
            addParticle(
              cx + (Math.random() - 0.5) * (state.progress * 140),
              cy + state.arcY + (Math.random() - 0.5) * 15,
              (Math.random() - 0.5) * 5,
              -1 - Math.random() * 4,
              20 + Math.random() * 15,
              '#f59e0b',
              1 + Math.random() * 2
            );
          }
        } else {
          state.arcIntensity *= 0.72; // rapidly extinguish inside plates
          if (state.arcIntensity < 0.01) {
            state.mode = 'open';
            state.arcIntensity = 0;
            setMode('open');
          }
        }
      } else if (state.mode === 'closing') {
        state.progress -= 0.045;
        state.arcY = 0;
        if (state.progress <= 0) {
          state.progress = 0;
          state.mode = 'closed';
          setMode('closed');
        }
      }

      // Update particles
      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        particles[i].update();
        if (particles[i].life <= 0) {
          particles.splice(i, 1);
        }
      }

      // Drawing
      const scale = Math.min(1, w / 400);
      ctx.save();
      ctx.translate(cx, cy);
      ctx.scale(scale, scale);

      // --- MAGNETIC FIELD INDICATION IN BACKGROUND ---
      if (state.arcIntensity > 0) {
        ctx.fillStyle = 'rgba(239, 68, 68, 0.04)';
        ctx.fillRect(-150, -210, 300, 260);

        // Grid of red crosses (B-field going into the screen)
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.25)';
        ctx.lineWidth = 1;
        for (let ix = -130; ix <= 130; ix += 35) {
          for (let iy = -190; iy <= 30; iy += 35) {
            ctx.beginPath();
            ctx.moveTo(ix - 4, iy - 4);
            ctx.lineTo(ix + 4, iy + 4);
            ctx.moveTo(ix + 4, iy - 4);
            ctx.lineTo(ix - 4, iy + 4);
            ctx.stroke();
          }
        }
        
        // Lorentz force indicator arrow
        ctx.fillStyle = '#f87171';
        ctx.strokeStyle = '#f87171';
        ctx.lineWidth = 2.5;
        ctx.font = '11px "JetBrains Mono", monospace';
        ctx.textAlign = 'left';
        ctx.fillText("F = B × I × L  (Vzhůru)", -140, 25);
      }

      // --- DEIONIZATION PLATES / ROŠT (Top) ---
      const plateStartY = -70;
      ctx.fillStyle = '#64748b'; // steel plates color
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1;

      // 8 vertical split plates
      for (let i = 0; i < 9; i++) {
        const px = -112 + i * 28;
        ctx.beginPath();
        ctx.moveTo(px - 3, plateStartY - 100);
        ctx.lineTo(px + 3, plateStartY - 100);
        ctx.lineTo(px + 3, plateStartY);
        ctx.lineTo(px, plateStartY + 15); // V-notch entry
        ctx.lineTo(px - 3, plateStartY);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }

      // Grid container outline
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 2;
      ctx.strokeRect(-125, plateStartY - 105, 250, 125);

      // --- ARC HORNS (Opalovací rohy) ---
      // Heavy copper/brass guide horns
      const hornGrd = ctx.createLinearGradient(-100, 0, 100, 0);
      hornGrd.addColorStop(0, '#d97706');
      hornGrd.addColorStop(0.5, '#f59e0b');
      hornGrd.addColorStop(1, '#b45309');

      ctx.strokeStyle = hornGrd;
      ctx.lineWidth = 8;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      // Left Guide Horn
      ctx.beginPath();
      ctx.moveTo(-18, 5);
      ctx.quadraticCurveTo(-110, 5, -112, -145);
      ctx.stroke();

      // Right Guide Horn
      ctx.beginPath();
      ctx.moveTo(18, 5);
      ctx.quadraticCurveTo(110, 5, 112, -145);
      ctx.stroke();

      // --- CONTACTS ---
      const gapX = state.progress * 42;

      // Fixed Primary contact (Left)
      ctx.fillStyle = '#475569';
      ctx.fillRect(-38, -10, 18, 20);
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(-38, -10, 18, 20);

      // Silver contact pad
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(-20, -10, 4, 20);

      // Moving Primary contact (Right)
      ctx.fillStyle = '#475569';
      ctx.fillRect(16 + gapX, -10, 18, 20);
      ctx.strokeRect(16 + gapX, -10, 18, 20);

      // Silver contact pad
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(16 + gapX, -10, 4, 20);

      // --- BLOWOUT COIL DRAWING (Cívka vyfukování) ---
      ctx.fillStyle = '#ea580c';
      ctx.strokeStyle = '#9a3412';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(-42, 28, 84, 18, 4);
      ctx.fill();
      ctx.stroke();
      ctx.font = '10px "Inter", sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText("VYFUKOVACÍ CÍVKA", 0, 41);

      // --- ELECTRIC ARC LORENTZ PHYSICS ---
      if (state.arcIntensity > 0) {
        ctx.save();
        ctx.shadowBlur = 18;
        ctx.shadowColor = '#f59e0b';

        const startArcX = -17;
        const endArcX = 17 + gapX;
        const currentY = state.arcY;

        if (currentY < plateStartY) {
          // Splitting phase - Arc is divided between metal plates
          const numSplits = 8;
          const plateWidth = 28;

          for (let i = 0; i < numSplits; i++) {
            const sx = -112 + i * plateWidth + 3;
            const ex = sx + plateWidth - 6;
            // Arc inside each splitter gap
            drawLightning(ctx, sx, currentY, ex, currentY, 2, '#fff', 3 * state.arcIntensity);
            drawLightning(ctx, sx, currentY, ex, currentY, 2, '#f59e0b', 5 * state.arcIntensity);
          }

          // Left arc root to horn
          const leftHornX = -112;
          drawLightning(ctx, leftHornX, currentY, -112 + 3, currentY, 2, '#fbbf24', 4 * state.arcIntensity);

          // Right arc root to horn
          const rightHornX = 112;
          drawLightning(ctx, 112 - 3, currentY, rightHornX, currentY, 2, '#fbbf24', 4 * state.arcIntensity);

        } else {
          // Elongation phase - Arc bows upwards in a beautiful loop
          const peakX = gapX / 2;
          const peakY = currentY - 18;

          ctx.beginPath();
          ctx.moveTo(startArcX, 0);
          ctx.quadraticCurveTo(peakX, peakY, endArcX, 0);
          ctx.strokeStyle = 'rgba(245, 158, 11, 0.45)';
          ctx.lineWidth = 14 * state.arcIntensity;
          ctx.stroke();

          // Core lightning
          drawLightning(ctx, startArcX, 0, endArcX, 0, 7, '#ffffff', 4 * state.arcIntensity);
        }
        ctx.restore();
      }

      ctx.restore();

      // Render sparks
      particles.forEach((p) => p.draw(ctx));

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
    };
  }, []);

  const triggerOpen = (type: 'normal' | 'short') => {
    if (mode === 'closed') {
      setArcType(type);
      setMode('opening');
    }
  };

  const triggerClose = () => {
    if (mode === 'open') {
      setMode('closing');
    }
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6 flex-1 h-full">
      {/* Simulation Box */}
      <div className="lg:col-span-2 flex flex-col h-full">
        <div ref={containerRef} className="simulation-container flex-1 min-h-[400px] md:min-h-[500px]">
          <canvas ref={canvasRef}></canvas>
          
          {/* Controls Overlay */}
          <div className="overlay-controls">
            <button
              onClick={triggerClose}
              disabled={mode !== 'open'}
              className="btn-sim px-3 md:px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded font-bold shadow-lg flex items-center gap-2 text-xs md:text-sm cursor-pointer"
            >
              <Link className="w-4 h-4" /> Zapnout
            </button>
            <button
              onClick={() => triggerOpen('normal')}
              disabled={mode !== 'closed'}
              className="btn-sim px-3 md:px-4 py-2 bg-slate-600 hover:bg-slate-500 disabled:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded font-bold shadow-lg flex items-center gap-2 text-xs md:text-sm cursor-pointer"
            >
              <Unlink className="w-4 h-4" /> Vypnout zátěž
            </button>
            <button
              onClick={() => triggerOpen('short')}
              disabled={mode !== 'closed'}
              className="btn-sim px-3 md:px-4 py-2 bg-red-600 hover:bg-red-500 disabled:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded font-bold shadow-lg flex items-center gap-2 text-xs md:text-sm cursor-pointer"
            >
              <Zap className="w-4 h-4" /> Zkrat!
            </button>
          </div>
        </div>
      </div>

      {/* Sidebar explanation panel */}
      <div className="bg-slate-800 rounded-xl p-5 border border-slate-700 flex flex-col h-full overflow-y-auto justify-between">
        <div>
          <h3 className="text-lg font-bold text-white mb-4 border-b border-slate-700 pb-2 flex items-center gap-2">
            <Magnet className="w-5 h-5 text-red-400" /> Lorentzova síla v akci
          </h3>
          
          <div className="space-y-3 text-xs md:text-sm text-slate-300">
            <div className={`p-3 rounded border transition-colors ${mode === 'opening' ? 'bg-red-950/20 border-red-500/30' : 'bg-slate-900/50 border-slate-800'}`}>
              <h4 className="font-bold text-red-400 mb-1">Vznik F = B &middot; I &middot; L</h4>
              <p className="leading-normal">Proud tekoucí vypínačem prochází vyfukovací cívkou. Ta vybudí silné magnetické pole. Plazmový oblouk (představující vodič s proudem <strong>I</strong>) je vytlačován kolmou Lorentzovou silou směrem nahoru.</p>
            </div>
            
            <div className={`p-3 rounded border transition-colors ${mode === 'opening' && stateRef.current.progress > 0.1 && stateRef.current.progress < 0.65 ? 'bg-amber-950/40 border-amber-500/50' : 'bg-slate-900/50 border-slate-800'}`}>
              <h4 className="font-bold text-amber-500 mb-1">Opalovací rohy (Arc Horns)</h4>
              <p className="leading-normal">Oblouk se okamžitě přesune z drahých hlavních kontaktů na vodicí masivní rohy. Zde se extrémně natahuje, čímž roste jeho odpor a klesá proud.</p>
            </div>
            
            <div className={`p-3 rounded border transition-colors ${mode === 'opening' && stateRef.current.progress >= 0.65 ? 'bg-blue-950/40 border-blue-500/50' : 'bg-slate-900/50 border-slate-800'}`}>
              <h4 className="font-bold text-blue-400 mb-1">Deionizační rošt (Komora)</h4>
              <p className="leading-normal">Na konci dráhy je oblouk natlačen do deionizačního roštu (kovové plechy). Zde se &quot;rozseká&quot; na 8 menších oblouků zapojených v sérii.</p>
            </div>
            
            <div className={`p-3 rounded border transition-colors ${mode === 'open' ? 'bg-teal-950/40 border-teal-500/50' : 'bg-slate-900/50 border-slate-800'}`}>
              <h4 className="font-bold text-teal-400 mb-1">Masivní chlazení a uhašení</h4>
              <p className="leading-normal">Ocelové plechy oblouk prudce ochladí. Pro zapálení každého malého oblouku je navíc nutné anodo-katodové přepětí (20-30V), což zvýší celkovou bariéru nad napětí sítě a oblouk zhasne.</p>
            </div>
          </div>
        </div>
        
        <div className="mt-6 pt-4 border-t border-slate-700 shrink-0">
          <div className="flex items-center gap-2 mb-2">
            <span className={`w-3.5 h-3.5 rounded-full ${
              mode === 'open' ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' :
              mode === 'closed' ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]' :
              'bg-amber-500 animate-pulse'
            }`}></span>
            <span className="font-bold text-white text-sm">
              Stav obvodu:{' '}
              <span className={
                mode === 'open' ? 'text-green-500' :
                mode === 'closed' ? 'text-red-500' :
                'text-amber-500'
              }>
                {mode === 'open' ? 'VYPNUTO (Bezpečný stav)' :
                 mode === 'closed' ? 'ZAPNUTO (Pod zátěží)' :
                 'V POHYBU'}
              </span>
            </span>
          </div>
          <p className="text-xs text-slate-400">
            {mode === 'open' && 'Obvod rozpojen, deionizační komora bezpečně uhašena.'}
            {mode === 'closed' && 'Proud protéká přes cívku vyfukování a hlavní kontakty.'}
            {mode === 'opening' && 'Rozpínání obvodu. Lorentzova síla vytlačuje oblouk do ocelového roštu.'}
            {mode === 'closing' && 'Kontakty se spojují.'}
          </p>
        </div>
      </div>
    </div>
  );
}
