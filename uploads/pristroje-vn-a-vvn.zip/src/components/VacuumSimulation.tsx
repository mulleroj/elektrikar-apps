import React, { useEffect, useRef, useState } from 'react';
import { CircleDot, Link, Unlink, Zap } from 'lucide-react';
import { SimulationState } from '../types';

class MetalVaporParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;

  constructor(x: number, y: number, vx: number, vy: number, life: number, color: string, size: number) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.life = life;
    this.maxLife = life;
    this.color = color;
    this.size = size;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.life--;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.globalAlpha = Math.max(0, this.life / this.maxLife);
    ctx.fillStyle = this.color;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

export default function VacuumSimulation() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [mode, setMode] = useState<'open' | 'closed' | 'opening' | 'closing'>('open');
  const [arcType, setArcType] = useState<'normal' | 'short'>('normal');

  const stateRef = useRef<SimulationState & { rotationAngle: number }>({
    mode: 'open',
    progress: 1.0,
    arcIntensity: 0,
    arcType: 'normal',
    rotationAngle: 0,
  });

  const particlesRef = useRef<MetalVaporParticle[]>([]);

  useEffect(() => {
    stateRef.current.mode = mode;
    stateRef.current.arcType = arcType;
  }, [mode, arcType]);

  const addParticle = (x: number, y: number, vx: number, vy: number, life: number, color: string, size: number) => {
    if (particlesRef.current.length < 200) {
      particlesRef.current.push(new MetalVaporParticle(x, y, vx, vy, life, color, size));
    }
  };

  const drawLightning = (
    ctx: CanvasRenderingContext2D,
    startX: number,
    startY: number,
    endX: number,
    endY: number,
    segments: number,
    color: string,
    thickness: number
  ) => {
    const dx = endX - startX;
    const dy = endY - startY;
    const length = Math.sqrt(dx * dx + dy * dy);

    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = thickness;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(startX, startY);

    for (let i = 1; i <= segments; i++) {
      const targetX = startX + (dx * (i / segments));
      const targetY = startY + (dy * (i / segments));

      let jitterX = (Math.random() - 0.5) * (length * 0.15);
      let jitterY = (Math.random() - 0.5) * (length * 0.15);

      if (i === segments) {
        jitterX = 0;
        jitterY = 0;
      }

      ctx.lineTo(targetX + jitterX, targetY + jitterY);
    }
    ctx.stroke();
    ctx.restore();
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        canvas.width = width || 400;
        canvas.height = height || 400;
      }
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;
      const cx = w / 2;
      const cy = h / 2 - 20;

      ctx.clearRect(0, 0, w, h);

      const state = stateRef.current;

      // Update simulation physics
      if (state.mode === 'opening') {
        state.progress += 0.04; // Vacuum circuit breakers are extremely fast
        state.rotationAngle += 0.15; // Rotate AMF arc

        if (state.progress >= 0.1 && state.progress < 0.85) {
          state.arcIntensity = state.arcType === 'short' ? 1.0 : 0.5;

          // Metal copper/chromium vapor particles
          for (let i = 0; i < 4; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = 1.5 + Math.random() * 4.5;
            addParticle(
              cx,
              cy,
              Math.cos(angle) * speed,
              Math.sin(angle) * speed,
              12 + Math.random() * 15,
              Math.random() > 0.4 ? '#d8b4fe' : '#38bdf8', // Purple/blue metal vapor glow
              1.5 + Math.random() * 2
            );
          }
        } else if (state.progress >= 0.85) {
          state.arcIntensity *= 0.65; // Extremely rapid dielectric recovery in vacuum
        }

        if (state.progress >= 1.0) {
          state.progress = 1.0;
          state.mode = 'open';
          state.arcIntensity = 0;
          setMode('open');
        }
      } else if (state.mode === 'closing') {
        state.progress -= 0.06; // Closes very fast
        if (state.progress <= 0) {
          state.progress = 0;
          state.mode = 'closed';
          setMode('closed');
        }
      }

      // Update particles
      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        particles[i].update();
        if (particles[i].life <= 0) {
          particles.splice(i, 1);
        }
      }

      // Drawing
      const scale = Math.min(1, w / 400);
      ctx.save();
      ctx.translate(cx, cy);
      ctx.scale(scale, scale);

      // --- CERAMIC BOTTLE ENVELOPE (Izolační těleso) ---
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 5;

      // Outer shape with fins (corrugations) for high dielectric creepage distance
      ctx.beginPath();
      ctx.moveTo(-75, -110);
      ctx.lineTo(-90, -90);
      ctx.lineTo(-90, 90);
      ctx.lineTo(-75, 110);
      ctx.lineTo(75, 110);
      ctx.lineTo(90, 90);
      ctx.lineTo(90, -90);
      ctx.lineTo(75, -110);
      ctx.closePath();

      // Create subtle ceramic gradient
      const ceramicGrd = ctx.createLinearGradient(-90, 0, 90, 0);
      ceramicGrd.addColorStop(0, '#f8fafc');
      ceramicGrd.addColorStop(0.5, '#ffffff');
      ceramicGrd.addColorStop(1, '#cbd5e1');
      ctx.fillStyle = ceramicGrd;
      ctx.fill();
      ctx.stroke();

      // Corrugations (horizontal fins)
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 3;
      for (let yOffset = -75; yOffset <= 75; yOffset += 25) {
        ctx.beginPath();
        ctx.moveTo(-93, yOffset);
        ctx.lineTo(93, yOffset);
        ctx.stroke();
      }

      // Internal metal shield (stínění zachycující páry kovu)
      ctx.fillStyle = 'rgba(71, 85, 105, 0.35)';
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(-55, -60, 110, 120, 4);
      ctx.fill();
      ctx.stroke();

      // Vacuum text label
      ctx.font = '12px "JetBrains Mono", monospace';
      ctx.fillStyle = '#94a3b8';
      ctx.textAlign = 'center';
      ctx.fillText("HLUBOKÉ VAKUUM", 0, -125);

      // --- CONTACTS CALCULATION ---
      const gapY = state.progress * 25; // 0 to 25px gap

      // --- FIXED CONTACT (Top) ---
      const metalGrd = ctx.createLinearGradient(-15, 0, 15, 0);
      metalGrd.addColorStop(0, '#94a3b8');
      metalGrd.addColorStop(0.5, '#e2e8f0');
      metalGrd.addColorStop(1, '#475569');

      ctx.fillStyle = metalGrd;
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 1.5;

      // Stationary stem
      ctx.fillRect(-8, -130, 16, 130 - gapY / 2 - 10);

      // AMF (Axial Magnetic Field) Contact Head (Top)
      // Spirálové/AMF zářezy - copper color head
      const copperGrd = ctx.createLinearGradient(-35, 0, 35, 0);
      copperGrd.addColorStop(0, '#c2410c');
      copperGrd.addColorStop(0.5, '#ea580c');
      copperGrd.addColorStop(1, '#9a3412');
      ctx.fillStyle = copperGrd;

      ctx.beginPath();
      ctx.arc(0, -gapY / 2 - 10, 35, Math.PI, 0);
      ctx.fill();
      ctx.fillRect(-35, -gapY / 2 - 10, 70, 10);
      ctx.strokeRect(-35, -gapY / 2 - 10, 70, 10);

      // Contact Slots (AMF cuts)
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.lineWidth = 2;
      for (let i = -25; i <= 25; i += 12) {
        if (i === 0) continue;
        ctx.beginPath();
        ctx.moveTo(i, -gapY / 2 - 10);
        ctx.lineTo(i - (i > 0 ? 5 : -5), -gapY / 2 - 25);
        ctx.stroke();
      }

      // --- MOVING CONTACT (Bottom) ---
      ctx.fillStyle = metalGrd;
      ctx.fillRect(-8, gapY / 2 + 10, 16, 130 - gapY / 2 - 10);

      // AMF Contact Head (Bottom)
      ctx.fillStyle = copperGrd;
      ctx.beginPath();
      ctx.arc(0, gapY / 2 + 10, 35, 0, Math.PI);
      ctx.fill();
      ctx.fillRect(-35, gapY / 2, 70, 10);
      ctx.strokeRect(-35, gapY / 2, 70, 10);

      // AMF Cuts (Bottom)
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.lineWidth = 2;
      for (let i = -25; i <= 25; i += 12) {
        if (i === 0) continue;
        ctx.beginPath();
        ctx.moveTo(i, gapY / 2 + 10);
        ctx.lineTo(i - (i > 0 ? 5 : -5), gapY / 2 + 25);
        ctx.stroke();
      }

      // --- BELLOWS (Nerezový vlnovec) ---
      // Allows moving terminal to slide up and down without breaking the hermetic vacuum seal
      const bellowTop = gapY / 2 + 10 + 35;
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 1.5;
      for (let i = 0; i < 5; i++) {
        const by = bellowTop + i * 9;
        ctx.beginPath();
        ctx.moveTo(-20, by);
        ctx.lineTo(-30, by + 4);
        ctx.lineTo(30, by + 4);
        ctx.lineTo(20, by);
        ctx.stroke();
      }

      // --- DIFFUSE VACUUM ARC ---
      if (state.arcIntensity > 0.04) {
        ctx.save();
        // Plasma plume (glow)
        ctx.globalAlpha = state.arcIntensity * 0.4;
        const radGrd = ctx.createRadialGradient(0, 0, 5, 0, 0, 45);
        radGrd.addColorStop(0, state.arcType === 'short' ? '#ffffff' : '#d8b4fe');
        radGrd.addColorStop(0.5, 'rgba(168, 85, 247, 0.5)');
        radGrd.addColorStop(1, 'rgba(168, 85, 247, 0)');
        ctx.fillStyle = radGrd;
        ctx.beginPath();
        ctx.ellipse(0, 0, 45, gapY / 2 + 10, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // Rotating AMF arc filament lines
        ctx.save();
        ctx.globalAlpha = state.arcIntensity;
        ctx.rotate(state.rotationAngle);

        const numChannels = state.arcType === 'short' ? 9 : 3;
        const arcColor = state.arcType === 'short' ? '#ffffff' : '#c084fc';
        const thickness = state.arcType === 'short' ? 3.5 : 1.5;

        for (let i = 0; i < numChannels; i++) {
          const angle = (Math.PI * 2 / numChannels) * i;
          const radius = 18;

          const startX = Math.cos(angle) * radius;
          const endX = Math.cos(angle + 0.8) * radius; // Twisted / swirling effect

          drawLightning(
            ctx,
            startX,
            -gapY / 2 - 2,
            endX,
            gapY / 2 + 2,
            2,
            arcColor,
            thickness
          );
        }
        ctx.restore();
      }

      ctx.restore();

      // Render metal vapor particles
      particles.forEach((p) => p.draw(ctx));

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
    };
  }, []);

  const triggerOpen = (type: 'normal' | 'short') => {
    if (mode === 'closed') {
      setArcType(type);
      setMode('opening');
    }
  };

  const triggerClose = () => {
    if (mode === 'open') {
      setMode('closing');
    }
  };

  return (
    <div className="grid lg:grid-cols-3 gap-6 flex-1 h-full">
      {/* Simulation Box */}
      <div className="lg:col-span-2 flex flex-col h-full">
        <div ref={containerRef} className="simulation-container flex-1 min-h-[400px] md:min-h-[500px]">
          <canvas ref={canvasRef}></canvas>
          
          {/* Controls Overlay */}
          <div className="overlay-controls">
            <button
              onClick={triggerClose}
              disabled={mode !== 'open'}
              className="btn-sim px-3 md:px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded font-bold shadow-lg flex items-center gap-2 text-xs md:text-sm cursor-pointer"
            >
              <Link className="w-4 h-4" /> Zapnout
            </button>
            <button
              onClick={() => triggerOpen('normal')}
              disabled={mode !== 'closed'}
              className="btn-sim px-3 md:px-4 py-2 bg-slate-600 hover:bg-slate-500 disabled:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded font-bold shadow-lg flex items-center gap-2 text-xs md:text-sm cursor-pointer"
            >
              <Unlink className="w-4 h-4" /> Vypnout zátěž
            </button>
            <button
              onClick={() => triggerOpen('short')}
              disabled={mode !== 'closed'}
              className="btn-sim px-3 md:px-4 py-2 bg-red-600 hover:bg-red-500 disabled:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded font-bold shadow-lg flex items-center gap-2 text-xs md:text-sm cursor-pointer"
            >
              <Zap className="w-4 h-4" /> Zkrat!
            </button>
          </div>
        </div>
      </div>

      {/* Sidebar explanation panel */}
      <div className="bg-slate-800 rounded-xl p-5 border border-slate-700 flex flex-col h-full overflow-y-auto justify-between">
        <div>
          <h3 className="text-lg font-bold text-white mb-4 border-b border-slate-700 pb-2 flex items-center gap-2">
            <CircleDot className="w-5 h-5 text-indigo-400" /> Jak funguje vakuová komora
          </h3>
          
          <div className="space-y-3 text-xs md:text-sm text-slate-300">
            <div className={`p-3 rounded border transition-colors ${mode === 'open' ? 'bg-indigo-950/40 border-indigo-600/50' : 'bg-slate-900/50 border-slate-800'}`}>
              <h4 className="font-bold text-indigo-400 mb-1">Extrémní pevnost vakua</h4>
              <p className="leading-normal">Pro spolehlivé uhašení oblouku a bezvadné izolační vlastnosti stačí oddálit kontakty o pouhých <strong>8-12 mm</strong>. Pohon je díky tomu mimořádně rychlý a nenáročný.</p>
            </div>
            
            <div className={`p-3 rounded border transition-colors ${mode === 'opening' && stateRef.current.progress < 0.6 ? 'bg-amber-950/40 border-amber-500/50' : 'bg-slate-900/50 border-slate-800'}`}>
              <h4 className="font-bold text-amber-400 mb-1">Z čeho hoří oblouk?</h4>
              <p className="leading-normal">Ve vakuu neexistuje plyn, který by se ionizoval. Při oddálení kontaktů se vlivem obrovské proudové hustoty odpaří kov. <strong>Elektrický oblouk hoří v plazmatu z odpařeného měď-chromového kovu kontaktů</strong>.</p>
            </div>
            
            <div className={`p-3 rounded border transition-colors ${mode === 'opening' && stateRef.current.progress >= 0.6 ? 'bg-purple-950/40 border-purple-500/50' : 'bg-slate-900/50 border-slate-800'}`}>
              <h4 className="font-bold text-purple-400 mb-1">Rotace AMF poli (Zářezy)</h4>
              <p className="leading-normal">Aby stacionární oblouk kontakty lokálně nepropálil, mají kontakty spirálové zářezy. Protékající proud vytvoří axiální magnetické pole (AMF), které nutí oblouk po ploše rotovat velkou rychlostí.</p>
            </div>
            
            <div className={`p-3 rounded border transition-colors ${mode === 'opening' && stateRef.current.progress >= 0.95 ? 'bg-teal-950/40 border-teal-500/50' : 'bg-slate-900/50 border-slate-800'}`}>
              <h4 className="font-bold text-teal-400 mb-1">Kondenzace par</h4>
              <p className="leading-normal">Při průchodu proudu nulou kovové páry okamžitě zkondenzují na studeném vnitřním stínění. Izolační síla se obnoví v řádu mikrosekund.</p>
            </div>
          </div>
        </div>
        
        <div className="mt-6 pt-4 border-t border-slate-700 shrink-0">
          <div className="flex items-center gap-2 mb-2">
            <span className={`w-3.5 h-3.5 rounded-full ${
              mode === 'open' ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' :
              mode === 'closed' ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]' :
              'bg-amber-500 animate-pulse'
            }`}></span>
            <span className="font-bold text-white text-sm">
              Stav komory:{' '}
              <span className={
                mode === 'open' ? 'text-green-500' :
                mode === 'closed' ? 'text-red-500' :
                'text-amber-500'
              }>
                {mode === 'open' ? 'VYPNUTO (Bezpečný stav)' :
                 mode === 'closed' ? 'ZAPNUTO (Pod zátěží)' :
                 'V POHYBU'}
              </span>
            </span>
          </div>
          <p className="text-xs text-slate-400">
            {mode === 'open' && 'Hluboké vakuum zajišťuje maximální izolační pevnost i při minimálním rozpojení.'}
            {mode === 'closed' && 'Kontakty pevně doléhají silným tlakem pružin.'}
            {mode === 'opening' && 'Rozpínání kontaktů. Difuzní oblouk je vytlačen rotací.'}
            {mode === 'closing' && 'Mimořádně rychlé sepnutí kontaktů.'}
          </p>
        </div>
      </div>
    </div>
  );
}
