import React, { useEffect, useRef, useState } from 'react';
import { Zap, ShieldAlert, AlertTriangle, Eye, ArrowRight, Play, RefreshCw, Sparkles, Thermometer, Gauge, Wind } from 'lucide-react';
import { motion } from 'motion/react';

// ==========================================
// 1. ARC THEORY SIMULATOR (Category: theory)
// ==========================================
export function ArcTheorySimulator() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [voltage, setVoltage] = useState<number>(110); // kV
  const [current, setCurrent] = useState<number>(200); // A
  const [spacing, setSpacing] = useState<number>(30); // mm
  const [isArcLit, setIsArcLit] = useState<boolean>(true);
  const [deionizationRate, setDeionizationRate] = useState<number>(40); // %

  const animationRef = useRef<number | null>(null);
  const timeRef = useRef<number>(0);

  const igniteArc = () => {
    setIsArcLit(true);
  };

  const triggerZeroCrossing = () => {
    // Zero crossing can extinguish arc if deionization/spacing is high enough
    const survivalProbability = (current * voltage) / (spacing * (deionizationRate / 10));
    if (survivalProbability < 1.5) {
      setIsArcLit(false);
    } else {
      // Temporary flicker
      setIsArcLit(false);
      setTimeout(() => setIsArcLit(true), 150);
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = canvas.width = 320;
    let height = canvas.height = 200;

    const render = () => {
      ctx.clearRect(0, 0, width, height);
      timeRef.current += 0.15;

      const cx = width / 2;
      const cy = height / 2 + 30;

      // Draw Electrodes (V-shaped Jacob's Ladder)
      ctx.strokeStyle = '#4A4E57';
      ctx.lineWidth = 6;
      ctx.lineCap = 'round';

      // Left electrode
      ctx.beginPath();
      ctx.moveTo(cx - 30, cy);
      ctx.quadraticCurveTo(cx - 40, cy - 40, cx - 70, cy - 110);
      ctx.stroke();

      // Right electrode
      ctx.beginPath();
      ctx.moveTo(cx + 30, cy);
      ctx.quadraticCurveTo(cx + 40, cy - 40, cx + 70, cy - 110);
      ctx.stroke();

      // Spark contact pads
      ctx.fillStyle = '#8E9AA8';
      ctx.beginPath();
      ctx.arc(cx - 30, cy, 5, 0, Math.PI * 2);
      ctx.arc(cx + 30, cy, 5, 0, Math.PI * 2);
      ctx.fill();

      // Arc Simulation
      if (isArcLit && current > 0) {
        // Compute vertical position of the arc based on time (rising motion of Jacob's ladder)
        const speed = (current / 200) * 0.5;
        const riseCycle = (timeRef.current * speed) % 100;
        const riseRatio = riseCycle / 100;

        // X coordinate spacing changes with height (V-shape)
        const arcY = cy - riseRatio * 100;
        const leftX = (cx - 30) - riseRatio * 35;
        const rightX = (cx + 30) + riseRatio * 35;

        // If spacing exceeds physical capability of voltage, extinguish
        const currentDistance = rightX - leftX;
        const maxSupportedDistance = (voltage * 1.5) + 40;
        
        if (currentDistance > maxSupportedDistance) {
          setIsArcLit(false);
          return;
        }

        // Draw Plasma glow
        const glowRadius = (current / 100) * 8 + 4;
        const grad = ctx.createRadialGradient((leftX + rightX) / 2, arcY, 2, (leftX + rightX) / 2, arcY, glowRadius * 2);
        
        // Color depends on current/voltage (high power = blue/white, low power = red/yellow)
        if (current > 300) {
          grad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
          grad.addColorStop(0.2, 'rgba(62, 99, 221, 0.9)');
          grad.addColorStop(1, 'rgba(142, 78, 198, 0)');
        } else {
          grad.addColorStop(0, 'rgba(255, 240, 200, 0.95)');
          grad.addColorStop(0.3, 'rgba(245, 158, 11, 0.8)');
          grad.addColorStop(1, 'rgba(239, 68, 68, 0)');
        }

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc((leftX + rightX) / 2, arcY, glowRadius * 3, 0, Math.PI * 2);
        ctx.fill();

        // Draw chaotic electrical lightning path between leftX and rightX
        ctx.strokeStyle = current > 300 ? '#A5C9FF' : '#FFE27C';
        ctx.lineWidth = 2 + (current / 200);
        ctx.beginPath();
        ctx.moveTo(leftX, arcY);

        const segments = 12;
        for (let i = 1; i < segments; i++) {
          const ratio = i / segments;
          const currX = leftX + (rightX - leftX) * ratio;
          // Add chaotic vertical & horizontal jitter
          const jitterX = (Math.random() - 0.5) * 6;
          const jitterY = (Math.random() - 0.5) * (8 + (current / 100) * 4);
          ctx.lineTo(currX + jitterX, arcY + jitterY);
        }
        ctx.lineTo(rightX, arcY);
        ctx.stroke();

        // Little fire particles drifting up
        if (Math.random() > 0.4) {
          ctx.fillStyle = 'rgba(245, 158, 11, 0.6)';
          ctx.beginPath();
          ctx.arc((leftX + rightX) / 2 + (Math.random() - 0.5) * 30, arcY - Math.random() * 20, Math.random() * 3 + 1, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Information display
      ctx.fillStyle = '#9BA1A6';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.fillText(`Napětí: ${voltage} kV`, 10, 20);
      ctx.fillText(`Proud: ${current} A`, 10, 35);
      ctx.fillText(`Hlava oblouku: ${isArcLit ? 'ZAPÁLEN' : 'UHAŠEN'}`, 10, 50);

      animationRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [voltage, current, spacing, isArcLit, deionizationRate]);

  return (
    <div className="flex flex-col bg-[#111112] border border-[#1F1F21] rounded-2xl p-4 h-full justify-between">
      <div className="shrink-0">
        <h4 className="text-sm font-bold text-white flex items-center gap-1.5 mb-2">
          <Zap className="w-4 h-4 text-amber-400" />
          Fyzikální simulátor el. oblouku
        </h4>
        <p className="text-xs text-[#9BA1A6] mb-3 leading-normal">
          Jacobův žebřík: plazma stoupá prouděním teplého vzduchu vzhůru, prodlužuje se a hasne.
        </p>
      </div>

      <div className="relative flex justify-center bg-[#0A0A0B] rounded-xl border border-[#1F1F21] py-2 overflow-hidden h-[180px]">
        <canvas ref={canvasRef} className="max-w-full" />
        {!isArcLit && (
          <div className="absolute inset-0 bg-[#0A0A0B]/80 flex flex-col items-center justify-center text-center p-2 animate-fadeIn">
            <span className="text-xs font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-2.5 py-1 rounded-full flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" /> Deionizováno
            </span>
            <p className="text-[11px] text-[#7E8085] mt-1.5 max-w-[200px]">Oblouk zhasl v nule proudu nebo byl roztažen nad izolační mez.</p>
          </div>
        )}
      </div>

      <div className="space-y-2 mt-3">
        <div className="flex justify-between items-center text-xs">
          <span className="text-[#9BA1A6]">Napětí VN:</span>
          <span className="text-white font-mono">{voltage} kV</span>
        </div>
        <input
          type="range"
          min="1"
          max="400"
          value={voltage}
          onChange={(e) => setVoltage(Number(e.target.value))}
          className="w-full accent-[#3E63DD] h-1 bg-[#1F1F21] rounded-lg appearance-none cursor-pointer"
        />

        <div className="flex justify-between items-center text-xs">
          <span className="text-[#9BA1A6]">Vypínaný proud:</span>
          <span className="text-white font-mono">{current} A</span>
        </div>
        <input
          type="range"
          min="0"
          max="500"
          value={current}
          onChange={(e) => setCurrent(Number(e.target.value))}
          className="w-full accent-[#3E63DD] h-1 bg-[#1F1F21] rounded-lg appearance-none cursor-pointer"
        />

        <div className="flex justify-between items-center text-xs">
          <span className="text-[#9BA1A6]">Rychlost deionizace:</span>
          <span className="text-white font-mono">{deionizationRate} %</span>
        </div>
        <input
          type="range"
          min="10"
          max="100"
          value={deionizationRate}
          onChange={(e) => setDeionizationRate(Number(e.target.value))}
          className="w-full accent-[#3E63DD] h-1 bg-[#1F1F21] rounded-lg appearance-none cursor-pointer"
        />

        <div className="grid grid-cols-2 gap-2 pt-2">
          <button
            onClick={igniteArc}
            className="px-3 py-1.5 bg-[#1F1F21] hover:bg-[#2E2E32] text-xs font-semibold rounded-lg text-white border border-[#2E2E32] active:scale-95 transition-all"
          >
            Zapálit oblouk
          </button>
          <button
            onClick={triggerZeroCrossing}
            className="px-3 py-1.5 bg-[#3E63DD] hover:bg-[#3E63DD]/90 text-xs font-semibold rounded-lg text-white active:scale-95 transition-all"
          >
            Průchod nulou
          </button>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 2. DISCONNECTOR SAFETY SIMULATOR (Category: safety)
// ==========================================
export function DisconnectorSafetySimulator() {
  const [breakerClosed, setBreakerClosed] = useState<boolean>(true); // Vypínač (true = closed, false = open)
  const [disconnectorClosed, setDisconnectorClosed] = useState<boolean>(true); // Odpojovač
  const [grounderClosed, setGrounderClosed] = useState<boolean>(false); // Uzemňovač
  const [loadCurrent, setLoadCurrent] = useState<number>(60); // A
  const [hasExploded, setHasExploded] = useState<boolean>(false);
  const [explosionType, setExplosionType] = useState<'load_disconnection' | 'ground_short' | null>(null);

  const resetAll = () => {
    setBreakerClosed(true);
    setDisconnectorClosed(true);
    setGrounderClosed(false);
    setHasExploded(false);
    setExplosionType(null);
  };

  const toggleBreaker = () => {
    if (hasExploded) return;
    setBreakerClosed(!breakerClosed);
  };

  const toggleDisconnector = () => {
    if (hasExploded) return;
    // CRITICAL DANGER: Disconnector opened or closed under load!
    const isCarryingCurrent = breakerClosed && disconnectorClosed && loadCurrent > 0;
    if (isCarryingCurrent) {
      setHasExploded(true);
      setExplosionType('load_disconnection');
    } else {
      setDisconnectorClosed(!disconnectorClosed);
    }
  };

  const toggleGrounder = () => {
    if (hasExploded) return;
    // CRITICAL DANGER: Grounder closed while system has power!
    // If disconnector is closed, the system is connected to the grid power source
    if (!grounderClosed && disconnectorClosed) {
      setHasExploded(true);
      setExplosionType('ground_short');
    } else {
      setGrounderClosed(!grounderClosed);
    }
  };

  // Determine safety state
  const isLineEnergized = disconnectorClosed && breakerClosed;
  const isSafeForWork = !breakerClosed && !disconnectorClosed && grounderClosed;

  return (
    <div className="flex flex-col bg-[#111112] border border-[#1F1F21] rounded-2xl p-4 h-full justify-between min-h-[380px]">
      <div className="shrink-0">
        <h4 className="text-sm font-bold text-white flex items-center gap-1.5 mb-1.5">
          <ShieldAlert className="w-4 h-4 text-red-500" />
          Zlaté pravidlo bezpečnosti (VN)
        </h4>
        <p className="text-xs text-[#9BA1A6] mb-3 leading-normal">
          Vyzkoušejte správné pořadí vypínání. Klikáním ovládejte jednotlivé spínací prvky v rozvodně.
        </p>
      </div>

      {/* Schematic Layout Panel */}
      <div className="relative flex flex-col items-center justify-center bg-[#0A0A0B] rounded-xl border border-[#1F1F21] py-4 px-2 overflow-hidden h-[160px]">
        {hasExploded ? (
          <div className="absolute inset-0 bg-red-950/90 flex flex-col items-center justify-center text-center p-3 z-10 animate-fadeIn">
            <AlertTriangle className="w-10 h-10 text-red-500 animate-bounce mb-1" />
            <span className="text-xs font-bold text-red-200">
              {explosionType === 'load_disconnection' 
                ? 'KATASTROFÁLNÍ HAVÁRIE! Odpojovač otevřen pod zátěží!' 
                : 'ZKRAT! Uzemňovač spojen s živou fází pod napětím!'}
            </span>
            <p className="text-[11px] text-red-300 mt-1 max-w-[240px]">
              {explosionType === 'load_disconnection' 
                ? 'Odpojovač nemá zhášecí zařízení. Elektrický oblouk jej roztavil a vyvolal zkrat v celé kobce!'
                : 'Uzemňovač se smí zapnout až tehdy, kdy je odpojovač bezpečně rozpojen!'}
            </p>
            <button
              onClick={resetAll}
              className="mt-2 px-3 py-1 bg-red-800 hover:bg-red-700 text-white text-xs font-bold rounded flex items-center gap-1"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Opravit a resetovat
            </button>
          </div>
        ) : null}

        {/* Dynamic flowing current line */}
        <div className="w-full flex items-center justify-between px-6 relative z-0">
          
          {/* Wire Background Line */}
          <div className="absolute left-6 right-6 h-1 bg-[#1F1F21] -translate-y-1/2 top-1/2"></div>
          
          {/* Flowing electrons */}
          {isLineEnergized && (
            <div className="absolute left-6 right-6 h-1 -translate-y-1/2 top-1/2 overflow-hidden">
              <div className="w-full h-full bg-gradient-to-r from-transparent via-[#3E63DD] to-transparent animate-pulse" />
              <div className="absolute left-0 w-2 h-1 bg-amber-400 animate-[moveElectrons_2s_linear_infinite]" style={{
                boxShadow: '0 0 8px #f59e0b'
              }} />
            </div>
          )}

          {/* 1. Zdroj (Power Source) */}
          <div className="flex flex-col items-center z-10">
            <div className="w-8 h-8 rounded-full bg-[#161618] border border-[#1F1F21] flex items-center justify-center font-mono text-[10px] text-[#EDEDEF]">
              G
            </div>
            <span className="text-[9px] text-[#7E8085] mt-1">Zdroj VN</span>
          </div>

          {/* 2. Výkonový Vypínač */}
          <button 
            onClick={toggleBreaker}
            className={`flex flex-col items-center z-10 p-1 rounded-lg border transition-all ${
              breakerClosed ? 'bg-red-950/40 border-red-500/50' : 'bg-[#161618] border-[#1F1F21]'
            }`}
          >
            <div className="h-6 w-8 flex items-center justify-center relative">
              {breakerClosed ? (
                <div className="w-6 h-1 bg-red-500 rounded" />
              ) : (
                <div className="w-6 h-1 bg-emerald-500 rounded -rotate-45 transform origin-left" />
              )}
            </div>
            <span className="text-[9px] font-bold text-white">Vypínač</span>
            <span className="text-[8px] text-[#9BA1A6] font-mono">{breakerClosed ? 'SEP' : 'VYP'}</span>
          </button>

          {/* 3. Odpojovač */}
          <button 
            onClick={toggleDisconnector}
            className={`flex flex-col items-center z-10 p-1 rounded-lg border transition-all ${
              disconnectorClosed ? 'bg-red-950/40 border-red-500/50' : 'bg-[#161618] border-emerald-500/50'
            }`}
          >
            <div className="h-6 w-8 flex items-center justify-center relative">
              {disconnectorClosed ? (
                <div className="w-6 h-1.5 bg-red-500 rounded" />
              ) : (
                <div className="w-6 h-1.5 bg-emerald-500 rounded -rotate-60 transform origin-left" />
              )}
            </div>
            <span className="text-[9px] font-bold text-white">Odpojovač</span>
            <span className="text-[8px] text-[#9BA1A6] font-mono">{disconnectorClosed ? 'SEP (Nože)' : 'VYP (Izol.)'}</span>
          </button>

          {/* 4. Uzemňovač */}
          <button 
            onClick={toggleGrounder}
            className={`flex flex-col items-center z-10 p-1 rounded-lg border transition-all ${
              grounderClosed ? 'bg-emerald-950/40 border-emerald-500/50' : 'bg-[#161618] border-[#1F1F21]'
            }`}
          >
            <div className="h-6 w-8 flex flex-col items-center justify-center relative">
              {grounderClosed ? (
                <div className="w-1 h-4 bg-emerald-500" />
              ) : (
                <div className="w-1 h-4 bg-[#4A4E57] -rotate-45" />
              )}
            </div>
            <span className="text-[9px] font-bold text-white">Uzemnit</span>
            <span className="text-[8px] text-[#9BA1A6] font-mono">{grounderClosed ? 'ZEMN' : 'VOLN'}</span>
          </button>

          {/* 5. Overhead line worker */}
          <div className="flex flex-col items-center z-10">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs border ${
              isSafeForWork 
                ? 'bg-emerald-950 border-emerald-500 text-emerald-400' 
                : isLineEnergized 
                ? 'bg-red-950 border-red-500 text-red-500 animate-pulse'
                : 'bg-[#161618] border-[#1F1F21] text-[#9BA1A6]'
            }`}>
              👷
            </div>
            <span className="text-[9px] text-[#7E8085] mt-1">Práce</span>
          </div>

        </div>

        {/* Safety Indicator Label */}
        <div className="mt-4 text-[10px] font-mono font-bold px-3 py-1 rounded-full border">
          {isSafeForWork ? (
            <span className="text-emerald-400">✅ BEZPEČNÝ STAV: Lze provádět údržbu (Vypnuto + Uzemněno!)</span>
          ) : isLineEnergized ? (
            <span className="text-red-400 animate-pulse">⚠️ NEBEZPEČÍ: Linka je pod napětím! Vstup zakázán!</span>
          ) : (
            <span className="text-amber-400">⏳ ODPOJENO, ale chybí uzemnění! Linka není připravena pro lidi.</span>
          )}
        </div>
      </div>

      {/* Interactive slider */}
      <div className="space-y-2 mt-2">
        <div className="flex justify-between items-center text-xs">
          <span className="text-[#9BA1A6]">Velikost zatěžovacího proudu:</span>
          <span className="text-white font-mono">{loadCurrent} A</span>
        </div>
        <input
          type="range"
          min="0"
          max="150"
          value={loadCurrent}
          onChange={(e) => setLoadCurrent(Number(e.target.value))}
          disabled={hasExploded}
          className="w-full accent-[#3E63DD] h-1 bg-[#1F1F21] rounded-lg appearance-none cursor-pointer"
        />
        
        <div className="text-[10px] text-[#7E8085] leading-normal bg-[#0A0A0B] p-2 rounded-lg border border-[#1F1F21] text-center">
          <strong>Úkol:</strong> Bezpečně odstavte síť pro pracovníka údržby (👷). Nejprve přerušte výkon vypínačem, pak rozpojte izolační odpojovač a nakonec bezpečně uzemněte!
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 3. SF6 GAS SIMULATOR (Category: sf6)
// ==========================================
class GasMolecule {
  x: number;
  y: number;
  vx: number;
  vy: number;
  type: 'sf6' | 'electron' | 'ion';
  radius: number;

  constructor(x: number, y: number, type: 'sf6' | 'electron' | 'ion') {
    this.x = x;
    this.y = y;
    this.type = type;
    
    if (type === 'sf6') {
      this.vx = (Math.random() - 0.5) * 1.5;
      this.vy = (Math.random() - 0.5) * 1.5;
      this.radius = 8;
    } else if (type === 'electron') {
      this.vx = (Math.random() - 0.5) * 6; // Electrons are extremely fast
      this.vy = (Math.random() - 0.5) * 6;
      this.radius = 2.5;
    } else {
      this.vx = (Math.random() - 0.5) * 0.4; // Ions are slow and heavy
      this.vy = (Math.random() - 0.5) * 0.4;
      this.radius = 9.5;
    }
  }

  update(width: number, height: number, pressure: number) {
    const speedMultiplier = 1 + (pressure - 1) * 0.15;
    this.x += this.vx * speedMultiplier;
    this.y += this.vy * speedMultiplier;

    // Boundaries bounce
    if (this.x < this.radius) { this.x = this.radius; this.vx *= -1; }
    if (this.x > width - this.radius) { this.x = width - this.radius; this.vx *= -1; }
    if (this.y < this.radius) { this.y = this.radius; this.vy *= -1; }
    if (this.y > height - this.radius) { this.y = height - this.radius; this.vy *= -1; }
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.save();
    if (this.type === 'sf6') {
      // Sulfur central (Orange) + Fluorines surrounding (Greenish)
      ctx.fillStyle = '#10B981'; // Fluorine color
      ctx.beginPath();
      // Draw a clustered molecule structure
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fill();

      // Core sulfur
      ctx.fillStyle = '#F59E0B';
      ctx.beginPath();
      ctx.arc(this.x, this.y, 3, 0, Math.PI * 2);
      ctx.fill();
    } else if (this.type === 'electron') {
      // Glowing blue electron
      ctx.shadowBlur = 6;
      ctx.shadowColor = '#3E63DD';
      ctx.fillStyle = '#3E63DD';
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // Heavy negative SF6- ion
      ctx.fillStyle = '#4F46E5';
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#818CF8';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Draw negative sign
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 8px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('-', this.x, this.y + 3);
    }
    ctx.restore();
  }
}

export function SF6GasSimulator() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [pressure, setPressure] = useState<number>(3); // bar
  const [temp, setTemp] = useState<number>(20); // °C
  const [electronCaptureCount, setElectronCaptureCount] = useState<number>(0);
  const [isBlasting, setIsBlasting] = useState<boolean>(false);

  const particlesRef = useRef<GasMolecule[]>([]);
  const animationRef = useRef<number | null>(null);

  const triggerBlast = () => {
    setIsBlasting(true);
    setTimeout(() => setIsBlasting(false), 800);
  };

  useEffect(() => {
    // Initialize molecules
    const particles: GasMolecule[] = [];
    
    // SF6 molecules (quantity scales with pressure)
    const sf6Count = 15 + pressure * 4;
    for (let i = 0; i < sf6Count; i++) {
      particles.push(new GasMolecule(Math.random() * 300, Math.random() * 150, 'sf6'));
    }

    // Free electrons (fast ionizing)
    for (let i = 0; i < 12; i++) {
      particles.push(new GasMolecule(Math.random() * 300, Math.random() * 150, 'electron'));
    }

    particlesRef.current = particles;
  }, [pressure]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = canvas.width = 320;
    let height = canvas.height = 140;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Liquid condensation check at low temperatures
      const isLiquid = temp < -25;
      
      // Draw gas chamber outline
      ctx.strokeStyle = '#1F1F21';
      ctx.lineWidth = 4;
      ctx.fillStyle = isLiquid ? 'rgba(16, 185, 129, 0.08)' : 'rgba(16, 185, 129, 0.03)';
      ctx.beginPath();
      ctx.rect(0, 0, width, height);
      ctx.fill();
      ctx.stroke();

      // Liquid puddle at the bottom
      if (isLiquid) {
        ctx.fillStyle = 'rgba(16, 185, 129, 0.25)';
        ctx.beginPath();
        ctx.rect(2, height - 15, width - 4, 13);
        ctx.fill();
        ctx.fillStyle = '#10B981';
        ctx.font = '8px sans-serif';
        ctx.fillText('ZKAPALNĚNÝ SF6 (Mráz)', 10, height - 5);
      }

      // Blast nozzle and jet stream visualization
      if (isBlasting) {
        ctx.fillStyle = 'rgba(14, 165, 233, 0.2)';
        ctx.beginPath();
        ctx.ellipse(width / 2, height / 2, 40, height / 2 - 10, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = 'rgba(14, 165, 233, 0.6)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(10, height / 2 - 20);
        ctx.lineTo(width - 10, height / 2 - 20);
        ctx.moveTo(10, height / 2 + 20);
        ctx.lineTo(width - 10, height / 2 + 20);
        ctx.stroke();

        ctx.fillStyle = '#0EA5E9';
        ctx.font = 'bold 9px "JetBrains Mono", monospace';
        ctx.fillText('BLAST OFUK', width / 2 - 30, height / 2 + 3);
      }

      const particles = particlesRef.current;

      // Update and draw molecules
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.update(width, height, isLiquid ? pressure * 0.4 : pressure);

        // Blasting sweeps electrons away
        if (isBlasting && p.type === 'electron') {
          p.vx += 1.5; // push right
          if (p.x > width - 10) {
            p.x = 20;
          }
        }

        p.draw(ctx);
      }

      // COLLISION DETECTION: Electronegative capture of electrons by SF6 molecules
      // If an electron gets close to SF6, it is captured to form a heavy SF6- negative ion
      for (let i = 0; i < particles.length; i++) {
        if (particles[i].type === 'sf6') {
          for (let j = 0; j < particles.length; j++) {
            if (particles[j].type === 'electron') {
              const dx = particles[i].x - particles[j].x;
              const dy = particles[i].y - particles[j].y;
              const distance = Math.sqrt(dx * dx + dy * dy);

              // Capture radius (increases with gas pressure)
              const captureRadius = 15 + pressure;

              if (distance < captureRadius) {
                // Electron is captured! Convert SF6 to heavy ion and remove electron
                particles[i].type = 'ion';
                particles.splice(j, 1);
                setElectronCaptureCount((prev) => prev + 1);
                break;
              }
            }
          }
        }
      }

      // Slowly spawn new electrons if count drops too low
      const electronCount = particles.filter(p => p.type === 'electron').length;
      if (electronCount < 4 && Math.random() > 0.95) {
        particles.push(new GasMolecule(Math.random() * width, Math.random() * height, 'electron'));
      }

      animationRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [pressure, temp, isBlasting]);

  return (
    <div className="flex flex-col bg-[#111112] border border-[#1F1F21] rounded-2xl p-4 h-full justify-between">
      <div className="shrink-0">
        <h4 className="text-sm font-bold text-white flex items-center gap-1.5 mb-1.5">
          <Wind className="w-4 h-4 text-emerald-400" />
          SF6 Mikroskopický pohled & Ofuk
        </h4>
        <p className="text-xs text-[#9BA1A6] mb-3 leading-normal">
          SF<sub>6</sub> plyn je <strong>elektronegativní</strong> – přitahuje a zachycuje volné elektrony a tvoří těžké, pomalé ionty.
        </p>
      </div>

      <div className="relative flex justify-center rounded-xl overflow-hidden mb-3">
        <canvas ref={canvasRef} className="max-w-full rounded-xl" />
        <div className="absolute top-2 right-2 bg-black/70 px-2 py-0.5 rounded text-[9px] font-mono text-emerald-400">
          Zachyty: {electronCaptureCount} e⁻
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between items-center text-xs">
          <span className="text-[#9BA1A6] flex items-center gap-1"><Gauge className="w-3.5 h-3.5 text-blue-400" /> Tlak plynu:</span>
          <span className="text-white font-mono">{pressure} bar</span>
        </div>
        <input
          type="range"
          min="1"
          max="6"
          value={pressure}
          onChange={(e) => setPressure(Number(e.target.value))}
          className="w-full accent-[#3E63DD] h-1 bg-[#1F1F21] rounded-lg appearance-none cursor-pointer"
        />

        <div className="flex justify-between items-center text-xs">
          <span className="text-[#9BA1A6] flex items-center gap-1"><Thermometer className="w-3.5 h-3.5 text-amber-500" /> Teplota plynu:</span>
          <span className={`font-mono ${temp < -25 ? 'text-blue-400 font-bold' : 'text-white'}`}>{temp} °C</span>
        </div>
        <input
          type="range"
          min="-40"
          max="60"
          value={temp}
          onChange={(e) => setTemp(Number(e.target.value))}
          className="w-full accent-[#3E63DD] h-1 bg-[#1F1F21] rounded-lg appearance-none cursor-pointer"
        />

        <button
          onClick={triggerBlast}
          className="w-full mt-2 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
        >
          <Wind className="w-4 h-4 animate-bounce" /> Spustit tlakový ofuk tryskou (Puffer)
        </button>
      </div>
    </div>
  );
}

// ==========================================
// 4. VACUUM CHAMBER SIMULATOR (Category: vacuum)
// ==========================================
export function VacuumAMFSimulator() {
  const [isAmfEnabled, setIsAmfEnabled] = useState<boolean>(true);
  const [gap, setGap] = useState<number>(0); // mm (0 to 12)
  const [isOpening, setIsOpening] = useState<boolean>(false);
  const [vaporCount, setVaporCount] = useState<number>(0);
  const [arcRotation, setArcRotation] = useState<number>(0);

  useEffect(() => {
    let timer: number;
    if (isOpening) {
      setGap(0);
      let curr = 0;
      const interval = setInterval(() => {
        curr += 1;
        setGap(curr);
        setVaporCount(curr * 15);
        setArcRotation(r => r + 0.3);
        if (curr >= 12) {
          clearInterval(interval);
          // Quick deionization at the peak distance
          setTimeout(() => {
            setIsOpening(false);
            setVaporCount(0);
          }, 400);
        }
      }, 40);
    }
    return () => clearInterval(timer);
  }, [isOpening]);

  const triggerInterruption = () => {
    setIsOpening(true);
  };

  const isArcActive = isOpening && gap > 1 && gap < 11;

  return (
    <div className="flex flex-col bg-[#111112] border border-[#1F1F21] rounded-2xl p-4 h-full justify-between min-h-[380px]">
      <div className="shrink-0">
        <h4 className="text-sm font-bold text-white flex items-center gap-1.5 mb-1">
          <Eye className="w-4 h-4 text-purple-400" />
          Vakuový spínač: AMF vs. Kontcentrovaný oblouk
        </h4>
        <p className="text-xs text-[#9BA1A6] mb-3 leading-normal">
          Uhlídejte teplotu kontaktů. Axiální magnetické pole (AMF) nutí oblouk roztočit se a brání erozi kontaktů.
        </p>
      </div>

      {/* Ceramic Bottle Schematic View */}
      <div className="relative flex items-center justify-center bg-[#0A0A0B] rounded-xl border border-[#1F1F21] py-4 overflow-hidden h-[160px]">
        
        {/* Ceramic insulator ribs */}
        <div className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-[120px] flex flex-col justify-around">
          {[1, 2, 3, 4, 5].map(i => <div key={i} className="w-full h-3 bg-[#32231A] rounded-r border-r border-[#1F1F21]" />)}
        </div>
        <div className="absolute right-6 top-1/2 -translate-y-1/2 w-4 h-[120px] flex flex-col justify-around">
          {[1, 2, 3, 4, 5].map(i => <div key={i} className="w-full h-3 bg-[#32231A] rounded-l border-l border-[#1F1F21]" />)}
        </div>

        {/* Metal Condensation Shield */}
        <div className="absolute left-10 right-10 top-1/2 -translate-y-1/2 h-[95px] rounded-lg border border-[#4A4E57]/20 bg-[#4A4E57]/5 flex items-center justify-center">
          <span className="absolute bottom-1 text-[8px] font-mono text-[#7E8085] tracking-widest">KOVOVÝ ŠTÍT (KONDENZACE PAR METÁLU)</span>
        </div>

        {/* Top Fixed Contact */}
        <div className="absolute top-6 left-1/2 -translate-x-1/2 w-14 h-8 bg-gradient-to-r from-amber-600 via-amber-300 to-amber-700 rounded-b-md border border-amber-600 flex items-center justify-center">
          <span className="text-[8px] text-amber-950 font-bold">PEVNÝ</span>
        </div>

        {/* Bottom Moving Contact */}
        <div 
          className="absolute left-1/2 -translate-x-1/2 w-14 h-8 bg-gradient-to-r from-amber-600 via-amber-300 to-amber-700 rounded-t-md border border-amber-600 flex items-center justify-center transition-all duration-75"
          style={{ top: `${72 + gap * 3.5}px` }}
        >
          <span className="text-[8px] text-amber-950 font-bold">POHYBLIVÝ</span>
        </div>

        {/* The Arc */}
        {isArcActive && (
          <div 
            className="absolute left-1/2 -translate-x-1/2 w-10 flex flex-col items-center justify-center transition-all duration-75"
            style={{ 
              top: '48px',
              height: `${28 + gap * 3.5}px`
            }}
          >
            {isAmfEnabled ? (
              /* AMF: Spiral, rotating neon-blue diffuse arc */
              <div className="w-full h-full relative animate-pulse flex justify-around">
                <div className="w-1.5 h-full bg-cyan-400 rounded-full blur-[2px] animate-pulse" />
                <div className="w-1.5 h-full bg-indigo-400 rounded-full blur-[1px] animate-pulse" />
                <div className="w-1.5 h-full bg-cyan-300 rounded-full blur-[2px] animate-pulse" />
                <span className="absolute text-[8px] font-bold text-cyan-200 bg-cyan-950/60 px-1 rounded -top-2">DIFFUSE AMF</span>
              </div>
            ) : (
              /* AMF OFF: Concentrated, melting thick fiery yellow-red arc */
              <div className="w-4 h-full bg-gradient-to-r from-yellow-300 via-white to-red-500 rounded-full animate-ping relative">
                <div className="absolute inset-0 bg-amber-500 blur-sm rounded-full" />
                <span className="absolute text-[8px] font-bold text-red-400 bg-red-950/90 px-1 rounded -top-2 animate-bounce">KONCENTROVANÝ OBLOUK</span>
              </div>
            )}
          </div>
        )}

        {/* Condensing Vapor particles floating towards the shield */}
        {vaporCount > 0 && (
          <div className="absolute inset-0 pointer-events-none">
            {[1, 2, 3, 4, 5, 6].map((i) => {
              const leftSide = i % 2 === 0;
              return (
                <div 
                  key={i} 
                  className="absolute w-1.5 h-1.5 bg-amber-300 rounded-full animate-ping"
                  style={{
                    left: leftSide ? `${30 + i * 8}px` : `${200 + i * 8}px`,
                    top: `${50 + (i * 12) % 60}px`,
                    transition: 'all 0.4s ease'
                  }}
                />
              );
            })}
          </div>
        )}
      </div>

      <div className="space-y-2 mt-2">
        <div className="flex justify-between items-center bg-[#0A0A0B] p-2 rounded-lg border border-[#1F1F21]">
          <span className="text-xs text-[#9BA1A6]">Režim AMF cívky:</span>
          <button
            onClick={() => setIsAmfEnabled(!isAmfEnabled)}
            className={`px-3 py-1 rounded text-xs font-bold transition-all ${
              isAmfEnabled 
                ? 'bg-cyan-950 border border-cyan-500 text-cyan-300' 
                : 'bg-red-950 border border-red-500 text-red-300'
            }`}
          >
            {isAmfEnabled ? 'AMF AKTIVNÍ (Bezpečný rozptyl)' : 'VYPNUTO (Riziko tavení!)'}
          </button>
        </div>

        <button
          onClick={triggerInterruption}
          disabled={isOpening}
          className="w-full py-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold text-xs rounded-lg shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5"
        >
          <Play className="w-4 h-4 fill-current" /> Spustit zkratový vypínací cyklus
        </button>

        <p className="text-[10px] text-[#7E8085] leading-normal text-center">
          <strong>Rozdíl:</strong> Ve vakuu není plyn, oblouk hoří pouze v odpařených kovech kontaktů. AMF zabrání bodovému tavení a zaručí deionizaci v milisekundách!
        </p>
      </div>
    </div>
  );
}

// ==========================================
// 5. MAGNETIC BLOWOUT SIMULATOR (Category: magnetic)
// ==========================================
export function MagneticBlowoutSimulator() {
  const [blowoutCurrent, setBlowoutCurrent] = useState<number>(80); // A
  const [magneticField, setMagneticField] = useState<number>(1.2); // Tesla
  const [isArcBlowing, setIsArcBlowing] = useState<boolean>(false);
  const [arcHeight, setArcHeight] = useState<number>(0); // how high the arc has been pushed (0 to 100)
  const [isExtinguished, setIsExtinguished] = useState<boolean>(false);

  const triggerBlowout = () => {
    setIsArcBlowing(true);
    setIsExtinguished(false);
    setArcHeight(0);

    // Compute speed of blowing based on Lorentz Force (F = B * I * L)
    const force = magneticField * blowoutCurrent * 0.1;
    const duration = Math.max(100, 2000 - force * 10);

    let start = Date.now();
    const interval = setInterval(() => {
      let elapsed = Date.now() - start;
      let ratio = Math.min(1.0, elapsed / duration);
      setArcHeight(ratio * 100);

      if (ratio >= 1.0) {
        clearInterval(interval);
        // Split and extinguish
        setIsExtinguished(true);
        setIsArcBlowing(false);
      }
    }, 20);
  };

  const lorentzForce = magneticField * blowoutCurrent;

  return (
    <div className="flex flex-col bg-[#111112] border border-[#1F1F21] rounded-2xl p-4 h-full justify-between min-h-[380px]">
      <div className="shrink-0">
        <h4 className="text-sm font-bold text-white flex items-center gap-1.5 mb-1">
          <AlertTriangle className="w-4 h-4 text-orange-400" />
          Lorentzova síla & Deionizační rošt
        </h4>
        <p className="text-xs text-[#9BA1A6] mb-3 leading-normal">
          Zhasněte stejnosměrný oblouk. Lorentzova síla ho odfoukne kolmo vzhůru do dělících kovových roštů.
        </p>
      </div>

      {/* Blowout chamber schema */}
      <div className="relative flex items-center justify-center bg-[#0A0A0B] rounded-xl border border-[#1F1F21] py-4 overflow-hidden h-[160px]">
        
        {/* De-ion splitter plates (deionizační mříž / plechy) at the top */}
        <div className="absolute top-2 left-12 right-12 h-10 flex justify-between">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div 
              key={i} 
              className={`w-2.5 h-full bg-[#3E4247] border border-[#1F1F21] rounded-b flex items-end justify-center ${
                isArcBlowing && arcHeight > 70 ? 'border-amber-400 animate-pulse bg-slate-500' : ''
              }`}
            >
              <span className="text-[6px] font-mono text-white mb-1">20V</span>
            </div>
          ))}
        </div>
        <div className="absolute top-12 left-12 right-12 h-0.5 bg-[#4A4E57]/40"></div>

        {/* Contacts at the bottom */}
        <div className="absolute bottom-4 left-1/4 w-10 h-6 bg-[#202226] border border-[#1F1F21] rounded flex items-center justify-center">
          <span className="text-[8px] font-bold text-white">PEVNÝ</span>
        </div>
        <div className="absolute bottom-4 right-1/4 w-10 h-6 bg-[#202226] border border-[#1F1F21] rounded flex items-center justify-center">
          <span className="text-[8px] font-bold text-white">POHYB</span>
        </div>

        {/* Magnetic field flux indicator (Crosses / Dots) */}
        <div className="absolute left-4 top-1/2 -translate-y-1/2 flex flex-col gap-1.5 opacity-40">
          {[1, 2, 3].map(i => (
            <div key={i} className="w-5 h-5 rounded-full border border-orange-500/50 flex items-center justify-center text-[8px] text-orange-500 font-mono font-bold">
              ⊗
            </div>
          ))}
          <span className="text-[7px] text-orange-400">Mag. pole (B)</span>
        </div>

        {/* Floating electric arc representation */}
        {isArcBlowing && (
          <div 
            className="absolute left-1/2 -translate-x-1/2 w-[110px] pointer-events-none transition-all duration-75"
            style={{ 
              bottom: `${24 + arcHeight * 0.9}px`,
              height: `${20 + arcHeight * 0.3}px`
            }}
          >
            {/* The arc stretching into a V shape */}
            <svg className="w-full h-full overflow-visible" viewBox="0 0 100 50">
              <path 
                d={`M 10 40 Q 50 ${10 - arcHeight * 0.4} 90 40`} 
                fill="none" 
                stroke={arcHeight > 75 ? "#FF4D4D" : "#FFC14D"} 
                strokeWidth={arcHeight > 75 ? "1.5" : "3.5"} 
                className="animate-pulse"
                strokeDasharray={arcHeight > 75 ? "2 2" : "none"}
              />
              {/* Splitting indicator */}
              {arcHeight > 75 && (
                <text x="32" y="25" fill="#FFC14D" fontSize="7" fontWeight="bold">DĚLENÍ OBLOUKU!</text>
              )}
            </svg>
          </div>
        )}

        {isExtinguished && (
          <div className="absolute inset-0 bg-[#0A0A0B]/85 flex flex-col items-center justify-center text-center p-2 z-10 animate-fadeIn">
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-2 py-0.5 rounded-full">
              UHAŠENO v roštu!
            </span>
            <p className="text-[10px] text-[#7E8085] mt-1 max-w-[200px]">
              Oblouk byl rozdělen na 6 menších segmentů. Celkový úbytek napětí (6 × 20V = 120V) převýšil napětí obvodu a proud zanikl.
            </p>
          </div>
        )}
      </div>

      <div className="space-y-2 mt-2">
        <div className="flex justify-between items-center text-xs">
          <span className="text-[#9BA1A6]">Síla elektromagnetu (B):</span>
          <span className="text-white font-mono">{magneticField} T</span>
        </div>
        <input
          type="range"
          min="0.2"
          max="3.0"
          step="0.1"
          value={magneticField}
          onChange={(e) => setMagneticField(Number(e.target.value))}
          disabled={isArcBlowing}
          className="w-full accent-[#3E63DD] h-1 bg-[#1F1F21] rounded-lg appearance-none cursor-pointer"
        />

        <div className="flex justify-between items-center text-xs">
          <span className="text-[#9BA1A6]">Velikost DC proudu (I):</span>
          <span className="text-white font-mono">{blowoutCurrent} A</span>
        </div>
        <input
          type="range"
          min="10"
          max="300"
          value={blowoutCurrent}
          onChange={(e) => setBlowoutCurrent(Number(e.target.value))}
          disabled={isArcBlowing}
          className="w-full accent-[#3E63DD] h-1 bg-[#1F1F21] rounded-lg appearance-none cursor-pointer"
        />

        <div className="flex justify-between items-center text-[10px] bg-[#0A0A0B] p-2 rounded-lg border border-[#1F1F21] font-mono">
          <span className="text-[#7E8085]">Vypočtená Lorentzova síla (F_L):</span>
          <span className="text-orange-400 font-bold">{lorentzForce.toFixed(1)} N</span>
        </div>

        <button
          onClick={triggerBlowout}
          disabled={isArcBlowing}
          className="w-full py-2 bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white font-bold text-xs rounded-lg shadow-md transition-all active:scale-95 flex items-center justify-center gap-1"
        >
          <Play className="w-4 h-4 fill-current" /> Vypnout stejnosměrnou zátěž (DC)
        </button>
      </div>
    </div>
  );
}

// ==========================================
// MAIN COMPONENT SELECTOR / ROUTER
// ==========================================
interface CompanionVisualProps {
  questionText: string;
}

export function CompanionVisual({ questionText }: CompanionVisualProps) {
  // Categorize based on question text content
  const getCategory = (qText: string): 'theory' | 'safety' | 'sf6' | 'vacuum' | 'magnetic' => {
    const t = qText.toLowerCase();
    if (t.includes('sf6') || t.includes('hexafluorid') || t.includes('puffer') || t.includes('trysk') || t.includes('plyn')) return 'sf6';
    if (t.includes('vakuum') || t.includes('vakuov') || t.includes('vlnovec') || t.includes('amf') || t.includes('keramik') || t.includes('stínění')) return 'vacuum';
    if (t.includes('magnet') || t.includes('lorentz') || t.includes('rošt') || t.includes('deion') || t.includes('plech') || t.includes('cívk') || t.includes('trakč')) return 'magnetic';
    if (t.includes('odpojovač') || t.includes('uzemňovač') || t.includes('bezpečnost') || t.includes('pořadí') || t.includes('blokování') || t.includes('zlaté pravidlo') || t.includes('zatíž') || t.includes('blokován')) return 'safety';
    return 'theory';
  };

  const category = getCategory(questionText);

  switch (category) {
    case 'theory':
      return <ArcTheorySimulator />;
    case 'safety':
      return <DisconnectorSafetySimulator />;
    case 'sf6':
      return <SF6GasSimulator />;
    case 'vacuum':
      return <VacuumAMFSimulator />;
    case 'magnetic':
      return <MagneticBlowoutSimulator />;
    default:
      return <ArcTheorySimulator />;
  }
}
