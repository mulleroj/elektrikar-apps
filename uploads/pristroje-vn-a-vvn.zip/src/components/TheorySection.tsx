import React from 'react';
import { Bolt, ToggleLeft, Power, Skull, Lightbulb, ArrowRight, AlertTriangle } from 'lucide-react';
import { TabId } from '../types';

interface TheorySectionProps {
  onSwitchTab: (tab: TabId) => void;
}

export default function TheorySection({ onSwitchTab }: TheorySectionProps) {
  return (
    <div id="section-intro" className="max-w-5xl mx-auto space-y-8 animate-fadeIn pb-16 md:pb-0">
      
      {/* Hlavní úvodní karta */}
      <div className="bg-[#161618] rounded-2xl p-6 md:p-8 border border-[#1F1F21] shadow-xl">
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-4 border-b border-[#1F1F21] pb-2">
          Proč potřebujeme speciální přístroje pro VN a VVN?
        </h2>
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <p className="text-[#9BA1A6] leading-relaxed text-sm md:text-base">
              Při běžném síťovém napětí (230 V) je přerušení obvodu poměrně snadné – stačí oddálit kontakty vypínače. Avšak na hladinách <strong>Vysokého napětí (VN: 1 kV - 52 kV)</strong> a <strong>Velmi vysokého napětí (VVN: 52 kV - 300 kV)</strong> nastává kritický problém: <span className="text-amber-400 font-semibold">Elektrický oblouk</span>.
            </p>
            <p className="text-[#9BA1A6] leading-relaxed text-sm md:text-base">
              Když se kontakty pod zatížením (nebo při zkratu) začnou oddalovat, zmenšuje se jejich styková plocha, roste přechodový odpor a teplota extrémně stoupne (až desítky tisíc °C). Toto teplo způsobí emisi elektronů a <strong>ionizaci okolního prostředí (vzduchu/plynu)</strong>. Prostředí se stane vodivým a vytvoří se plazmový kanál – elektrický oblouk, kterým proud teče dál, i když jsou kontakty fyzicky rozpojené.
            </p>
            <div className="bg-[#1D1204]/60 border border-amber-500/20 rounded-xl p-4 mt-4">
              <h3 className="text-amber-400 font-bold mb-1 flex items-center gap-2 text-sm md:text-base">
                <AlertTriangle className="w-5 h-5" /> Nebezpečí oblouku
              </h3>
              <ul className="list-disc list-inside text-sm text-amber-200/80 space-y-1">
                <li>Extrémní teplota (ničí kontakty i okolní materiál).</li>
                <li>Tlaková vlna (hrozí exploze přístroje).</li>
                <li>Poškození zraku zářením, riziko požáru.</li>
              </ul>
            </div>
          </div>
          
          <div className="bg-[#111112] rounded-xl p-6 border border-[#1F1F21] flex flex-col items-center justify-center min-h-[300px]">
            <div className="text-center mb-6">
              <span className="text-sm font-mono text-[#9BA1A6] bg-[#0A0A0B] px-3 py-1.5 rounded-lg border border-[#1F1F21]">
                U = L &middot; di/dt
              </span>
              <p className="text-xs text-[#7E8085] mt-2 max-w-xs">
                Indukční zátěž (transformátory, motory) způsobuje při vypnutí přepětí, které znovu zapaluje oblouk.
              </p>
            </div>
            
            {/* Jednoduchá vizualizace oblouku */}
            <div className="relative w-48 h-32 flex items-center justify-between">
              {/* Pevný kontakt */}
              <div className="w-12 h-8 bg-slate-400 rounded-sm border-2 border-slate-300 flex items-center justify-center shadow-md">
                <span className="text-[10px] font-bold text-slate-800">PEVNÝ</span>
              </div>
              
              {/* Blesk/Oblouk s animovaným zářením */}
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-10 flex items-center justify-center">
                <div className="relative w-16 h-12 flex items-center justify-center">
                  {/* Animovaný puls na pozadí blesku */}
                  <div className="absolute inset-0 bg-amber-400/30 rounded-full blur-md animate-pulse"></div>
                  <Bolt className="w-12 h-12 text-amber-400 relative z-10 animate-bounce" />
                </div>
              </div>
              
              {/* Pohyblivý kontakt */}
              <div className="w-12 h-8 bg-slate-400 rounded-sm border-2 border-slate-300 transform translate-x-4 flex items-center justify-center shadow-md">
                <span className="text-[10px] font-bold text-slate-800">POHYB</span>
              </div>
            </div>
            
            <p className="mt-6 text-sm text-center text-[#EDEDEF] font-medium bg-[#161618] px-4 py-2.5 rounded-full border border-[#1F1F21] shadow-inner">
              Základní cíl přístrojů VN/VVN:<br />
              <span className="text-amber-400 font-semibold">Co nejrychleji uhasit (deionizovat) oblouk.</span>
            </p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Odpojovač */}
        <div className="bg-[#161618] rounded-2xl p-6 border border-red-500/20 hover:border-red-500/40 transition-colors relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 bg-red-600 text-white text-xs font-bold px-3 py-1 rounded-bl-xl tracking-wider">
            BEZPEČNOST
          </div>
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-[#1F1F21] flex items-center justify-center text-slate-300 shadow-inner">
                <ToggleLeft className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">Odpojovač</h3>
            </div>
            <p className="text-[#9BA1A6] text-sm mb-4 leading-relaxed">
              Slouží k vytvoření <strong>viditelné izolační vzdálenosti</strong> v obvodu, typicky pro zajištění bezpečnosti při údržbě (např. v rozvodně).
            </p>
          </div>
          <div className="bg-[#1F1111] border border-red-500/20 p-4 rounded-xl shadow-inner">
            <h4 className="text-red-400 font-bold flex items-center gap-2 mb-2 text-sm md:text-base">
              <Skull className="w-5 h-5 text-red-500 animate-pulse" /> Zlaté pravidlo elektrikáře!
            </h4>
            <p className="text-xs md:text-sm text-red-200/90 leading-normal">
              Odpojovač nemá zhášecí zařízení. <strong>NIKDY se nesmí otevírat pod zátěží!</strong> 
              Pokud byste omylem rozpojili odpojovač, kterým protéká proud, vzniklý oblouk na čerstvém vzduchu nezhasne, zničí přístroj a může způsobit smrtelné popáleniny obsluze. Nejprve musí obvod přerušit <em>výkonový vypínač</em>.
            </p>
          </div>
        </div>

        {/* Výkonový vypínač */}
        <div className="bg-[#161618] rounded-2xl p-6 border border-[#1F1F21] hover:border-[#3E63DD]/40 transition-colors flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-[#3E63DD] flex items-center justify-center text-white shadow-[0_0_15px_rgba(62,99,221,0.4)]">
                <Power className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">Výkonový vypínač</h3>
            </div>
            <p className="text-[#9BA1A6] text-sm mb-4 leading-relaxed">
              Hlavní &quot;pracovní&quot; spínací prvek sítě. Je konstruován tak, aby spolehlivě zapnul i vypnul jmenovité proudy a především <strong>bezpečně vypnul extrémní zkratové proudy</strong> (v řádech desítek kA).
            </p>
          </div>
          <div className="bg-[#121B3A]/60 border-l-4 border-[#3E63DD] p-4 rounded-r-xl mt-2">
            <p className="text-sm text-blue-300 mb-2 font-medium">
              Vlastnost:
            </p>
            <p className="text-xs md:text-sm text-[#EDEDEF]/90 leading-normal mb-2">
              Obsahuje robustní kontakty, silný a rychlý pohon (často pružinový nebo střádačový) a především <strong>výkonnou zhášecí komoru</strong>.
            </p>
            <p className="text-xs text-[#7E8085]">
              Vždy se zapíná jako <em>poslední</em> (po odpojovačích) a vypíná jako <em>první</em>.
            </p>
          </div>
        </div>
      </div>
      
      {/* Zajímavost z fyziky */}
      <div className="bg-[#16122C]/40 border border-[#8E4EC6]/20 rounded-2xl p-6 flex gap-4 items-start">
        <div className="bg-[#22173F]/60 p-3 rounded-xl text-[#8E4EC6] shrink-0">
          <Lightbulb className="w-6 h-6" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-[#8E4EC6] mb-1">Zajímavost z fyziky: Jacobův žebřík</h3>
          <p className="text-sm text-[#9BA1A6] leading-relaxed">
            Znáte ze sci-fi filmů tzv. &quot;klouzavý obloukový výboj&quot; (dvě svislé elektrody, mezi kterými stoupá jiskra nahoru)? Tento jev využívá toho, že horká plazma oblouku je lehčí než okolní vzduch, a proto oblouk přirozeně stoupá vzhůru, prodlužuje se, až se nakonec přetrhne. 
            Tento fyzikální princip (spolu s magnetickým foukáním) se historicky využíval v jednoduchých zhášedlech!
          </p>
        </div>
      </div>

      {/* Navigační rozcestník */}
      <div className="text-center mt-8 pb-10">
        <p className="text-[#9BA1A6] mb-6 text-lg font-medium">Prozkoumejte jednotlivé technologie zhášení oblouku pomocí interaktivních simulací:</p>
        <div className="flex justify-center gap-4 flex-wrap">
          <button 
            onClick={() => onSwitchTab('sf6')} 
            className="px-6 py-3 bg-[#161618] hover:bg-[#3E63DD] text-white rounded-xl font-semibold transition-all shadow-md border border-[#1F1F21] hover:border-[#3E63DD]/50 flex items-center gap-2 cursor-pointer active:scale-95"
          >
            Simulace: Vypínač SF6 <ArrowRight className="w-4 h-4" />
          </button>
          <button 
            onClick={() => onSwitchTab('vacuum')} 
            className="px-6 py-3 bg-[#161618] hover:bg-[#3E63DD] text-white rounded-xl font-semibold transition-all shadow-md border border-[#1F1F21] hover:border-[#3E63DD]/50 flex items-center gap-2 cursor-pointer active:scale-95"
          >
            Simulace: Vakuový vypínač <ArrowRight className="w-4 h-4" />
          </button>
          <button 
            onClick={() => onSwitchTab('magnetic')} 
            className="px-6 py-3 bg-[#161618] hover:bg-[#3E63DD] text-white rounded-xl font-semibold transition-all shadow-md border border-[#1F1F21] hover:border-[#3E63DD]/50 flex items-center gap-2 cursor-pointer active:scale-95"
          >
            Simulace: Magnetické vyfukování <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
