import React, { useState } from 'react';
import { GraduationCap, ClipboardList, Play, ArrowRight, RotateCcw, Trophy, ThumbsUp, AlertTriangle, Check, X } from 'lucide-react';
import { Question } from '../types';
import { quizDatabase } from '../quizData';
import { CompanionVisual } from './QuizSimulators';

export default function QuizSection() {
  const [gameState, setGameState] = useState<'start' | 'active' | 'results'>('start');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [selectedAns, setSelectedAns] = useState<number | null>(null);

  // Shuffles questions database and picks 10 random ones
  const startQuiz = () => {
    const shuffled = [...quizDatabase].sort(() => Math.random() - 0.5);
    setQuestions(shuffled.slice(0, 10));
    setCurrentIdx(0);
    setScore(0);
    setSelectedAns(null);
    setGameState('active');
  };

  const selectAnswer = (idx: number) => {
    if (selectedAns !== null) return; // already answered this question
    setSelectedAns(idx);
    if (idx === questions[currentIdx].a) {
      setScore((prev) => prev + 1);
    }
  };

  const handleNext = () => {
    setSelectedAns(null);
    if (currentIdx < 9) {
      setCurrentIdx((prev) => prev + 1);
    } else {
      setGameState('results');
    }
  };

  return (
    <div id="section-quiz" className="max-w-6xl mx-auto animate-fadeIn pb-16 md:pb-0 flex-1 flex flex-col">
      <div className="mb-6">
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-2 flex items-center gap-3">
          <span className="text-emerald-500">
            <GraduationCap className="w-8 h-8" />
          </span>{' '}
          Ověření znalostí
        </h2>
        <p className="text-slate-400 text-sm">
          Otestujte své znalosti o přístrojích VN a VVN. Z rozsáhlé databáze 94 otázek je náhodně vybráno 10 pro každý pokus s interaktivními simulacemi a zobrazením fyzikálních jevů.
        </p>
      </div>

      <div className="bg-[#161618] rounded-2xl p-6 md:p-8 border border-[#1F1F21] shadow-xl flex-1 flex flex-col relative overflow-hidden min-h-[450px]">
        {/* START SCREEN */}
        {gameState === 'start' && (
          <div className="flex-1 flex flex-col items-center justify-center text-center py-6">
            <div className="w-20 h-20 bg-[#1F1F21] rounded-full border border-[#2E2E32] flex items-center justify-center text-emerald-400 mb-6 shadow-inner">
              <ClipboardList className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-3">Připraveni na test?</h3>
            <p className="text-slate-400 mb-8 max-w-md text-sm md:text-base leading-relaxed">
              Čeká vás 10 náhodných otázek s interaktivními pohybovými simulátory pro teorii elektrického oblouku, bezpečnostní pravidla, plyny SF6, vakuové komory a magnetické vypínače.
            </p>
            <button
              onClick={startQuiz}
              className="px-8 py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-lg shadow-[0_0_15px_rgba(16,185,129,0.4)] transition-all hover:scale-105 cursor-pointer active:scale-95 flex items-center gap-2"
            >
              Spustit test <Play className="w-5 h-5 fill-current" />
            </button>
          </div>
        )}

        {/* ACTIVE QUIZ SCREEN */}
        {gameState === 'active' && questions.length > 0 && (
          <div className="flex-1 flex flex-col lg:grid lg:grid-cols-5 gap-6">
            {/* Left Column: Interactive Simulation Companion */}
            <div className="lg:col-span-2 flex flex-col justify-stretch">
              <CompanionVisual questionText={questions[currentIdx].q} />
            </div>

            {/* Right Column: Question & Answers */}
            <div className="lg:col-span-3 flex flex-col justify-between h-full min-h-[380px] border-t lg:border-t-0 lg:border-l border-[#1F1F21] pt-6 lg:pt-0 lg:pl-6">
              <div className="flex flex-col flex-1">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-xs md:text-sm font-bold text-slate-400 uppercase tracking-wider">
                    Otázka {currentIdx + 1} z 10
                  </span>
                  <span className="text-xs md:text-sm font-bold text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-2.5 py-0.5 rounded-full">
                    Skóre: {score}
                  </span>
                </div>
                
                {/* Progress Bar */}
                <div className="w-full bg-[#1F1F21] rounded-full h-2 mb-6 overflow-hidden">
                  <div
                    className="bg-emerald-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${((currentIdx) / 10) * 100}%` }}
                  ></div>
                </div>

                {/* Question Text */}
                <h3 className="text-lg md:text-xl font-semibold text-white mb-6 leading-snug">
                  {questions[currentIdx].q}
                </h3>

                {/* Options */}
                <div className="space-y-3 mb-6 flex-1">
                  {questions[currentIdx].options.map((optionText, idx) => {
                    const isCorrectAnswer = idx === questions[currentIdx].a;
                    const isSelectedAnswer = idx === selectedAns;
                    const hasAnswered = selectedAns !== null;

                    let buttonClass = 'w-full text-left p-4 rounded-lg border transition-all font-medium text-slate-200 flex items-start gap-3 group ';
                    let iconElement = <div className="w-5 h-5 rounded-full border-2 border-slate-600 flex items-center justify-center shrink-0 mt-0.5 group-hover:border-emerald-400 transition-colors"></div>;

                    if (!hasAnswered) {
                      buttonClass += 'bg-[#161618] hover:bg-[#1F1F21] border-[#1F1F21] hover:border-[#2E2E32] cursor-pointer active:scale-[0.99]';
                    } else {
                      buttonClass += 'cursor-default ';
                      if (isCorrectAnswer) {
                        buttonClass += 'bg-emerald-950/40 border-emerald-500 text-emerald-100 font-semibold';
                        iconElement = (
                          <div className="w-5 h-5 rounded-full bg-emerald-500/20 border-2 border-emerald-500 flex items-center justify-center shrink-0 mt-0.5">
                            <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3px]" />
                          </div>
                        );
                      } else if (isSelectedAnswer) {
                        buttonClass += 'bg-red-950/40 border-red-500 text-red-100';
                        iconElement = (
                          <div className="w-5 h-5 rounded-full bg-red-500/20 border-2 border-red-500 flex items-center justify-center shrink-0 mt-0.5">
                            <X className="w-3.5 h-3.5 text-red-400 stroke-[3px]" />
                          </div>
                        );
                      } else {
                        buttonClass += 'bg-[#111112]/50 border-transparent opacity-45';
                      }
                    }

                    return (
                      <button
                        key={idx}
                        onClick={() => selectAnswer(idx)}
                        disabled={hasAnswered}
                        className={buttonClass}
                      >
                        {iconElement}
                        <span className="text-sm md:text-base">{optionText}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Next/Finish Button */}
              <div className="border-t border-[#1F1F21] pt-4 flex justify-end">
                <button
                  onClick={handleNext}
                  disabled={selectedAns === null}
                  className={`px-5 py-2.5 rounded-lg font-bold transition-all flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                    selectedAns === null
                      ? 'bg-[#1F1F21] text-slate-500'
                      : currentIdx === 9
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                      : 'bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_10px_rgba(37,99,235,0.3)]'
                  }`}
                >
                  {currentIdx === 9 ? 'Vyhodnotit test' : 'Další otázka'}{' '}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* RESULTS SCREEN */}
        {gameState === 'results' && (
          <div className="flex-1 flex flex-col items-center justify-center text-center py-6">
            {score >= 9 ? (
              <div className="w-24 h-24 rounded-full flex items-center justify-center text-5xl mb-6 shadow-[0_0_20px_rgba(16,185,129,0.5)] bg-emerald-950/60 text-emerald-400 border border-emerald-500/30">
                <Trophy className="w-12 h-12" />
              </div>
            ) : score >= 6 ? (
              <div className="w-24 h-24 rounded-full flex items-center justify-center text-5xl mb-6 shadow-[0_0_20px_rgba(59,130,246,0.5)] bg-blue-950/60 text-blue-400 border border-blue-500/30">
                <ThumbsUp className="w-12 h-12" />
              </div>
            ) : (
              <div className="w-24 h-24 rounded-full flex items-center justify-center text-5xl mb-6 shadow-[0_0_20px_rgba(239,68,68,0.5)] bg-red-950/60 text-red-400 border border-red-500/30">
                <AlertTriangle className="w-12 h-12 animate-bounce" />
              </div>
            )}

            <h3 className="text-2xl md:text-3xl font-bold text-white mb-2">
              {score >= 9 ? 'Excelentní výkon!' : score >= 6 ? 'Dobrá práce!' : 'Musíš ještě přidat!'}
            </h3>
            
            <p className="text-slate-400 mb-6 text-base md:text-lg">
              Vaše skóre:{' '}
              <strong className={`text-2xl ml-1 ${score >= 9 ? 'text-emerald-400' : score >= 6 ? 'text-blue-400' : 'text-red-400'}`}>
                {score} / 10
              </strong>
            </p>

            <div className="bg-[#111112] border border-[#1F1F21] rounded-xl p-5 mb-8 max-w-md w-full">
              <p className="text-sm text-slate-300 font-medium leading-relaxed">
                {score >= 9
                  ? 'Máš znalosti opravdového experta na vysoké napětí. Plně chápeš rizika i technologie. Skvělá práce!'
                  : score >= 6
                  ? 'Základy ovládáš dobře, ale pro samostatnou práci v rozvodnách by to chtělo ještě trochu dopilovat detaily.'
                  : 'S těmito znalostmi by vstup do rozvodny mohl být extrémně nebezpečný. Projdi si znovu teorii a interaktivní simulace.'}
              </p>
            </div>

            <button
              onClick={startQuiz}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold shadow-md transition-all flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <RotateCcw className="w-4 h-4" /> Spustit nový pokus (Další sada otázek)
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
