export interface Question {
  q: string;
  options: string[];
  a: number; // index of the correct option
}

export type TabId = 'intro' | 'sf6' | 'vacuum' | 'magnetic' | 'quiz';

export interface SimulationState {
  mode: 'open' | 'closed' | 'opening' | 'closing';
  progress: number;
  arcIntensity: number;
  arcType: 'normal' | 'short';
}
