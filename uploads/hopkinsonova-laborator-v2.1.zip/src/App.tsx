/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Settings, 
  Magnet, 
  Zap, 
  Activity, 
  Info, 
  AlertTriangle, 
  Target, 
  Lightbulb, 
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Share2,
  Minimize2,
  X,
  QrCode
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeSVG } from 'qrcode.react';

// --- Types ---

type MaterialKey = 'air' | 'castiron' | 'ferrite' | 'iron' | 'silicon_steel' | 'permalloy' | 'cobalt_iron' | 'mumetal';

interface MaterialDefinition {
  name: string;
  muR: number;
  color: string;
  description: string;
}

// --- Constants ---

const MU0 = 4 * Math.PI * 1e-7;
const CORE_LENGTH = 0.25; // m
const CORE_AREA = 0.0006; // m2

const CHALLENGE_TARGETS = [
  0.05, 0.12, 0.18, 0.24, 0.30, 0.35, 0.42, 0.48, 0.55, 0.61,
  0.68, 0.75, 0.82, 0.88, 0.95, 1.05, 1.12, 1.18, 1.25, 1.32,
  1.40, 1.48, 1.55, 1.62, 1.70, 1.78, 1.85, 1.92, 2.05, 2.15,
  2.25, 2.35, 2.45, 2.55, 2.65, 2.75, 2.85, 2.95, 3.05, 3.15,
  3.25, 3.35, 3.45, 3.55, 3.75, 3.95, 4.15, 4.35, 4.65, 5.00
];

const MATERIALS: Record<MaterialKey, MaterialDefinition> = {
  air: { 
    name: 'Vzduch', 
    muR: 1, 
    color: '#f8fafc',
    description: 'Vysoký magnetický odpor, nízká vodivost toku.'
  },
  castiron: { 
    name: 'Litina', 
    muR: 400, 
    color: '#94a3b8',
    description: 'Běžný materiál pro levnější konstrukce strojů.'
  },
  ferrite: { 
    name: 'Ferit', 
    muR: 1200, 
    color: '#27272a',
    description: 'Keramický magnetický polárně nevodivý materiál.'
  },
  iron: { 
    name: 'Elektro-železo', 
    muR: 2500, 
    color: '#475569',
    description: 'Standardní materiál pro transformátory a motory.'
  },
  silicon_steel: { 
    name: 'Křemík. ocel', 
    muR: 5000, 
    color: '#52627a',
    description: 'Vysoká permeabilita a nízké ztráty pro energetiku.'
  },
  permalloy: { 
    name: 'Permalloy', 
    muR: 8000, 
    color: '#1e293b',
    description: 'Speciální slitina s vysokou magnetickou vodivostí.'
  },
  cobalt_iron: { 
    name: 'Kobalt-železo', 
    muR: 18000, 
    color: '#334155',
    description: 'Materiál s nejvyšší magnetickou indukcí nasycení.'
  },
  mumetal: { 
    name: 'Mumetal', 
    muR: 80000, 
    color: '#0f172a',
    description: 'Extrémně vysoká prostupnost, ideální pro stínění.'
  }
};

export default function App() {
  // --- States ---
  const [current, setCurrent] = useState(2.0);
  const [turns, setTurns] = useState(500);
  const [material, setMaterial] = useState<MaterialKey>('iron');
  const [airGap, setAirGap] = useState(0);
  const [showComparison, setShowComparison] = useState(true);
  const [activeChallenge, setActiveChallenge] = useState<number | null>(null);
  const [score, setScore] = useState<string | null>(null);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  // --- Helpers ---
  const shareUrl = typeof window !== 'undefined' ? window.location.href : '';

  // --- Calculations ---
  const calc = useMemo(() => {
    const muR = MATERIALS[material].muR;
    const Fm = current * turns; // Magnetomotorické napětí (Ampérzávity)
    const Rm_iron = CORE_LENGTH / (MU0 * muR * CORE_AREA);
    const Rm_air = (airGap / 1000) / (MU0 * CORE_AREA);
    const Rm_total = Rm_iron + Rm_air;
    const Phi = Fm / Rm_total; // Magnetický tok (Weber)
    const B = Phi / CORE_AREA; // Magnetická indukce (Tesla)
    
    // Equivalent electrical circuit for comparison (Ohm's Law Analogy)
    // Scaled for visualization purposes
    const U_equiv = Fm / 100; 
    const R_equiv = Rm_total / 1000000;
    const I_equiv = U_equiv / R_equiv;

    // Core Loss Heuristic: Grows with B^2 and permeability
    const coreLoss = (B * B) * (Math.log10(muR) + 1) * 4;

    return { Fm, Rm_total, Phi, B, Rm_iron, Rm_air, U_equiv, R_equiv, I_equiv, coreLoss };
  }, [current, turns, material, airGap]);

  // --- Handlers ---
  const startChallenge = () => {
    const target = CHALLENGE_TARGETS[Math.floor(Math.random() * CHALLENGE_TARGETS.length)];
    setActiveChallenge(target);
    setScore(null);
  };

  const checkChallenge = () => {
    const diff = Math.abs((calc.Phi * 1000) - (activeChallenge || 0));
    if (diff < 0.05) setScore('PERFEKTNÍ!');
    else if (diff < 0.2) setScore('DOBŘE TY!');
    else setScore('Zkus to znovu...');
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#0a0a0c] font-sans text-slate-300">
      {/* Header */}
      <nav className="h-16 bg-[#0d0d10] text-slate-300 px-6 sticky top-0 z-50 shadow-[0_1px_0_0_rgba(255,255,255,0.05)] flex items-center justify-between">
        <div className="max-w-7xl mx-auto w-full flex flex-row justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-600 to-blue-700 flex items-center justify-center shadow-lg shadow-cyan-900/20 ring-1 ring-white/10">
              <Magnet className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-widest text-white uppercase leading-none">Hopkinsonova Laboratoř</h1>
              <p className="text-[10px] text-slate-500 font-mono tracking-tighter mt-1 block uppercase">System v2.1.0 // Magnetic_Reluctance_Sim</p>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="hidden sm:flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-[10px] font-mono text-emerald-500 uppercase">Core_Active</span>
            </div>
            <motion.button 
              whileHover={{ scale: 1.05, backgroundColor: 'rgba(255, 255, 255, 0.08)' }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsShareModalOpen(true)}
              className="p-2 rounded-full border border-white/10 text-white hover:bg-white/5 transition-all backdrop-blur-sm shadow-sm"
              title="Sdílet přes QR kód"
            >
              <QrCode className="w-4 h-4" />
            </motion.button>
            <motion.button 
              whileHover={{ scale: 1.05, backgroundColor: 'rgba(255, 255, 255, 0.08)' }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowComparison(!showComparison)}
              className="px-4 py-1.5 rounded-full border border-white/10 text-[10px] font-bold uppercase tracking-widest hover:bg-white/5 transition-all backdrop-blur-sm shadow-sm"
            >
              {showComparison ? 'Skrýt el. analogii' : 'Srovnat s Ohmem'}
            </motion.button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto w-full p-6 md:p-8 lg:p-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Controls */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          
          {/* CHALLENGE CARD */}
          <motion.section 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-orange-600/20 to-amber-600/10 border border-orange-500/20 rounded-2xl p-5 relative overflow-hidden"
          >
            <div className="relative z-10">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest flex items-center gap-2">
                  <Target className="w-3 h-3" />
                  Aktivní mise
                </span>
                {activeChallenge && (
                  <span className="text-[10px] px-2 py-0.5 bg-orange-500/20 text-orange-300 rounded font-bold uppercase tracking-tighter">Probíhá...</span>
                )}
              </div>
              
              <AnimatePresence mode="wait">
                {activeChallenge ? (
                  <motion.div 
                    key="active"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-4"
                  >
                    <p className="text-xs text-orange-200/70 leading-relaxed">Vyrovnej magnetický obvod pro dosažení toku:</p>
                    <div className="bg-black/40 rounded-xl py-4 text-center border border-orange-500/10 shadow-inner">
                      <span className="text-3xl font-mono font-bold text-orange-400">{activeChallenge}</span>
                      <span className="text-xs text-orange-500 ml-1 font-mono uppercase">mWb</span>
                    </div>
                    <div className="flex gap-2">
                      <motion.button 
                        whileHover={{ scale: 1.02, backgroundColor: '#fb923c' }}
                        whileTap={{ scale: 0.98 }}
                        onClick={checkChallenge} 
                        className="flex-1 py-3 bg-orange-500 text-black font-black text-[10px] uppercase tracking-widest rounded-xl hover:bg-orange-400 transition-all shadow-lg shadow-orange-900/20"
                      >
                        Ověřit konfiguraci
                      </motion.button>
                      <motion.button 
                        whileHover={{ scale: 1.1, backgroundColor: 'rgba(255, 255, 255, 0.1)' }}
                        whileTap={{ scale: 0.9 }}
                         onClick={() => {setActiveChallenge(null); setScore(null);}} 
                        className="bg-white/5 text-orange-400 p-3 rounded-xl border border-white/5 transition-all"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </motion.button>
                    </div>
                    {score && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.9 }} 
                        animate={{ opacity: 1, scale: 1 }}
                        className={`text-center font-bold text-[10px] tracking-widest uppercase p-2 rounded-lg ${score === 'PERFEKTNÍ!' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}
                      >
                        {score}
                      </motion.div>
                    )}
                  </motion.div>
                ) : (
                  <div className="space-y-4">
                    <p className="text-xs text-orange-200/60 leading-relaxed">
                      Dokážete ovládnout reluktanci v praxi?
                    </p>
                    <motion.button 
                      whileHover={{ scale: 1.02, backgroundColor: 'rgba(255, 255, 255, 0.1)' }}
                      whileTap={{ scale: 0.98 }}
                      onClick={startChallenge} 
                      className="w-full py-3 bg-white/5 border border-white/10 text-white font-bold text-[10px] uppercase tracking-widest rounded-xl transition-all"
                    >
                      Zahájit simulaci
                    </motion.button>
                  </div>
                )}
              </AnimatePresence>
            </div>
          </motion.section>

          {/* PARAMETER CONTROLS */}
          <section className="bg-[#111114] border border-white/5 rounded-2xl p-6 flex flex-col gap-6">
            <div className="space-y-4">
              <div className="flex justify-between items-end">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Proud cívky (I)</label>
                <span className="font-mono text-cyan-400 text-sm tracking-tight">{current.toFixed(2)} A</span>
              </div>
              <input 
                type="range" min="0" max="10" step="0.1" 
                value={current} 
                onChange={(e)=>setCurrent(parseFloat(e.target.value))} 
                className="w-full h-1.5 bg-white/5 rounded-lg appearance-none accent-cyan-500 cursor-pointer" 
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-end">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Závity cívky (N)</label>
                <span className="font-mono text-cyan-400 text-sm tracking-tight">{turns} z</span>
              </div>
              <input 
                type="range" min="10" max="2500" step="10" 
                value={turns} 
                onChange={(e)=>setTurns(parseInt(e.target.value))} 
                className="w-full h-1.5 bg-white/5 rounded-lg appearance-none accent-cyan-500 cursor-pointer" 
              />
            </div>

            <div className="pt-4 border-t border-white/5">
              <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500 block mb-3">Materiál společného jádra</label>
              <div className="grid grid-cols-2 gap-2">
                {(Object.entries(MATERIALS) as [MaterialKey, MaterialDefinition][]).map(([id, mat]) => (
                  <motion.button 
                    key={id}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setMaterial(id)}
                    className={`py-2 px-3 rounded-lg border text-[10px] font-bold uppercase tracking-tighter transition-all ${material === id ? 'bg-cyan-500 border-cyan-400 text-black shadow-[0_0_15px_rgba(6,182,212,0.2)]' : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10 hover:border-white/10'}`}
                  >
                    {mat.name}
                  </motion.button>
                ))}
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-white/5">
              <div className="flex justify-between items-end">
                <label className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Vzduchová mezera</label>
                <span className="font-mono text-indigo-400 text-sm tracking-tight">{airGap.toFixed(2)} mm</span>
              </div>
              <input 
                type="range" min="0" max="10" step="0.1" 
                value={airGap} 
                onChange={(e)=>setAirGap(parseFloat(e.target.value))} 
                className="w-full h-1.5 bg-white/5 rounded-lg appearance-none accent-indigo-500 cursor-pointer" 
              />
            </div>
          </section>
        </div>

        {/* Dynamic Visualizations Column */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 flex-1 min-h-[400px]">
            
            {/* MAGNETIC CIRCUIT VISUALIZATION */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-[#111114] border border-white/5 rounded-3xl p-6 flex flex-col items-center justify-between relative overflow-hidden"
            >
              <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-600 mb-4">Topology Simulation</span>
              
              <div className="flex-1 flex items-center justify-center py-4">
                <svg viewBox="0 0 200 200" className="w-48 h-48">
                  {/* Main Core Structure with Material Color */}
                  <motion.rect 
                    x="30" y="30" width="140" height="140" 
                    fill="none" 
                    initial={false}
                    animate={{ 
                      stroke: calc.B > 1.6 ? '#450a0a' : MATERIALS[material].color,
                      strokeWidth: 24,
                      opacity: 1
                    }}
                    transition={{ duration: 0.6, ease: "easeInOut" }}
                    rx="8" 
                  />

                  {/* Permeability "Aura" - Pulsing based on muR (active for muR > 1000) */}
                  <motion.rect 
                    x="30" y="30" width="140" height="140" 
                    fill="none"
                    initial={false}
                    animate={{ 
                      stroke: MATERIALS[material].color,
                      strokeWidth: 24,
                      // Intensity varies with muR (logarithmic scale)
                      opacity: MATERIALS[material].muR > 1 
                        ? [0.05, Math.min(0.6, (Math.log10(MATERIALS[material].muR) / 8) + 0.1), 0.05]
                        : 0,
                      filter: `blur(${Math.max(4, Math.log10(MATERIALS[material].muR) * 3)}px)`
                    }}
                    transition={{ 
                      opacity: {
                        // Speed scales with muR: higher permeability = faster "energy" pulse
                        duration: MATERIALS[material].muR > 1000 
                          ? Math.max(0.8, 4 / (Math.log10(MATERIALS[material].muR) * 0.8))
                          : 4,
                        repeat: Infinity,
                        ease: "easeInOut"
                      },
                      stroke: { duration: 0.6 },
                      filter: { duration: 0.6 }
                    }}
                    rx="8"
                  />

                  {/* Flux Path (Magnetic Flow Lines) */}
                  <motion.rect 
                    x="42" y="42" width="116" height="116" 
                    rx="4" 
                    fill="none" 
                    initial={false}
                    animate={{
                      stroke: calc.B > 1.6 ? '#ef4444' : '#22d3ee',
                      strokeWidth: Math.max(1, Math.min(6, calc.B * 3)),
                      strokeOpacity: Math.max(0.2, Math.min(1, calc.B * 0.7)),
                    }}
                    transition={{ duration: 0.3 }}
                    strokeDasharray="12 8"
                    style={{
                      animation: `dash ${Math.max(0.03, (calc.B > 1.6 ? 1.5 : 5) / (calc.B * 2.5 + 0.1))}s linear infinite`
                    }}
                  />

                  {/* Air Gap Visual Element */}
                  <AnimatePresence>
                    {airGap > 0 && (
                      <motion.rect 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        x="90" y="158" width="20" height="24" fill="#0a0a0c" 
                      />
                    )}
                  </AnimatePresence>
                  
                  {/* Coil Detail */}
                  <g>
                    {[...Array(6)].map((_, i) => (
                      <rect 
                        key={i} 
                        x="18" y={60 + i*13} 
                        width="24" height="6" 
                        rx="1" fill="#92400e" 
                        className="opacity-80"
                      />
                    ))}
                  </g>
                </svg>
              </div>

              <div className="w-full space-y-3 mt-4">
                <div className="flex justify-between items-baseline">
                  <div className="flex flex-col">
                    <span className="text-[10px] text-slate-500 uppercase font-bold tracking-tight">Mag. Tok (Φ)</span>
                    <span className="text-[8px] text-slate-600 font-mono italic">{MATERIALS[material].name} Core</span>
                  </div>
                  <span className="text-2xl font-mono font-bold text-cyan-400">{(calc.Phi * 1000).toFixed(3)} <span className="text-[10px] text-cyan-700">mWb</span></span>
                </div>
                <div className="h-1 bg-white/5 w-full rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(100, calc.B * 50)}%` }}
                    className={`h-full rounded-full ${calc.B > 1.6 ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]' : 'bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.5)]'}`}
                  />
                </div>
              </div>
            </motion.div>

            {/* ELECTRICAL ANALOGY */}
            <AnimatePresence>
              {showComparison && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="bg-black border border-white/5 rounded-3xl p-6 flex flex-col items-center justify-between"
                >
                  <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-600 mb-4">Electrical Analogy</span>
                  
                  <div className="flex-1 flex items-center justify-center py-4">
                    <svg viewBox="0 0 200 200" className="w-48 h-48">
                      <rect x="40" y="40" width="120" height="120" fill="none" stroke="#1e1e24" strokeWidth="2" rx="4" />
                      
                      {/* Voltage Source (U) */}
                      <circle cx="40" cy="100" r="14" fill="#000" stroke="#f59e0b" strokeWidth="2" />
                      <text x="36" y="104" fill="#f59e0b" fontSize="11" fontWeight="black">U</text>
                      
                      {/* Resistor (R) */}
                      <g transform="translate(148, 80)">
                        <rect width="24" height="40" fill="#000" stroke="#6366f1" strokeWidth="2" rx="2" />
                        <text x="5" y="24" fill="#6366f1" fontSize="10" fontWeight="black" textAnchor="start" className="translate-x-1 underline">R</text>
                      </g>
                      
                      {/* Analogy Flow (Amber Dash) */}
                      <motion.rect 
                        x="40" y="40" width="120" height="120" 
                        rx="4"
                        fill="none" 
                        stroke="#f59e0b" 
                        strokeWidth="1.5" 
                        strokeDasharray="2 12"
                        className="opacity-60"
                        style={{
                          animation: `dash ${Math.max(0.1, 5 / (calc.I_equiv * 1.5 || 1))}s linear infinite`
                        }}
                      />
                    </svg>
                  </div>

                  <div className="w-full space-y-3 mt-4">
                    <div className="flex justify-between items-baseline">
                      <span className="text-[10px] text-slate-500 uppercase font-bold tracking-tight">Proud (I_equiv)</span>
                      <span className="text-2xl font-mono font-bold text-amber-500">{(calc.I_equiv * 10).toFixed(1)} <span className="text-[10px] text-amber-700">mA</span></span>
                    </div>
                    <p className="text-[9px] text-slate-700 uppercase font-bold tracking-widest text-center">Analogous to magnetic flux behavior</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* METRIC GRID */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Mag. Napětí (Fm)', value: calc.Fm.toFixed(1), unit: 'A', accent: 'text-white' },
              { label: 'Odpor (Rm)', value: (calc.Rm_total / 1000).toFixed(1), unit: 'kA/Wb', accent: 'text-white' },
              { label: 'Indukce (B)', value: calc.B.toFixed(2), unit: 'T', accent: calc.B > 1.6 ? 'text-red-400' : 'text-white' },
              { label: 'Čistý Výstup (Φ)', value: (calc.Phi * 1000).toFixed(3), unit: 'mWb', accent: 'text-emerald-400', surface: 'bg-emerald-950/20 border-emerald-500/20 shadow-emerald-900/10 shadow-lg' }
            ].map((metric, i) => (
              <motion.div 
                key={i} 
                whileHover={{ y: -4, backgroundColor: metric.surface ? undefined : '#16161a' }}
                className={`${metric.surface || 'bg-[#111114] border border-white/5'} rounded-2xl p-4 flex flex-col justify-between h-24 transition-colors cursor-default`}
              >
                <span className={`text-[10px] font-bold uppercase tracking-widest ${metric.surface ? 'text-emerald-500/70' : 'text-slate-500'}`}>{metric.label}</span>
                <div>
                  <span className={`text-xl font-mono font-bold ${metric.accent}`}>{metric.value}</span>
                  <span className={`text-[10px] font-mono ml-1 ${metric.surface ? 'text-emerald-600' : 'text-slate-600'}`}>{metric.unit}</span>
                </div>
              </motion.div>
            ))}
          </div>

          {/* INSIGHT BOX */}
          <div className="flex flex-col gap-4">
            {/* Core Loss Visualization Card */}
            <motion.div 
               initial={{ opacity: 0, y: 10 }}
               animate={{ opacity: 1, y: 0 }}
               className="bg-[#111114] border border-white/5 rounded-2xl p-5"
            >
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-orange-500" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Analýza tepelných ztrát (Core Loss)</span>
                </div>
                <span className={`text-[10px] font-mono font-bold ${calc.coreLoss > 40 ? 'text-orange-500' : 'text-slate-500'}`}>
                  {calc.coreLoss.toFixed(1)} W/kg (est.)
                </span>
              </div>
              <div className="space-y-4">
                <div className="h-2 bg-white/5 w-full rounded-full overflow-hidden flex">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(100, calc.coreLoss * 2)}%` }}
                    className={`h-full rounded-full transition-colors duration-500 ${
                      calc.coreLoss > 60 ? 'bg-red-600' : 
                      calc.coreLoss > 30 ? 'bg-orange-500' : 'bg-amber-400'
                    }`}
                  />
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="flex flex-col">
                    <span className="text-[8px] text-slate-600 uppercase font-black">Hystereze</span>
                    <div className="h-1 bg-white/5 w-full mt-1 overflow-hidden rounded-full">
                       <motion.div animate={{ width: `${Math.min(100, calc.B * 40)}%` }} className="h-full bg-slate-500" />
                    </div>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[8px] text-slate-600 uppercase font-black">Vířivý proud</span>
                    <div className="h-1 bg-white/5 w-full mt-1 overflow-hidden rounded-full">
                       <motion.div animate={{ width: `${Math.min(100, MATERIALS[material].muR / 1000)}%` }} className="h-full bg-slate-600" />
                    </div>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[8px] text-slate-600 uppercase font-black">Tepelný stress</span>
                    <div className="h-1 bg-white/5 w-full mt-1 overflow-hidden rounded-full">
                       <motion.div animate={{ width: `${Math.min(100, calc.coreLoss * 1.5)}%` }} className={`h-full ${calc.coreLoss > 50 ? 'bg-orange-900' : 'bg-slate-700'}`} />
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            <AnimatePresence>
              {calc.B > 1.6 && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="bg-red-500/10 border border-red-500/20 rounded-2xl p-5 flex items-start gap-4 overflow-hidden"
                >
                  <div className="bg-red-500/20 p-2 rounded-lg mt-0.5">
                    <AlertTriangle className="w-4 h-4 text-red-500" />
                  </div>
                  <div>
                    <h4 className="text-[10px] font-bold uppercase text-red-500 tracking-widest mb-1">Systémové Nasycení</h4>
                    <p className="text-xs text-slate-400 leading-relaxed font-medium">
                      Pozor: Jádro dosáhlo limitu sycení. Další zvyšování napětí Fm nepovede k lineárnímu nárůstu toku Φ, ale pouze k tepelným ztrátám.
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <motion.div 
              whileHover={{ y: -2, backgroundColor: 'rgba(59, 130, 246, 0.08)' }}
              className="bg-blue-500/5 border border-blue-500/10 rounded-2xl p-5 flex items-start gap-4 transition-colors"
            >
              <div className="bg-blue-500/20 p-2 rounded-lg mt-0.5">
                <Info className="w-4 h-4 text-blue-400" />
              </div>
              <div>
                <h4 className="text-[10px] font-bold uppercase text-blue-400 tracking-widest mb-1">Laboratory Insight</h4>
                <p className="text-xs text-slate-400 leading-relaxed font-medium">
                  Sledujte, jak i malá 0.2mm vzduchová mezera dramaticky zvyšuje celkovou reluktanci (Rm). V magnetickém obvodu působí mezery jako vysoké sériové odpory v elektronice.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </main>

      {/* Decorative Footer */}
      <footer className="h-10 bg-[#0d0d10] border-t border-white/5 flex items-center px-10">
        <div className="max-w-7xl mx-auto w-full flex justify-between items-center">
          <div className="flex gap-4 opacity-20">
            <div className="h-1 w-12 bg-white rounded-full"></div>
            <div className="h-1 w-24 bg-white rounded-full"></div>
            <div className="h-1 w-8 bg-white rounded-full"></div>
          </div>
          <span className="text-[9px] font-mono text-slate-700 tracking-widest uppercase">Kernel_Process_Normal // 0x55AF</span>
        </div>
      </footer>

      {/* Share Modal */}
      <AnimatePresence>
        {isShareModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsShareModalOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-[#111114] border border-white/10 rounded-[2rem] p-8 max-w-sm w-full relative z-10 shadow-2xl overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-600 to-blue-700" />
              
                  <motion.button 
                    whileHover={{ 
                      scale: 1.05, 
                      borderColor: 'rgba(255, 255, 255, 0.2)',
                      backgroundColor: 'rgba(255, 255, 255, 0.08)'
                    }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setIsShareModalOpen(false)}
                    className="absolute top-4 right-4 text-slate-500 hover:text-white transition-colors p-2 rounded-full"
                  >
                    <X className="w-5 h-5" />
                  </motion.button>

              <div className="text-center space-y-6">
                <div className="space-y-2">
                  <h3 className="text-lg font-bold text-white uppercase tracking-widest">Share Laboratory</h3>
                  <p className="text-xs text-slate-500 font-mono tracking-tighter">Naskenujte QR kód pro sdílení simulace</p>
                </div>

                <div className="bg-white p-4 rounded-3xl inline-block shadow-xl ring-1 ring-white/10">
                  <QRCodeSVG 
                    value={shareUrl} 
                    size={200} 
                    level="H"
                    includeMargin={false}
                    className="rounded-lg"
                  />
                </div>

                <div className="space-y-4">
                  <div className="bg-black/20 p-3 rounded-xl border border-white/5 truncate text-[10px] font-mono text-slate-400">
                    {shareUrl}
                  </div>
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(shareUrl);
                      alert('Odkaz zkopírován do schránky!');
                    }}
                    className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-[10px] uppercase tracking-widest rounded-xl transition-all shadow-lg shadow-cyan-900/20 active:scale-95"
                  >
                    Kopírovat odkaz
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
