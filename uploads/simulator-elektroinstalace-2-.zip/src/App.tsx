import React, { useState } from 'react';
import { motion } from 'motion/react';
import QRCode from 'react-qr-code';
import { QrCode, X, Zap, Activity } from 'lucide-react';

// --- Technické diagramy pro testovací otázky ---
const DiagramTerminals = () => (
  <svg viewBox="0 0 200 100" className="w-full h-32 bg-slate-900 rounded-lg border border-slate-700">
    <rect x="70" y="20" width="60" height="60" rx="4" fill="#1e293b" stroke="#334155" strokeWidth="2" />
    <circle cx={85} cy={35} r="5" fill="#f97316" stroke="#fb923c" strokeWidth="1" />
    <circle cx={115} cy={35} r="5" fill="#f97316" stroke="#fb923c" strokeWidth="1" />
    <circle cx={100} cy={70} r="5" fill="#f97316" stroke="#fb923c" strokeWidth="1" />
    <text x="100" y="92" textAnchor="middle" fontSize="8" className="fill-slate-500 font-black uppercase tracking-widest">Zapojení svorek</text>
  </svg>
);

const DiagramWires = () => (
  <svg viewBox="0 0 200 100" className="w-full h-32 bg-slate-900 rounded-lg border border-slate-700">
    <rect x="40" y="35" width="120" height="30" rx="15" fill="#334155" stroke="#475569" />
    <circle cx="65" cy="50" r="8" fill="#92400e" stroke="#78350f" />
    <circle cx="100" cy="50" r="8" fill="#2563eb" stroke="#1e40af" />
    <circle cx="135" cy="50" r="8" fill="#22c55e" stroke="#166534" />
    <text x="100" y="85" textAnchor="middle" fontSize="8" className="fill-slate-500 font-black uppercase tracking-widest">Průřez kabelu CYKY</text>
  </svg>
);

const DiagramSafety = () => (
  <svg viewBox="0 0 200 100" className="w-full h-32 bg-slate-900 rounded-lg border border-slate-700">
    <line x1="30" y1="30" x2="170" y2="30" stroke="#3b82f6" strokeWidth="2" strokeDasharray="4 2" />
    <line x1="30" y1="50" x2="170" y2="50" stroke="#22c55e" strokeWidth="2" strokeDasharray="4 2" />
    <line x1="30" y1="70" x2="170" y2="70" stroke="#f97316" strokeWidth="2" />
    <rect x={90} y={62} width={20} height={16} rx={2} fill="none" stroke="#ef4444" strokeWidth="2" strokeDasharray="2" className="animate-pulse" />
    <text x="20" y="32" fontSize="10" className="fill-blue-500 font-bold">N</text>
    <text x="18" y="52" fontSize="10" className="fill-green-500 font-bold">PE</text>
    <text x="22" y="72" fontSize="10" className="fill-orange-500 font-bold">L</text>
  </svg>
);

const DiagramStripper = () => (
  <svg viewBox="0 0 200 100" className="w-full h-32 bg-slate-900 rounded-lg border border-slate-700">
    <path d="M50 70 L80 30 L150 30 L150 40 L85 40 L55 80 Z" fill="#ef4444" stroke="#991b1b" strokeWidth="2" />
    <circle cx="120" cy="35" r="6" fill="#64748b" />
    <text x="100" y="90" textAnchor="middle" fontSize="8" className="fill-slate-500 font-black uppercase tracking-widest">Nástroj Jokari</text>
  </svg>
);

const DiagramBreaker = () => (
  <svg viewBox="0 0 200 100" className="w-full h-32 bg-slate-900 rounded-lg border border-slate-700">
    <rect x="85" y="15" width="30" height="70" rx="3" fill="#1e293b" stroke="#475569" strokeWidth="2" />
    <rect x="92" y="35" width="16" height="30" rx="1" fill="#fbbf24" opacity="0.8" />
    <text x="100" y="55" textAnchor="middle" fontSize="10" className="fill-slate-900 font-black">B10</text>
  </svg>
);


const InteractiveCircuit = ({ 
  initialMode = 6, 
  compact = false,
  showLabels = true,
  hideControls = false
}: { 
  initialMode?: number, 
  compact?: boolean,
  showLabels?: boolean,
  key?: any,
  hideControls?: boolean
}) => {
  const [sw1, setSw1] = useState(0);
  const [swMid, setSwMid] = useState(0);
  const [sw2, setSw2] = useState(0);
  const [breaker, setBreaker] = useState(true);
  const circuitMode = initialMode;

  const livePath1 = breaker && sw1 === 0;
  const livePath2 = breaker && sw1 === 1;

  let finalPath1, finalPath2;
  if (circuitMode === 7) {
    finalPath1 = swMid === 0 ? livePath1 : livePath2;
    finalPath2 = swMid === 0 ? livePath2 : livePath1;
  } else {
    finalPath1 = livePath1;
    finalPath2 = livePath2;
  }

  const isLightOn = sw2 === 0 ? finalPath1 : finalPath2;

  const getWireAnim = (isLive: boolean | number, baseColor = THEME.dead) => ({
    animate: {
      stroke: isLive ? [THEME.live, THEME.liveBright, THEME.live] : baseColor,
      strokeWidth: isLive ? [2.5, 3.5, 2.5] : 2,
      strokeDashoffset: isLive ? [0, -24] : 0,
    },
    transition: {
      stroke: { repeat: Infinity, duration: 1.5, ease: "easeInOut" },
      strokeWidth: { repeat: Infinity, duration: 1.5, ease: "easeInOut" },
      strokeDashoffset: { repeat: Infinity, duration: 0.8, ease: "linear" },
    }
  });

  const pathProps = (isLive: boolean | number) => ({
    strokeDasharray: isLive ? "6 6" : "0",
    fill: "none",
    ...getWireAnim(isLive)
  });

  const Terminal = ({ x, y, active }: { x: number, y: number, active?: boolean }) => (
    <circle cx={x} cy={y} r="1.5" className={`${active ? 'fill-orange-400' : 'fill-slate-400'}`} stroke="#1e293b" strokeWidth="0.5" />
  );

  return (
    <div className={`bg-slate-900 rounded-2xl border-4 border-slate-800 shadow-2xl relative overflow-hidden flex flex-col items-center justify-center ${compact ? 'p-3 mt-2' : 'p-6'}`}>
      {/* Circuit Board Texture */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '10px 10px' }}></div>
      
      <div className={`relative w-full ${compact ? 'h-36' : 'h-72'}`}>
        <svg viewBox="0 0 100 80" className="absolute inset-0 w-full h-full">
          {/* Legend / Title Overlay */}
          {!compact && (
            <text x="2" y="5" fontSize="2.5" className="fill-slate-500 font-bold tracking-widest uppercase">Technické schéma: Řazení {circuitMode}</text>
          )}

          {/* Neutral and PE base lines (Educational Context) */}
          <line x1="5" y1="10" x2="95" y2="10" stroke="#3b82f6" strokeWidth="0.8" strokeDasharray="2 2" className="opacity-30" />
          <text x="2" y="11" fontSize="2" className="fill-blue-500 opacity-50">N (Nula)</text>
          
          <line x1="5" y1="70" x2="95" y2="70" stroke="#22c55e" strokeWidth="0.8" strokeDasharray="2 2" className="opacity-30" />
          <text x="2" y="71" fontSize="2" className="fill-green-500 opacity-50">PE (Ochranný)</text>

          {/* Phase Line (L) */}
          <text x="2" y="41" fontSize="2" className="fill-orange-500 opacity-70">L (Fáze)</text>
          
          {/* Supply to Breaker */}
          <motion.line x1="5" y1="40" x2="15" y2="40" {...pathProps(breaker)} />
          <Terminal x={15} y={40} active={breaker} />
          
          {/* Breaker to Switch 1 */}
          <motion.path d="M 15 40 L 22 40" {...pathProps(breaker)} />
          <Terminal x={22} y={40} active={breaker} />

          {/* Switch 1 Diagram */}
          <g transform="translate(22, 40)">
             {/* Common Terminal */}
             <Terminal x={0} y={0} active={breaker} />
             {/* Arm 1 */}
             <motion.line 
                x1={0} y1={0} 
                animate={{ 
                  x2: 13, 
                  y2: sw1 === 0 ? -12 : 12,
                  stroke: breaker ? THEME.live : THEME.dead,
                  strokeWidth: breaker ? 3 : 2
                }} 
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
             />
             {/* Outputs */}
             <Terminal x={13} y={-12} active={livePath1} />
             <Terminal x={13} y={12} active={livePath2} />
          </g>

          {/* Transverse Wires (Korespondenční) */}
          <motion.path d="M 35 28 L 45 28" {...pathProps(livePath1)} />
          <motion.path d="M 35 52 L 45 52" {...pathProps(livePath2)} />

          {circuitMode === 6 ? (
            <>
              <motion.path d="M 35 28 L 65 28" {...pathProps(livePath1)} />
              <motion.path d="M 35 52 L 65 52" {...pathProps(livePath2)} />
            </>
          ) : (
            /* Cross Switch (Sch 7) visualization */
            <g transform="translate(45, 28)">
               <Terminal x={0} y={0} active={livePath1} />
               <Terminal x={0} y={24} active={livePath2} />
               {/* Internal Crossing mechanism */}
               <motion.line 
                  x1={0} y1={0} 
                  animate={{ 
                    x2: 12, y2: swMid === 0 ? 0 : 24,
                    stroke: livePath1 ? THEME.live : THEME.dead,
                    strokeWidth: livePath1 ? 3 : 2
                  }} 
                  transition={{ type: "spring", stiffness: 200, damping: 15 }}
               />
               <motion.line 
                  x1={0} y1={24} 
                  animate={{ 
                    x2: 12, y2: swMid === 0 ? 24 : 0,
                    stroke: livePath2 ? THEME.live : THEME.dead,
                    strokeWidth: livePath2 ? 3 : 2
                  }} 
                  transition={{ type: "spring", stiffness: 200, damping: 15 }}
               />
               <Terminal x={12} y={0} active={finalPath1} />
               <Terminal x={12} y={24} active={finalPath2} />
               {/* Connections to next switch */}
               <motion.path d="M 12 0 L 20 0" {...pathProps(finalPath1)} />
               <motion.path d="M 12 24 L 20 24" {...pathProps(finalPath2)} />
            </g>
          )}

          {/* Switch 2 Diagram */}
          <g transform="translate(65, 28)">
             <Terminal x={0} y={0} active={finalPath1} />
             <Terminal x={0} y={24} active={finalPath2} />
             {/* Common Terminal of SW2 */}
             <Terminal x={13} y={12} active={isLightOn} />
             {/* Arm 2 */}
             <motion.line 
                x1={13} y1={12} 
                animate={{ 
                  x2: 0, 
                  y2: sw2 === 0 ? 0 : 24,
                  stroke: isLightOn ? THEME.live : THEME.dead,
                  strokeWidth: isLightOn ? 3 : 2
                }} 
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
             />
             {/* Switch output to Light */}
             <motion.path d="M 13 12 L 20 12" {...pathProps(isLightOn)} />
          </g>

          {/* Final Lead to Light */}
          <motion.line x1="85" y1="40" x2="90" y2="40" {...pathProps(isLightOn)} />
          
          {/* Light Bulb - Technical Symbol CROSS */}
          <g transform="translate(90, 40)">
            <motion.circle 
              r="4" 
              className="stroke-slate-600 fill-slate-800" 
              strokeWidth="0.8"
              animate={{ 
                stroke: isLightOn ? "#facc15" : "#475569",
                fill: isLightOn ? "#422006" : "#1e293b" 
              }}
            />
            {/* The X symbol inside */}
            <motion.path 
              d="M -2.5 -2.5 L 2.5 2.5 M -2.5 2.5 L 2.5 -2.5" 
              strokeWidth="0.8"
              animate={{ stroke: isLightOn ? "#facc15" : "#475569" }}
            />
            {/* Light glow effect */}
            {isLightOn && (
              <motion.circle 
                r="8" 
                className="fill-yellow-400 opacity-20 blur-md pointer-events-none"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 2 }}
              />
            )}
          </g>

          {showLabels && (
            <g className="font-bold tracking-tight opacity-40 uppercase">
              <text x="8" y="38" fontSize="2" className="fill-slate-500">Přívod</text>
              <text x="35" y="25" fontSize="2" className="fill-slate-500" textAnchor="middle">Korespond. A</text>
              <text x="35" y="58" fontSize="2" className="fill-slate-500" textAnchor="middle">Korespond. B</text>
              <text x="88" y="35" fontSize="2" className="fill-slate-500" textAnchor="middle">Zátěž</text>
            </g>
          )}
        </svg>

        {/* UI Controls overlay */}
        {!hideControls && (
          <div className="flex items-center justify-around w-full z-10 absolute bottom-0 left-0 p-2 bg-slate-900/60 backdrop-blur-sm rounded-b-xl border-t border-slate-700">
            <div className="flex flex-col items-center gap-1">
              <BreakerSwitch state={breaker} onChange={() => setBreaker(!breaker)} />
              <span className="text-[7px] font-black text-slate-500 uppercase">Jistič (Q)</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <RockerSwitch state={sw1} onChange={() => setSw1(sw1 === 0 ? 1 : 0)} />
              <span className="text-[7px] font-black text-slate-500 uppercase tracking-tighter">VYP 1 (Sch. 6)</span>
            </div>
            {circuitMode === 7 && (
              <div className="flex flex-col items-center gap-1">
                <RockerSwitch state={swMid} onChange={() => setSwMid(swMid === 0 ? 1 : 0)} isCross />
                <span className="text-[7px] font-black text-blue-500 uppercase tracking-tighter">VYP 2 (Sch. 7)</span>
              </div>
            )}
            <div className="flex flex-col items-center gap-1">
              <RockerSwitch state={sw2} onChange={() => setSw2(sw2 === 0 ? 1 : 0)} />
              <span className="text-[7px] font-black text-slate-500 uppercase tracking-tighter">VYP {circuitMode === 7 ? '3' : '2'} (Sch. 6)</span>
            </div>
            <div className="flex flex-col items-center gap-1 group">
              <div className="relative">
                <IconLight on={isLightOn} />
                {isLightOn && <motion.div 
                  className="absolute inset-0 bg-yellow-400 blur-xl rounded-full opacity-20 pointer-events-none"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                />}
              </div>
              <span className={`text-[7px] font-black uppercase transition-colors ${isLightOn ? 'text-yellow-500' : 'text-slate-500'}`}>Žárovka (E)</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// --- UI Ikony ---
const IconLight = ({ on }: { on: boolean }) => (
  <svg width="48" height="48" viewBox="0 0 24 24" fill={on ? "#facc15" : "none"} stroke={on ? "#854d0e" : "#94a3b8"} strokeWidth="2">
    <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A5 5 0 0 0 8 8c0 1.3.5 2.6 1.5 3.5.8.8 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/>
  </svg>
);

const RockerSwitch = ({ state, onChange, isCross = false }: { state: number, onChange: () => void, isCross?: boolean }) => {
  return (
    <motion.button
      onClick={onChange}
      className={`w-10 h-14 rounded-md shadow-inner flex items-center justify-center p-1 transition-all duration-300 ${
        isCross 
          ? (state === 1 ? 'bg-blue-400 ring-2 ring-blue-300 ring-offset-1' : 'bg-blue-200') 
          : (state === 1 ? 'bg-slate-400 ring-2 ring-slate-300 ring-offset-1' : 'bg-slate-200')
      }`}
      whileTap={{ scale: 0.9 }}
      style={{ perspective: 300 }}
    >
      <motion.div
        className={`w-full h-full rounded shadow-md border transition-colors duration-300 ${
          isCross 
            ? (state === 1 ? 'bg-blue-100 border-blue-400' : 'bg-blue-50 border-blue-300') 
            : (state === 1 ? 'bg-slate-50 border-slate-400' : 'bg-white border-slate-300')
        }`}
        animate={{
          rotateX: state === 0 ? 35 : -35,
          y: state === 0 ? -2 : 2,
          boxShadow: state === 0 
            ? "0px 4px 2px -1px rgba(0,0,0,0.3), inset 0px -2px 4px rgba(0,0,0,0.1)" 
            : "0px -4px 2px -1px rgba(0,0,0,0.3), inset 0px 2px 4px rgba(0,0,0,0.1)"
        }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
        style={{ transformStyle: "preserve-3d" }}
      >
        <div className={`w-full h-full flex flex-col justify-between py-1.5 items-center transition-colors duration-300 ${
          isCross 
            ? (state === 1 ? 'text-blue-600' : 'text-blue-400') 
            : (state === 1 ? 'text-slate-600' : 'text-slate-300')
        }`}>
           <div className="w-3 h-0.5 bg-current rounded-full"></div>
           <div className="w-3 h-0.5 bg-current rounded-full"></div>
        </div>
      </motion.div>
    </motion.button>
  );
};

const BreakerSwitch = ({ state, onChange }: { state: boolean, onChange: () => void }) => {
  return (
    <motion.button
      onClick={onChange}
      className={`w-10 h-10 rounded-lg border-2 flex items-center justify-center shadow-inner transition-all duration-300 ${
        state 
          ? 'bg-green-600 border-green-700 ring-4 ring-green-500/30' 
          : 'bg-red-600 border-red-700'
      }`}
      whileTap={{ scale: 0.9 }}
      style={{ perspective: 300 }}
    >
      <motion.div
        className="w-4 h-6 bg-slate-100 rounded shadow-md border border-slate-300"
        animate={{
          rotateX: state ? 35 : -35,
          y: state ? -2 : 2,
          boxShadow: state 
            ? "0px 3px 2px -1px rgba(0,0,0,0.4), inset 0px -1px 2px rgba(0,0,0,0.2)" 
            : "0px -3px 2px -1px rgba(0,0,0,0.4), inset 0px 1px 2px rgba(0,0,0,0.2)"
        }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
        style={{ transformStyle: "preserve-3d" }}
      />
    </motion.button>
  );
};

// --- Téma barev pro celou aplikaci ---
const THEME = {
  live: "#f97316",
  liveBright: "#fdba74",
  dead: "#334155",
  neutral: "#3b82f6",
  earth: "#22c55e",
};

// --- Měřicí přístroje ---
const MeasurementWorkbench = ({ circuitMode }: { circuitMode: number }) => {
  const [selectedTool, setSelectedTool] = useState<'tester' | 'multimeter' | null>('tester');
  const [sw1, setSw1] = useState(0);
  const [swMid, setSwMid] = useState(0);
  const [sw2, setSw2] = useState(0);
  const [breaker, setBreaker] = useState(true);
  const [hoveredNode, setHoveredNode] = useState<{ id: string, live: boolean, label: string, x: number, y: number } | null>(null);

  const livePath1 = breaker && sw1 === 0;
  const livePath2 = breaker && sw1 === 1;

  let finalPath1, finalPath2;
  if (circuitMode === 7) {
    finalPath1 = swMid === 0 ? livePath1 : livePath2;
    finalPath2 = swMid === 0 ? livePath2 : livePath1;
  } else {
    finalPath1 = livePath1;
    finalPath2 = livePath2;
  }

  const isLightOn = sw2 === 0 ? finalPath1 : finalPath2;

  // Definice měřicích bodů na nové mřížce 100x80
  const nodes = [
    { id: 'L_IN', x: 10, y: 40, live: breaker, label: 'Přívod fázový' },
    { id: 'SW1_IN', x: 22, y: 40, live: breaker, label: 'Vstup přepínače 1' },
    { id: 'KOR1_UP', x: 35, y: 28, live: livePath1, label: 'Korespondenční A' },
    { id: 'KOR1_DOWN', x: 35, y: 52, live: livePath2, label: 'Korespondenční B' },
    { id: 'SW2_IN_UP', x: 65, y: 28, live: finalPath1, label: 'Vstup přepínače 2/A' },
    { id: 'SW2_IN_DOWN', x: 65, y: 52, live: finalPath2, label: 'Vstup přepínače 2/B' },
    { id: 'SW2_OUT', x: 78, y: 40, live: isLightOn, label: 'Výstup přepínače 2' },
    { id: 'LIGHT_L', x: 90, y: 40, live: isLightOn, label: 'Přívod svítidla' },
  ];

  const getWireAnim = (isLive: boolean | number, baseColor = THEME.dead) => ({
    animate: {
      stroke: isLive ? [THEME.live, THEME.liveBright, THEME.live] : baseColor,
      strokeWidth: isLive ? [2.5, 3.5, 2.5] : 2,
      strokeDashoffset: isLive ? [0, -30] : 0,
    },
    transition: {
      stroke: { repeat: Infinity, duration: 1.5, ease: "easeInOut" },
      strokeWidth: { repeat: Infinity, duration: 1.5, ease: "easeInOut" },
      strokeDashoffset: { repeat: Infinity, duration: 0.6, ease: "linear" },
    }
  });

  const pathProps = (isLive: boolean | number) => ({
    strokeDasharray: isLive ? "8 8" : "0",
    fill: "none",
    ...getWireAnim(isLive)
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-center gap-4">
        <button 
          onClick={() => setSelectedTool('tester')}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${selectedTool === 'tester' ? 'bg-orange-500 text-white shadow-lg scale-105' : 'bg-white text-slate-600 border border-slate-200 shadow-sm'}`}
        >
          <Zap size={18} /> Zkoušečka (Fázovka)
        </button>
        <button 
          onClick={() => setSelectedTool('multimeter')}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${selectedTool === 'multimeter' ? 'bg-blue-600 text-white shadow-lg scale-105' : 'bg-white text-slate-600 border border-slate-200 shadow-sm'}`}
        >
          <Activity size={18} /> Multimetr
        </button>
      </div>

      <div className="relative bg-slate-900 rounded-2xl border-4 border-slate-800 p-8 cursor-crosshair overflow-hidden group shadow-2xl">
        <div className="absolute top-4 left-4 bg-slate-800/80 backdrop-blur-sm px-4 py-1.5 rounded-full border border-slate-700 text-[10px] font-black text-slate-300 uppercase tracking-[0.2em] z-10 flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full animate-pulse ${selectedTool === 'tester' ? 'bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]' : 'bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.8)]'}`} />
          {selectedTool === 'tester' ? 'Zjišťování fáze' : 'Měření napětí (U)'}
        </div>

        <div className="relative w-full h-80">
          <svg viewBox="0 0 100 80" className="absolute inset-0 w-full h-full pointer-events-none">
            {/* Background Texture */}
            <defs>
              <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                <circle cx="1" cy="1" r="1" fill="rgba(255,255,255,0.05)" />
              </pattern>
            </defs>
            <rect width="100" height="80" fill="url(#grid)" />

            {/* Static Lines */}
            <line x1="5" y1="10" x2="95" y2="10" stroke="#3b82f6" strokeWidth="0.5" strokeDasharray="1 1" className="opacity-20" />
            <line x1="5" y1="70" x2="95" y2="70" stroke="#22c55e" strokeWidth="0.5" strokeDasharray="1 1" className="opacity-20" />

            {/* Circuit Paths */}
            <motion.line x1="5" y1="40" x2="15" y2="40" {...pathProps(breaker)} />
            <motion.path d="M 15 40 L 22 40" {...pathProps(breaker)} />
            
            {/* SW1 Arm logic for visual consistency */}
            <motion.path d="M 22 40 L 35 28" {...pathProps(livePath1)} animate={{ opacity: sw1 === 0 ? 1 : 0.3 }} />
            <motion.path d="M 22 40 L 35 52" {...pathProps(livePath2)} animate={{ opacity: sw1 === 1 ? 1 : 0.3 }} />
            
            {circuitMode === 6 ? (
              <>
                <motion.path d="M 35 28 L 65 28" {...pathProps(livePath1)} />
                <motion.path d="M 35 52 L 65 52" {...pathProps(livePath2)} />
              </>
            ) : (
              /* Simplified Sch 7 for measurement visualization */
              <>
                <motion.path 
                  d={swMid === 0 ? "M 35 28 L 65 28" : "M 35 28 L 65 52"} 
                  {...pathProps(livePath1)} 
                  transition={{ duration: 0.3 }}
                />
                <motion.path 
                  d={swMid === 0 ? "M 35 52 L 65 52" : "M 35 52 L 65 28"} 
                  {...pathProps(livePath2)} 
                  transition={{ duration: 0.3 }}
                />
              </>
            )}

            <motion.path d="M 65 28 L 78 40" {...pathProps(finalPath1)} animate={{ opacity: sw2 === 0 ? 1 : 0.3 }} />
            <motion.path d="M 65 52 L 78 40" {...pathProps(finalPath2)} animate={{ opacity: sw2 === 1 ? 1 : 0.3 }} />
            <motion.line x1="78" y1="40" x2="90" y2="40" {...pathProps(isLightOn)} />

            {/* Interactive Nodes */}
            {nodes.map(node => (
              <g key={node.id} onMouseEnter={() => setHoveredNode(node)} onMouseLeave={() => setHoveredNode(null)} className="pointer-events-auto">
                <circle 
                  cx={node.x} cy={node.y} r="1.5" 
                  className={`transition-all duration-300 ${hoveredNode?.id === node.id ? 'fill-blue-400 r-3 filter blur-[1px]' : 'fill-slate-700 opacity-60 hover:fill-blue-500 hover:opacity-100'}`} 
                />
                <circle cx={node.x} cy={node.y} r="6" fill="transparent" />
              </g>
            ))}
          </svg>

          {/* Controls */}
          <div className="flex items-center justify-around w-full z-1 absolute bottom-0 left-0 p-2 bg-slate-900/60 backdrop-blur-sm rounded-b-xl border-t border-slate-700">
            <BreakerSwitch state={breaker} onChange={() => setBreaker(!breaker)} />
            <RockerSwitch state={sw1} onChange={() => setSw1(sw1 === 0 ? 1 : 0)} />
            {circuitMode === 7 && <RockerSwitch state={swMid} onChange={() => setSwMid(swMid === 0 ? 1 : 0)} isCross />}
            <RockerSwitch state={sw2} onChange={() => setSw2(sw2 === 0 ? 1 : 0)} />
            <IconLight on={isLightOn} />
          </div>

          {/* Tool Visualization */}
          {hoveredNode && (
            <motion.div 
              className="absolute pointer-events-none z-20 flex flex-col items-center"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1, left: `${hoveredNode.x}%`, top: `${hoveredNode.y}%` }}
              style={{ transform: 'translate(-50%, -100%)' }}
            >
              {selectedTool === 'tester' ? (
                <div className="flex flex-col items-center filter drop-shadow-[0_0_10px_rgba(0,0,0,0.5)]">
                  <div className={`w-4 h-16 rounded-t-lg border-x-4 border-t-4 border-slate-600 relative overflow-hidden ${hoveredNode.live ? 'bg-orange-400 shadow-[0_0_20px_rgba(249,115,22,1)]' : 'bg-slate-300'}`}>
                    {hoveredNode.live && <motion.div animate={{ opacity: [0.3, 0.8, 0.3] }} transition={{ repeat: Infinity, duration: 0.5 }} className="absolute inset-0 bg-white" />}
                  </div>
                  <div className="w-1.5 h-10 bg-slate-400 rounded-b-full -mt-0.5" />
                </div>
              ) : (
                <div className="bg-slate-800 text-white px-4 py-3 rounded-2xl border-2 border-blue-500 shadow-2xl flex flex-col items-center min-w-[100px]">
                  <div className="flex gap-1 mb-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                  </div>
                  <span className="text-[9px] text-blue-400 font-black uppercase mb-1 tracking-tighter">Napětí AC (Phase - N)</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-mono font-black text-white">{hoveredNode.live ? '230' : '0'}</span>
                    <span className="text-xs text-slate-400 font-bold">V</span>
                  </div>
                </div>
              )}
              <div className="mt-4 bg-slate-800 px-4 py-1.5 rounded-full border border-slate-700 shadow-lg text-[9px] font-black text-slate-200 uppercase tracking-widest whitespace-nowrap">
                {hoveredNode.label}
              </div>
            </motion.div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 shadow-lg group hover:border-orange-500/50 transition-colors">
          <h4 className="text-xs font-black text-orange-500 flex items-center gap-2 mb-3 uppercase tracking-widest">
             <div className="w-2 h-2 rounded-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]" />
             Zkoušečka (Doutnavka)
          </h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Hledá přítomnost <strong>fáze (napětí)</strong>. Pokud svítí, je vodič pod napětím. U nulového vodiče (N) nebo u vypnutého okruhu nezměří nic.
          </p>
        </div>
        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 shadow-lg group hover:border-blue-500/50 transition-colors">
          <h4 className="text-xs font-black text-blue-500 flex items-center gap-2 mb-3 uppercase tracking-widest">
             <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
             Multimetr (V-metr)
          </h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Měří přesnou hodnotu napětí v obvodu. V simulaci měříme rozdíl mezi fází a nulovým bodem (referenční 0V).
          </p>
        </div>
      </div>
    </div>
  );
};

const ALL_QUESTIONS = [
  { text: "Kolik připojovacích svorek má standardní křížový přepínač (Řazení 7)?", diagram: <InteractiveCircuit initialMode={7} compact showLabels={false} hideControls />, options: ["2 svorky", "3 svorky", "4 svorky", "5 svorek"], correct: 2, explanation: "Křížový přepínač má 4 svorky – dva páry pro korespondenční vodiče." },
  { text: "Jakou barvu má podle normy nulový vodič (N)?", diagram: <DiagramWires />, options: ["Zelenožlutá", "Hnědá", "Černá", "Světle modrá"], correct: 3, explanation: "Nulový vodič (N) je v domovních instalacích vždy světle modrý." },
  { text: "Které řazení vypínačů je zobrazeno na schématu ovládání ze dvou míst?", diagram: <InteractiveCircuit initialMode={6} compact showLabels={false} hideControls />, options: ["2x řazení 1", "2x řazení 6", "1x řazení 6 a 1x řazení 7", "2x řazení 5"], correct: 1, explanation: "Pro dvě místa se používají dva střídavé přepínače (řazení 6)." },
  { text: "Který vodič na schématu smí být přerušen vypínačem?", diagram: <DiagramSafety />, options: ["Modrý (N)", "Zelenožlutý (PE)", "Hnědý/Oranžový (L)", "Všechny tři"], correct: 2, explanation: "Vypínačem se vždy přerušuje pouze fáze (L). N a PE nesmí být nikdy přerušeny!" },
  { text: "Jaký nástroj je nejvhodnější pro bezpečné odpláštění kabelu CYKY?", diagram: <DiagramStripper />, options: ["Kuchyňský nůž", "Kombinované kleště", "Nože na kabely (Jokari)", "Plochý šroubovák"], correct: 2, explanation: "Nože na kabely umožňují nastavit hloubku řezu bez poškození izolace žil." },
  { text: "Jakou jmenovitou hodnotu jističe B zvolíte pro světelný okruh 1.5 mm²?", diagram: <DiagramBreaker />, options: ["B 6A", "B 10A", "B 16A", "B 20A"], correct: 1, explanation: "Pro světelné okruhy s průřezem 1.5 mm² se standardně používá jistič 10A." },
  { text: "Kde se u střídavého přepínače zapojuje přívodní fáze?", diagram: <InteractiveCircuit initialMode={6} compact showLabels={false} hideControls />, options: ["Na libovolnou svorku", "Na společnou svorku (L)", "Na korespondenční svorku", "Nikam"], correct: 1, explanation: "Přívodní fáze musí být na společné svorce (označené L nebo šipkou)." },
  { text: "Může být křížový vypínač (řazení 7) použit jako první v řadě?", diagram: <InteractiveCircuit initialMode={7} compact showLabels={false} hideControls />, options: ["Ano", "Ne, musí být mezi řazením 6", "Ano, ale světlo bude blikat", "Jen v průmyslu"], correct: 1, explanation: "Křížový vypínač se vkládá vždy mezi dva střídavé přepínače (řazení 6)." },
  { text: "Jak se nazývají vodiče propojující dva přepínače řazení 6?", diagram: <InteractiveCircuit initialMode={6} compact showLabels={false} hideControls />, options: ["Hlavní přívody", "Nulové vodiče", "Korespondenční vodiče", "Zemnící vodiče"], correct: 2, explanation: "Vodiče přenášející fázi mezi vypínači jsou korespondenční vodiče." },
  { text: "Co znamená barevné značení Zelenožlutá?", diagram: <DiagramWires />, options: ["Fázový vodič", "Nulový vodič", "Ochranný vodič (PE)", "Signální vodič"], correct: 2, explanation: "Zelenožlutá barva je vyhrazena výhradně pro ochranný vodič PE." },
  { text: "Jaký je minimální průřez měděného jádra pro zásuvkový okruh?", options: ["1.5 mm²", "2.5 mm²", "4.0 mm²", "1.0 mm²"], correct: 1, explanation: "Zásuvkové okruhy v bytech vyžadují minimální průřez 2.5 mm² Cu." },
  { text: "Co znamená označení jističe 'charakteristika B'?", options: ["Pro motory", "Pro běžné světelné okruhy", "Pro citlivou elektroniku", "Pro topení"], correct: 1, explanation: "B je standardní charakteristika pro vedení s nízkými proudovými rázy (světla, zásuvky)." },
  { text: "Jak vysoký stupeň krytí je vyžadován v zóně 1 v koupelně?", options: ["IP20", "IP44", "IPx5", "IPx7"], correct: 2, explanation: "V zóně 1 (nad vanou/sprchou) je vyžadováno krytí alespoň IPx5." },
  { text: "Může se do jedné krabice umístit zásuvka i vypínač řazení 1?", options: ["Ano, pokud jsou na stejném okruhu", "Ne, nikdy", "Pouze v garáži", "Ano, ale musí mít jinou barvu"], correct: 0, explanation: "Ano, je to běžné (tzv. sdružené rámečky), pokud náleží ke stejné fázi a jištění." },
  { text: "Co je to 'doutnavka' ve vypínači?", options: ["Pojistka", "Svítící prvek pro orientaci ve tmě", "Zkratovací prvek", "Měřič proudu"], correct: 1, explanation: "Doutnavka slouží k podsvícení vypínače pro snadnější orientaci ve tmě." },
  { text: "Jaký je rozdíl mezi řazením 1 a řazením 6?", options: ["V barvě", "V počtu svorek (2 vs 3)", "V nosnosti proudu", "Žádný"], correct: 1, explanation: "Vypínač č. 1 má 2 svorky (ZAP/VYP), vypínač č. 6 má 3 svorky (přepínací)." },
  { text: "Pro ovládání světla ze 3 míst potřebujeme:", options: ["3x řazení 6", "2x řazení 6 a 1x řazení 7", "1x řazení 6 a 2x řazení 7", "3x řazení 7"], correct: 1, explanation: "Na krajích jsou střídavé (6) a uprostřed libovolný počet křížových (7) přepínačů." },
  { text: "Co znamená zkratka CYKY?", options: ["Celoplastový kabel s měděným jádrem", "Cín, Yoga, Kyslík, Ypsilon", "Typ čínského výrobce", "Gumový kabel"], correct: 0, explanation: "CYKY je standardní označení pro tuhé měděné kabely s PVC izolací." },
  { text: "Jaká je barva fázového vodiče L1?", options: ["Modrá", "Hnědá", "Zelenožlutá", "Fialová"], correct: 1, explanation: "Standardní barva první fáze je hnědá (nebo černá/šedá)." },
  { text: "K čemu slouží proudový chránič (RCD)?", options: ["Proti přetížení", "Proti zkratu", "Ochrana před úrazem proudem", "Stabilizace napětí"], correct: 2, explanation: "RCD odpojí obvod při detekci unikajícího proudu (např. přes tělo člověka)." },
  { text: "Jaký je 'hlavní' rozdíl mezi kabelem a vodičem?", options: ["Cena", "Kabel má více vrstev izolace a plášť", "Délka", "Materiál jádra"], correct: 1, explanation: "Vodič je jedna žíla s izolací, kabel je svazek žil v celkovém plášti." },
  { text: "Kolik ampér vydrží běžná domovní zásuvka 230V?", options: ["6 A", "10 A", "16 A", "25 A"], correct: 2, explanation: "Standardní domovní zásuvky jsou dimenzovány na maximální proud 16 A." },
  { text: "Co se měří multimetrem zapojeným do série s vypnutým spotřebičem?", options: ["Napětí", "Proud", "Odpor", "Výkon"], correct: 1, explanation: "Pro měření proudu se přístroj zapojuje do série (pokud protéká proud)." },
  { text: "Co se stane, když propojíte L a N bez spotřebiče?", options: ["Nic", "Světlo se rozsvítí", "Nastane zkrat", "Vzroste napětí"], correct: 2, explanation: "Přímé propojení fáze a nuly způsobí zkrat a vybití jističe." },
  { text: "Vypínač řazení 5 se používá pro:", options: ["Dvouokruhové svítidlo (lustr)", "Schodiště", "Venkovní světlo", "Garážová vrata"], correct: 0, explanation: "Řazení 5 (sériový přepínač) má dvě klapky pro ovládání dvou částí svítidla." },
  { text: "Jaké je bezpečné napětí AC v suchém prostředí pro dospělé?", options: ["50 V", "120 V", "230 V", "24 V"], correct: 0, explanation: "V normálním suchém prostředí je bezpečné dotykové napětí u střídavého proudu 50 V." },
  { text: "Lze použít střídavý přepínač (6) jako obyčejný vypínač (1)?", options: ["Ano, stačí zapojit L a jednu z výstupních svorek", "Ne, technicky to nejde", "Pouze se speciálním adaptérem", "Ano, ale bude hořet"], correct: 0, explanation: "Ano, řazení 6 je univerzálnější a lze ho použít i jako jednoduchý spínač." },
  { text: "Který nástroj slouží k ověření přítomnosti napětí v zásuvce?", options: ["Metr", "Zkoušečka", "Šroubovák", "Kladivo"], correct: 1, explanation: "Zkoušečka (fázovka nebo dvoupólová) slouží k detekci napětí." },
  { text: "Co označuje písmeno 'E' ve schematických značkách?", options: ["Elektrárna", "Vypínač", "Svítidlo (zátěž)", "Uzemnění"], correct: 2, explanation: "E se často používá pro světelné zdroje a svítidla." },
  { text: "Jak se nazývá krabice pod vypínačem?", options: ["Rozvodka", "Přístrojová krabice (např. KU68)", "Svorkovnice", "Krytka"], correct: 1, explanation: "Pod vypínače se do zdi sádrují přístrojové krabice (standardně KU68)." },
  { text: "Může být jistič 16A použit na kabel 1.5 mm² pro zásuvky?", options: ["Ano", "Ne, je to nebezpečné", "Pouze v dřevostavbě", "Jen u LED světel"], correct: 1, explanation: "Ne, kabel 1.5 mm² není dostatečně dimenzován pro 16A jištění zásuvek." },
  { text: "Jaká je barva fázového vodiče L3?", options: ["Hnědá", "Černá", "Šedá", "Modrá"], correct: 2, explanation: "Standardní pořadí barev fází je Hnědá (L1), Černá (L2), Šedá (L3)." },
  { text: "Vypínač řazení 2 je:", options: ["Jednopólový", "Dvoupólový", "Třípólový", "Schodišťový"], correct: 1, explanation: "Řazení 2 přerušuje oba póly (fázi i nulu najednou) – používá se např. v koupelnách." },
  { text: "Co znamená IP44?", options: ["Ochrana proti stříkající vodě", "Ochrana proti prachu", "Vodotěsnost do 1 metru", "Dětská pojistka"], correct: 0, explanation: "IP44 vyjadřuje ochranu proti vniknutí pevných těles >1mm a proti stříkající vodě." },
  { text: "Která svorka je u vypínače 6 společná?", options: ["Ta nahoře", "Ta dole", "Ta, která je barevně odlišena nebo označena L", "Všechny jsou stejné"], correct: 2, explanation: "Společná svorka je vždy jasně označena (často má jiný šroubek nebo barvu plastu)." },
  { text: "Kolik vodičů CYKY-J 3x1.5 přichází do vypínače řazení 6 v krabici?", options: ["1", "2", "3", "4"], correct: 1, explanation: "Standardně přichází přívod a odchází korespondenční vedení (nebo přívod od předchozího vypínače)." },
  { text: "Co vyjadřuje jednotka Ohm (Ω)?", options: ["Napětí", "Proud", "Elektrický odpor", "Kapacitu"], correct: 2, explanation: "Ohm je jednotka elektrického odporu." },
  { text: "Smí se v domovní elektroinstalaci používat hliníkové vodiče pro nové rozvody?", options: ["Ano", "Ne, pouze měď", "Ano, ale jen do 10A", "Pouze v panelácích"], correct: 1, explanation: "Moderní normy vyžadují pro nové domovní rozvody výhradně měděné vodiče." },
  { text: "Jaké je standardní síťové napětí v ČR?", options: ["110 V / 60 Hz", "230 V / 50 Hz", "400 V / 50 Hz", "220 V / 60 Hz"], correct: 1, explanation: "Standardní napětí v síti je 230 V se síťovou frekvencí 50 Hz." },
  { text: "K čemu slouží svorkovnice 'Wago'?", options: ["K vypnutí proudu", "K bezšroubovému spojování vodičů", "K izolaci drátů", "Ke svícení"], correct: 1, explanation: "Wago svorky jsou populární pro rychlé a bezpečné spojování drátů bez šroubování." },
  { text: "Kolik klidových kontaktů má křížový přepínač?", options: ["Žádný, je to přepínač", "2", "4", "1"], correct: 0, explanation: "Vypínače nefungují jako tlačítka s klidovými kontakty, jsou to mechanické přepínače stavu." },
  { text: "Může mít světelný okruh vlastní proudový chránič?", options: ["Ano a je to doporučeno", "Ne, nesmí", "Pouze v hotelích", "Jen u výbojek"], correct: 0, explanation: "Dnešní normy vyžadují chránič pro všechny běžné okruhy včetně světelných." },
  { text: "Jak se značí ochranný vodič v dokumentaci?", options: ["N", "L", "PE", "PEN"], correct: 2, explanation: "PE (Protective Earth) je označení ochranného uzemňovacího vodiče." },
  { text: "Co znamená 'nulování' v soustavě TN-C?", options: ["Vypnutí všech světel", "Spojení kostry spotřebiče s vodičem PEN", "Vynulování elektroměru", "Zkratování zásuvky"], correct: 1, explanation: "V soustavě TN-C (staré hliníkové rozvody) se ochrana provádí nulováním na společný vodič PEN." },
  { text: "Jak se nazývá svislá drážka ve zdi pro kabel?", options: ["Tunel", "Šlic", "Průraz", "Rýha"], correct: 1, explanation: "V elektrikářském slangu se drážka pro vedení nazývá 'šlic'." },
  { text: "Co musíte udělat před prací na elektrickém zařízení?", options: ["Vypnout příslušný jistič a ověřit beznapěťový stav", "Jen vypnout vypínač", "Vzít si gumové rukavice", "Zavolat sousedovi"], correct: 0, explanation: "Bezpečnostní pravidlo č. 1: Odpojit a ověřit zkoušečkou, zda je obvod skutečně bez napětí." },
  { text: "Jaký je barevný kód žíly pro korespondenční vodiče v kabelu CYKY-O?", options: ["Vždy modrá a hnědá", "Hnědá a černá (nebo šedá)", "Zelenožlutá a modrá", "Červená a bílá"], correct: 1, explanation: "Korespondenční vodiče jsou 'živé', používají se barvy fází (černá, hnědá, šedá)." },
  { text: "Vypínač řazení 4 je:", options: ["Střídavý", "Křížový", "Skupinový (žaluziový)", "Sériový"], correct: 2, explanation: "Řazení 4 se dříve používalo pro žaluzie nebo ovládání dvou skupin světel odděleně." },
  { text: "Lze v zóně 0 v koupelně instalovat vypínač?", options: ["Ano", "Ne, v žádném případě", "Pouze v IP67", "Jen pro baterie"], correct: 1, explanation: "Zóna 0 je vnitřní prostor vany nebo sprchy, tam nesmí být žádné elektroinstalace na 230V." },
  { text: "Co je to 'vratný' vypínač (tlačítko)?", options: ["Řazení 1/0", "Řazení 6", "Řazení 5", "Jistič"], correct: 0, explanation: "Tlačítko (řazení 1/0) sepne kontakt jen po dobu stisku (např. pro zvonek nebo relé)." }
];

const App = () => {
  const [activeTab, setActiveTab] = useState('sim');
  const [circuitMode, setCircuitMode] = useState(6);

  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [feedback, setFeedback] = useState<{ correct: boolean; selected: number } | null>(null);
  const [showQRModal, setShowQRModal] = useState(false);
  
  // State for current selection of 10 random questions
  const [currentQuiz, setCurrentQuiz] = useState<any[]>([]);
  const [currentQIndex, setCurrentQIndex] = useState(0);

  // Initialize quiz
  React.useEffect(() => {
    shuffleAndSetQuiz();
  }, []);

  const shuffleAndSetQuiz = () => {
    const shuffled = [...ALL_QUESTIONS].sort(() => 0.5 - Math.random());
    setCurrentQuiz(shuffled.slice(0, 10));
    setCurrentQIndex(0);
    setScore(0);
    setShowResult(false);
    setFeedback(null);
  };

  const handleAnswer = (idx: number) => {
    if (feedback || currentQuiz.length === 0) return;
    const correct = idx === currentQuiz[currentQIndex].correct;
    if (correct) setScore(score + 1);
    setFeedback({ correct, selected: idx });
  };

  const nextQuestion = () => {
    setFeedback(null);
    if (currentQIndex < currentQuiz.length - 1) {
      setCurrentQIndex(currentQIndex + 1);
    } else {
      setShowResult(true);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-4 font-sans text-slate-800">
      <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="bg-slate-900 p-6 text-white flex flex-col md:flex-row justify-between items-center gap-4">
          <h1 className="text-xl font-bold">Simulátor Elektroinstalace: Proudová cesta</h1>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowQRModal(true)} 
              className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
              title="Zobrazit QR kód pro sdílení"
            >
              <QrCode size={20} />
            </button>
            <div className="flex bg-slate-800 rounded-lg p-1">
              <button onClick={() => setActiveTab('sim')} className={`px-4 py-2 rounded-md text-sm font-bold transition-all ${activeTab === 'sim' ? 'bg-blue-600 text-white' : 'hover:bg-slate-700'}`}>Schéma</button>
              <button onClick={() => setActiveTab('tools')} className={`px-4 py-2 rounded-md text-sm font-bold transition-all ${activeTab === 'tools' ? 'bg-blue-600 text-white' : 'hover:bg-slate-700'}`}>Měření</button>
              <button onClick={() => setActiveTab('test')} className={`px-4 py-2 rounded-md text-sm font-bold transition-all ${activeTab === 'test' ? 'bg-blue-600 text-white' : 'hover:bg-slate-700'}`}>Test</button>
            </div>
          </div>
        </div>

        {/* QR Kód Modal */}
        {showQRModal && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white p-8 rounded-2xl shadow-2xl max-w-sm w-full relative flex flex-col items-center"
            >
              <button 
                onClick={() => setShowQRModal(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-800 transition-colors"
              >
                <X size={24} />
              </button>
              <h2 className="text-xl font-bold mb-6 text-slate-800">Sdílet aplikaci</h2>
              <div className="bg-white p-4 rounded-xl border-2 border-slate-100 shadow-sm mb-6">
                <QRCode value={window.location.href} size={200} />
              </div>
              <p className="text-sm text-slate-500 text-center mb-4">
                Naskenujte tento QR kód pro otevření simulátoru na mobilním zařízení nebo tabletu.
              </p>
              <div className="w-full bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs text-slate-600 break-all text-center">
                {window.location.href}
              </div>
            </motion.div>
          </div>
        )}

        {/* Global Toolbar */}
        <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-4 bg-slate-50">
          <div className="flex items-center gap-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Typ obvodu:</span>
            <div className="flex border border-slate-300 rounded overflow-hidden">
              <button 
                onClick={() => setCircuitMode(6)} 
                className={`px-4 py-1 text-xs font-bold transition-colors ${circuitMode === 6 ? 'bg-slate-800 text-white' : 'bg-white hover:bg-slate-50'}`}
              >
                Řazení 6
              </button>
              <button 
                onClick={() => setCircuitMode(7)} 
                className={`px-4 py-1 text-xs font-bold transition-colors ${circuitMode === 7 ? 'bg-slate-800 text-white' : 'bg-white hover:bg-slate-50'}`}
              >
                Řazení 7
              </button>
            </div>
          </div>
        </div>

        {activeTab === 'sim' ? (
          <div className="p-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <InteractiveCircuit key={circuitMode} initialMode={circuitMode} />

            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl">
                <h3 className="font-black text-blue-400 text-[10px] mb-4 uppercase tracking-[0.2em] flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500" /> Legenda symbolů
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-0.5 bg-orange-500" />
                    <span className="text-[10px] text-slate-300 font-bold uppercase">Fázový vodič (L)</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-0.5 bg-blue-500/50 border-b border-dashed border-blue-500" />
                    <span className="text-[10px] text-slate-300 font-bold uppercase">Nulový vodič (N)</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full border border-slate-400 bg-slate-700" />
                    <span className="text-[10px] text-slate-300 font-bold uppercase">Svorka (Terminal)</span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl">
                 <h3 className="font-black text-orange-400 text-[10px] mb-4 uppercase tracking-[0.2em] flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-orange-500" /> Cíl výuky
                </h3>
                <p className="text-[11px] text-slate-400 leading-relaxed font-medium">
                  Sledujte <strong>proudovou cestu</strong>. Oranžová barva znázorňuje napětí. 
                  Cílem je pochopit, jak se střídavé (Sch 6) a křížové (Sch 7) přepínače navzájem ovlivňují v sérii.
                </p>
              </div>
            </div>
          </div>
        ) : activeTab === 'tools' ? (
          <div className="p-8 animate-in fade-in zoom-in-95 duration-500">
            <h2 className="text-xl font-black mb-2 uppercase tracking-tight text-slate-800">Virtuální měření</h2>
            <p className="text-xs text-slate-500 mb-8 max-w-lg">
              Vyberte si měřicí přístroj a umístěte jej na testovací body (šedé tečky) v obvodu. 
              Sledujte, jak se mění hodnoty v závislosti na stavu vypínačů.
            </p>
            <MeasurementWorkbench circuitMode={circuitMode} />
          </div>
        ) : (
          <div className="p-8">
            {!showResult && currentQuiz.length > 0 ? (
              <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 max-w-2xl mx-auto">
                <div className="mb-4">
                  <span className="text-[10px] font-bold text-blue-600 uppercase">Test znalostí: Otázka {currentQIndex + 1} / {currentQuiz.length}</span>
                  <h2 className="text-lg font-bold mt-2 leading-tight">{currentQuiz[currentQIndex].text}</h2>
                </div>

                <div className="my-6">{currentQuiz[currentQIndex].diagram}</div>

                <motion.div 
                  key={currentQIndex}
                  initial="hidden"
                  animate="visible"
                  variants={{
                    visible: { transition: { staggerChildren: 0.1 } }
                  }}
                  className="space-y-2"
                >
                  {currentQuiz[currentQIndex].options.map((opt: string, i: number) => (
                    <motion.button 
                      key={i} 
                      variants={{
                        hidden: { opacity: 0, x: -20 },
                        visible: { opacity: 1, x: 0 }
                      }}
                      onClick={() => handleAnswer(i)}
                      className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
                        feedback 
                          ? i === currentQuiz[currentQIndex].correct ? 'bg-green-100 border-green-500' : i === feedback.selected ? 'bg-red-100 border-red-500' : 'bg-white opacity-50'
                          : 'bg-white border-slate-200 hover:border-blue-400'
                      }`}
                      disabled={feedback !== null}
                      whileHover={!feedback ? { scale: 1.01, x: 5 } : {}}
                      whileTap={!feedback ? { scale: 0.98 } : {}}
                    >
                      <span className="text-sm font-bold">{opt}</span>
                    </motion.button>
                  ))}
                </motion.div>

                {feedback && (
                  <div className="mt-6 p-4 bg-white rounded-lg border border-slate-200 shadow-sm animate-in fade-in">
                    <p className="text-xs text-slate-600 italic mb-4">{currentQuiz[currentQIndex].explanation}</p>
                    <button onClick={feedback.correct ? nextQuestion : () => setFeedback(null)} 
                            className="w-full py-3 bg-slate-900 text-white rounded-lg font-bold text-xs">
                      {currentQIndex < currentQuiz.length - 1 ? 'DALŠÍ OTÁZKA' : 'ZOBRAZIT VÝSLEDEK'}
                    </button>
                  </div>
                )}
              </div>
            ) : showResult ? (
              <div className="text-center p-12 bg-white border border-slate-200 rounded-xl shadow-xl max-w-sm mx-auto">
                <h2 className="text-2xl font-black mb-4">Výsledek testu</h2>
                <div className="text-6xl font-black text-blue-600 mb-8">{Math.round((score/currentQuiz.length)*100)}%</div>
                <div className="text-xs text-slate-500 mb-8 font-bold uppercase tracking-widest">
                  Správně: {score} z {currentQuiz.length}
                </div>
                <button onClick={shuffleAndSetQuiz} className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold uppercase tracking-widest text-xs shadow-lg">Nová sada otázek</button>
              </div>
            ) : (
               <div className="text-center p-12">
                 <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4" />
                 <p className="text-xs text-slate-400 font-bold uppercase font-mono">Připravuji otázky...</p>
               </div>
            )}
          </div>
        )}

        <div className="bg-slate-50 border-t border-slate-100 p-4 text-center text-[9px] text-slate-400 font-bold uppercase tracking-[0.4em]">
          Učební obor Elektrikář • Technologie elektroinstalace • 2026
        </div>
      </div>
    </div>
  );
};

export default App;
