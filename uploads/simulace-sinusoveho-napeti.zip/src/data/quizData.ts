export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export const quizQuestions: Question[] = [
  {
    id: 1,
    question: "Jak se nazývá jev, při kterém ve vodiči vzniká napětí vlivem časové změny magnetického pole?",
    options: ["Elektrostatická indukce", "Elektromagnetická indukce", "Magnetorezistence", "Hala-efekt"],
    correctAnswer: 1,
    explanation: "Elektromagnetická indukce je vznik elektromotorického napětí v uzavřeném elektrickém obvodu způsobený změnou magnetického toku."
  },
  {
    id: 2,
    question: "Který fyzik formuloval zákon o směru indukovaného proudu?",
    options: ["Ampére", "Tesla", "Lenz", "Faraday"],
    correctAnswer: 2,
    explanation: "Lenzův zákon říká, že indukovaný proud má takový směr, že svým magnetickým polem působí proti změně, která ho vyvolala."
  },
  {
    id: 3,
    question: "V jakých jednotkách se měří magnetická indukce?",
    options: ["Weber (Wb)", "Tesla (T)", "Henry (H)", "Volt (V)"],
    correctAnswer: 1,
    explanation: "Jednotkou magnetické indukce v soustavě SI je Tesla (T)."
  },
  {
    id: 4,
    question: "Co se stane s indukovaným napětím, pokud zdvojnásobíme rychlost otáčení rotoru?",
    options: ["Zůstane stejné", "Klesne na polovinu", "Zdvojnásobí se", "Vzroste čtyřikrát"],
    correctAnswer: 2,
    explanation: "Indukované napětí je přímo úměrné rychlosti změny magnetického toku (v tomto případě úhlové rychlosti)."
  },
  {
    id: 5,
    question: "Při jakém úhlu α mezi vodičem a siločárami je indukované napětí maximální?",
    options: ["0°", "45°", "90°", "180°"],
    correctAnswer: 2,
    explanation: "Vztah obsahuje funkci sin(α), která nabývá maxima (1) při úhlu 90°."
  },
  {
    id: 6,
    question: "Jednotkou magnetického toku Φ je:",
    options: ["Tesla (T)", "Weber (Wb)", "Farad (F)", "Ohm (Ω)"],
    correctAnswer: 1,
    explanation: "Magnetický tok se měří ve Weberech (Wb), kde 1 Wb = 1 T · m²."
  },
  {
    id: 7,
    question: "K určení směru indukovaného proudu v přímém vodiči používáme:",
    options: ["Pravidlo pravé ruky", "Pravidlo levé ruky", "Zákon zachování hybnosti", "Ohmův zákon"],
    correctAnswer: 0,
    explanation: "Flemingovo pravidlo pravé ruky se používá k určení směru proudu indukovaného v pohyblivém vodiči v magnetickém poli."
  },
  {
    id: 8,
    question: "Základní vztah pro indukované napětí na pohybujícím se vodiči je U_i = ...",
    options: ["B · I · l", "B · v · l · sin(α)", "Φ / t", "R · I"],
    correctAnswer: 1,
    explanation: "Vztah U_i = B · v · l · sin(α) vyjadřuje napětí indukované na vodiči délky l pohybujícím se rychlostí v v poli B."
  },
  {
    id: 9,
    question: "Co vyjadřuje Faradayův zákon magnetické indukce?",
    options: ["Indukované napětí je rovno časové změně magnetického toku", "Odpor vodiče", "Sílu mezi dvěma magnety", "Kapacitu kondenzátoru"],
    correctAnswer: 0,
    explanation: "Faradayův zákon: U_i = -dΦ/dt."
  },
  {
    id: 10,
    question: "Jaký průběh má napětí indukované v rotující smyčce v homogenním poli?",
    options: ["Konstantní stejnosměrný", "Obdélníkový", "Sinusový", "Exponenciální"],
    correctAnswer: 2,
    explanation: "Při rovnoměrném otáčení se úhel mění lineárně s časem, což vede k sinusovému průběhu napětí."
  },
  {
    id: 11,
    question: "Pokud je vodič v klidu v konstantním magnetickém poli, indukované napětí je:",
    options: ["Maximální", "Nulové", "Konstantní nenulové", "Závislé na teplotě"],
    correctAnswer: 1,
    explanation: "Pro indukci je nutná změna magnetického pole nebo pohyb vodiče (změna toku)."
  },
  {
    id: 12,
    question: "Vlastní indukčnost se měří v jednotkách:",
    options: ["Tesla", "Volt", "Henry (H)", "Watt"],
    correctAnswer: 2,
    explanation: "Jednotkou indukčnosti je Henry (H)."
  },
  {
    id: 13,
    question: "Samoindukce vzniká:",
    options: ["V každém magnetu", "Při změně proudu ve vlastní cívce", "Jen u stejnosměrného proudu", "V kondenzátoru"],
    correctAnswer: 1,
    explanation: "Samoindukce je jev, kdy měnící se proud ve vodiči indukuje napětí v témže vodiči."
  },
  {
    id: 14,
    question: "Proud vznikající při elektromagnetické indukci v uzavřeném vodiči se nazývá:",
    options: ["Statický proud", "Indukovaný proud", "Vířivý proud", "Kapacitní proud"],
    correctAnswer: 1,
    explanation: "Proud vyvolaný indukovaným napětím v uzavřeném obvodu."
  },
  {
    id: 15,
    question: "Který technický přístroj využívá elektromagnetickou indukci k přeměně mechanické energie na elektrickou?",
    options: ["Elektromotor", "Transformátor", "Generátor (alternátor)", "Akumulátor"],
    correctAnswer: 2,
    explanation: "Generátory využívají principu indukce k výrobě elektřiny z rotace."
  },
  {
    id: 16,
    question: "Co popisuje veličina magnetický tok Φ?",
    options: ["Počet siločár procházejících plochou", "Sílu magnetu", "Rychlost elektronů", "Elektrický odpor"],
    correctAnswer: 0,
    explanation: "Magnetický tok je mírou celkového magnetismu procházejícího danou plochou."
  },
  {
    id: 17,
    question: "Železné jádro v cívce způsobuje:",
    options: ["Snížení magnetického pole", "Zesílení magnetického pole", "Změnu polarity", "Zrušení indukce"],
    correctAnswer: 1,
    explanation: "Feromagnetické jádro výrazně zvyšuje magnetickou indukci cívky."
  },
  {
    id: 18,
    question: "Frekvence střídavého proudu v běžné síti v ČR je:",
    options: ["10 Hz", "50 Hz", "60 Hz", "230 Hz"],
    correctAnswer: 1,
    explanation: "Standardní frekvence v Evropě je 50 Hz."
  },
  {
    id: 19,
    question: "Perioda střídavého proudu o frekvenci 50 Hz je:",
    options: ["0,02 s", "0,5 s", "1 s", "50 s"],
    correctAnswer: 0,
    explanation: "T = 1/f = 1/50 = 0,02 s."
  },
  {
    id: 20,
    question: "Efektivní hodnota střídavého napětí 230 V odpovídá maximální hodnotě (amplitudě) přibližně:",
    options: ["230 V", "325 V", "400 V", "115 V"],
    correctAnswer: 1,
    explanation: "U_max = U_ef * sqrt(2) ≈ 230 * 1,414 ≈ 325 V."
  },
  {
    id: 21,
    question: "Jaký úhel α odpovídá nulovému indukovanému napětí v simulaci?",
    options: ["0° a 180°", "90° a 270°", "45°", "Pouze 360°"],
    correctAnswer: 0,
    explanation: "V těchto bodech se vodič pohybuje rovnoběžně se siločárami, sin(0)=0."
  },
  {
    id: 22,
    question: "Který materiál je nejvhodnější pro jádro transformátoru?",
    options: ["Měď", "Hliník", "Měkká magnetická ocel", "Plast"],
    correctAnswer: 2,
    explanation: "Magneticky měkké materiály mají úzkou hysterezní smyčku a minimalizují ztráty."
  },
  {
    id: 23,
    question: "Transformátor slouží k:",
    options: ["Změně frekvence", "Změně velikosti střídavého napětí", "Měření odporu", "Výrobě energie"],
    correctAnswer: 1,
    explanation: "Transformátor mění napětí a proud při zachování (ideálně) stejného výkonu a frekvence."
  },
  {
    id: 24,
    question: "Princip transformátoru je založen na:",
    options: ["Tepelném účinku", "Vzájemné indukci", "Elektrostatice", "Mechanickém tření"],
    correctAnswer: 1,
    explanation: "Měnící se pole primární cívky indukuje napětí v sekundární cívce."
  },
  {
    id: 25,
    question: "Vířivé proudy vznikají:",
    options: ["Jen v kapalinách", "V masivních vodičích v proměnném poli", "V izolantech", "V klidném magnetu"],
    correctAnswer: 1,
    explanation: "Foucaultovy proudy jsou uzavřené proudy indukované v objemových vodičích."
  },
  {
    id: 26,
    question: "Jak se omezují ztráty vířivými proudy v jádrech transformátorů?",
    options: ["Chlazením vodou", "Složením jádra z izolovaných plechů", "Použitím silnějších drátů", "Nátěrem černou barvou"],
    correctAnswer: 1,
    explanation: "Izolované plechy přerušují dráhy vířivých proudů."
  },
  {
    id: 27,
    question: "Lorentzova síla působí na:",
    options: ["Nehybný náboj", "Pohybující se náboj v magnetickém poli", "Světlo ve vakuu", "Neutrony"],
    correctAnswer: 1,
    explanation: "F = q · (v × B)."
  },
  {
    id: 28,
    question: "Magnetické pole kolem přímého vodiče s proudem tvoří:",
    options: ["Přímky", "Soustředné kružnice", "Čtverce", "Paraboly"],
    correctAnswer: 1,
    explanation: "Siločáry tvoří uzavřené kružnice kolem vodiče."
  },
  {
    id: 29,
    question: "Směr siločár magnetického pole u magnetu je:",
    options: ["Od S k N (vně)", "Od N k S (vně)", "Náhodný", "Vždy vertikální"],
    correctAnswer: 1,
    explanation: "Vně magnetu směřují siločáry od severního (N) k jižnímu (S) pólu."
  },
  {
    id: 30,
    question: "Co je to solenoid?",
    options: ["Druh baterie", "Válcová cívka", "Měřič napětí", "Typ izolace"],
    correctAnswer: 1,
    explanation: "Solenoid je dlouhá cívka s mnoha závity."
  },
  {
    id: 31,
    question: "Relativní permeabilita vakua je rovna:",
    options: ["0", "1", "4π · 10^-7", "Nekonečnu"],
    correctAnswer: 1,
    explanation: "Relativní permeabilita vakua (mu_r) je definována jako 1."
  },
  {
    id: 32,
    question: "Feromagnetické látky mají relativní permeabilitu:",
    options: ["Mnohem menší než 1", "Rovnu 1", "Mnohem větší než 1", "Zápornou"],
    correctAnswer: 2,
    explanation: "Tyto látky (železo, kobalt, nikl) pole výrazně zesilují."
  },
  {
    id: 33,
    question: "Curieova teplota je bod, kdy:",
    options: ["Látka taje", "Feromagnetická látka ztrácí své vlastnosti", "Indukce je nulová", "Vodič se stává supravodičem"],
    correctAnswer: 1,
    explanation: "Nad touto teplotou se feromagnetikum stává paramagnetikem."
  },
  {
    id: 34,
    question: "Pokud se magnet přibližuje k cívce, v cívce vzniká:",
    options: ["Stacionární pole", "Indukované napětí", "Mrazivý efekt", "Úbytek hmotnosti"],
    correctAnswer: 1,
    explanation: "Pohyblivý magnet mění tok Φ v cívce, což indukuje napětí."
  },
  {
    id: 35,
    question: "Počet závitů cívky ovlivňuje indukované napětí tak, že:",
    options: ["S více závity napětí klesá", "S více závity napětí roste", "Počet závitů nemá vliv", "Změní směr proudu"],
    correctAnswer: 1,
    explanation: "U_i = N · (ΔΦ / Δt), kde N je počet závitů."
  },
  {
    id: 36,
    question: "Vztah pro energii magnetického pole cívky je:",
    options: ["E = 1/2 · L · I^2", "E = m · c^2", "E = U · I · t", "E = 1/2 · C · U^2"],
    correctAnswer: 0,
    explanation: "Energie je úměrná indukčnosti a čtverci proudu."
  },
  {
    id: 37,
    question: "Co se stane s Φ, pokud plochu S kolmou k poli B zmenšíme na polovinu?",
    options: ["Φ se zdvojnásobí", "Φ se nezmění", "Φ klesne na polovinu", "Φ bude nulový"],
    correctAnswer: 2,
    explanation: "Φ = B · S · cos(theta). Přímá úměra k ploše."
  },
  {
    id: 38,
    question: "Indukovaný proud v simulaci mění směr každých:",
    options: ["90°", "180°", "360°", "45°"],
    correctAnswer: 1,
    explanation: "Polarita se mění při průchodu nulovou linií (rovnoběžný pohyb)."
  },
  {
    id: 39,
    question: "Tesla je ekvivalentní jednotce:",
    options: ["Wb / m^2", "V / s", "A · m", "N · C"],
    correctAnswer: 0,
    explanation: "Z definice toku Φ = B · S plyne B = Φ / S."
  },
  {
    id: 40,
    question: "V jakém případě je indukované napětí v simulaci záporné?",
    options: ["Při pohybu v horní polovině (0°-180°)", "Při pohybu v dolní polovině (180°-360°)", "Vždy", "Nikdy"],
    correctAnswer: 1,
    explanation: "V druhé polovině otáčky se směr protnutí siločár relativně otočí."
  },
  {
    id: 41,
    question: "Co určuje frekvenci generovaného napětí?",
    options: ["Počet pólů a rychlost otáčení", "Barva magnetu", "Délka kabelu k žárovce", "Teplota okolí"],
    correctAnswer: 0,
    explanation: "Frekvence závisí na mechanických otáčkách stroje."
  },
  {
    id: 42,
    question: "Elektromagnet je:",
    options: ["Přírodní magnet", "Cívka s jádrem, kterou protéká proud", "Kus gumy", "Měřič magnetismu"],
    correctAnswer: 1,
    explanation: "Magnetismus elektromagnetu lze vypnout přerušením proudu."
  },
  {
    id: 43,
    question: "Zákon elektromagnetické indukce objevil:",
    options: ["Newton", "Faraday", "Einstein", "Ohm"],
    correctAnswer: 1,
    explanation: "Michael Faraday v roce 1831."
  },
  {
    id: 44,
    question: "V generátoru na elektrokole se indukuje napětí:",
    options: ["Stejnosměrné", "Střídavé", "Žádné", "Statické"],
    correctAnswer: 1,
    explanation: "Dynamo u kola je vlastně malý alternátor (pokud nemá komutátor)."
  },
  {
    id: 45,
    question: "Komutátor u stejnosměrného stroje slouží k:",
    options: ["Chlazení", "Mechanickému usměrnění proudu", "Zvýšení napětí", "Měření otáček"],
    correctAnswer: 1,
    explanation: "Přepíná směr připojení cívek tak, aby vnějším obvodem tekl proud jedním směrem."
  },
  {
    id: 46,
    question: "Jednotkou úhlové rychlosti ω je:",
    options: ["Stupeň / s", "Radián / s", "Otáčka / min", "Metr / s"],
    correctAnswer: 1,
    explanation: "SI jednotkou je rad/s."
  },
  {
    id: 47,
    question: "Jaký je vztah mezi frekvencí f a periodou T?",
    options: ["f = T", "f = 1 / T", "f = T^2", "f = sqrt(T)"],
    correctAnswer: 1,
    explanation: "Frekvence je převrácená hodnota periody."
  },
  {
    id: 48,
    question: "Jak se změní magnetické pole cívky, pokud do ní vložíme hliníkové jádro?",
    options: ["Výrazně zesílí", "Výrazně zeslábne", "Téměř se nezmění", "Změní se na elektrické"],
    correctAnswer: 2,
    explanation: "Hliník je paramagnetikum, jeho vliv na zesílení pole je zanedbatelný oproti železu."
  },
  {
    id: 49,
    question: "Magnetické pole Země nás chrání před:",
    options: ["Deštěm", "Slunečním větrem (nabitými částicemi)", "Měsíčním světlem", "Zemětřesením"],
    correctAnswer: 1,
    explanation: "Magnetosféra odklání proud nabitých částic ze Slunce."
  },
  {
    id: 50,
    question: "Vztah pro magnetickou indukci v dutině dlouhého solenoidu je B = ...",
    options: ["mu · (N · I) / l", "F / q", "k · Q / r", "U / R"],
    correctAnswer: 0,
    explanation: "Pole závisí na permeabilitě, hustotě závitů a proudu."
  }
];
