import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, XCircle, ChevronRight, RotateCcw, Award, BookOpen } from 'lucide-react';
import { quizQuestions, Question } from '../data/quizData';

export default function Quiz() {
  const [sessionQuestions, setSessionQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [quizComplete, setQuizComplete] = useState(false);

  // Initialize quiz: shuffle and pick 10
  useEffect(() => {
    const shuffled = [...quizQuestions].sort(() => Math.random() - 0.5);
    setSessionQuestions(shuffled.slice(0, 10));
  }, []);

  const currentQuestion = sessionQuestions[currentIndex];

  const handleOptionSelect = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
  };

  const handleConfirm = () => {
    if (selectedOption === null || isAnswered) return;
    
    setIsAnswered(true);
    if (selectedOption === currentQuestion.correctAnswer) {
      setScore(prev => prev + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < sessionQuestions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setQuizComplete(true);
    }
  };

  const resetQuiz = () => {
    const shuffled = [...quizQuestions].sort(() => Math.random() - 0.5);
    setSessionQuestions(shuffled.slice(0, 10));
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setScore(0);
    setQuizComplete(false);
  };

  if (sessionQuestions.length === 0) return null;

  return (
    <section className="bg-white border-t border-black p-6 md:p-10">
      <div className="max-w-4xl mx-auto">
        <header className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h2 className="text-xs font-black uppercase tracking-[0.3em] mb-4 border-b border-black pb-2 flex items-center gap-2">
              <BookOpen className="w-3.5 h-3.5" />
              03. Testování Znalostí
            </h2>
            <div className="flex items-baseline gap-3">
              <span className="text-5xl font-serif italic tracking-tighter">Fyzikální Kvíz</span>
              <span className="text-[10px] font-black uppercase tracking-widest opacity-30">Verze 1.0 / 50 Úloh</span>
            </div>
          </div>
          <div className="flex items-center gap-8">
            <div className="flex flex-col items-end">
              <span className="text-[9px] font-black uppercase tracking-widest opacity-40 mb-1">Průběh</span>
              <span className="text-xl font-mono font-bold leading-none">{currentIndex + 1} / 10</span>
            </div>
            <div className="flex flex-col items-end">
              <span className="text-[9px] font-black uppercase tracking-widest opacity-40 mb-1">Skóre</span>
              <span className="text-xl font-mono font-bold leading-none text-red-600">{score}</span>
            </div>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {!quizComplete ? (
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className="p-8 border border-black bg-[#FDFCFB] relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 border-l border-b border-black opacity-5 pointer-events-none translate-x-12 -translate-y-12 rotate-45" />
                <h3 className="text-xl md:text-2xl font-medium leading-snug">
                  {currentQuestion.question}
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {currentQuestion.options.map((option, idx) => {
                  const isSelected = selectedOption === idx;
                  const isCorrect = isAnswered && idx === currentQuestion.correctAnswer;
                  const isWrong = isAnswered && isSelected && idx !== currentQuestion.correctAnswer;

                  return (
                    <button
                      key={idx}
                      onClick={() => handleOptionSelect(idx)}
                      disabled={isAnswered}
                      className={`
                        p-6 text-left transition-all relative border flex items-center justify-between group
                        ${isSelected ? 'border-black bg-black text-white shadow-xl translate-y-[-2px]' : 'border-black/10 hover:border-black/40'}
                        ${isCorrect ? '!bg-green-600 !border-green-600 !text-white' : ''}
                        ${isWrong ? '!bg-red-600 !border-red-600 !text-white' : ''}
                        ${isAnswered && !isSelected && !isCorrect ? 'opacity-30' : ''}
                      `}
                    >
                      <div className="flex items-center gap-4">
                        <span className={`text-[10px] font-mono font-bold w-6 h-6 flex items-center justify-center border rounded-full transition-colors
                          ${isSelected ? 'border-white/40' : 'border-black/10'}
                        `}>
                          {String.fromCharCode(65 + idx)}
                        </span>
                        <span className="text-sm font-medium">{option}</span>
                      </div>
                      
                      {isCorrect && <CheckCircle2 className="w-5 h-5" />}
                      {isWrong && <XCircle className="w-5 h-5" />}
                    </button>
                  );
                })}
              </div>

              <div className="flex flex-col md:flex-row items-center justify-between gap-6 pt-4">
                <div className="flex-grow">
                  <AnimatePresence>
                    {isAnswered && (
                      <motion.div
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="p-4 bg-black/5 border-l-4 border-black"
                      >
                        <p className="text-[10px] font-black uppercase tracking-widest mb-1 opacity-50">Vysvětlení</p>
                        <p className="text-xs font-medium leading-relaxed">{currentQuestion.explanation}</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="flex items-center gap-4 shrink-0">
                  {!isAnswered ? (
                    <button
                      onClick={handleConfirm}
                      disabled={selectedOption === null}
                      className="px-10 py-4 bg-black text-white text-[11px] font-black uppercase tracking-[0.2em] disabled:opacity-30 transition-all hover:shadow-2xl"
                    >
                      Potvrdit Odpověď
                    </button>
                  ) : (
                    <button
                      onClick={handleNext}
                      className="px-10 py-4 bg-red-600 text-white text-[11px] font-black uppercase tracking-[0.2em] flex items-center gap-2 hover:bg-black transition-all"
                    >
                      {currentIndex === sessionQuestions.length - 1 ? 'Dokončit Kvíz' : 'Další Úloha'}
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="py-20 text-center space-y-10 border border-black bg-black text-white relative overflow-hidden"
            >
              <div className="absolute inset-0 opacity-10 pointer-events-none grid grid-cols-12 gap-0">
                {Array.from({ length: 144 }).map((_, i) => (
                  <div key={i} className="border-r border-b border-white h-12" />
                ))}
              </div>

              <div className="relative z-10 space-y-6">
                <div className="w-24 h-24 border-2 border-white rounded-full mx-auto flex items-center justify-center animate-bounce">
                  <Award className="w-12 h-12" />
                </div>
                <div>
                  <h3 className="text-4xl font-serif italic mb-2 tracking-tight">Test Dokončen</h3>
                  <p className="text-[10px] uppercase tracking-[0.4em] opacity-50">Vaše finální hodnocení</p>
                </div>
                
                <div className="flex items-center justify-center gap-8">
                  <div className="text-center">
                    <span className="block text-6xl font-mono font-bold leading-none">{score}</span>
                    <span className="text-[9px] uppercase tracking-widest opacity-40">Bodů</span>
                  </div>
                  <div className="w-[1px] h-12 bg-white/20" />
                  <div className="text-center">
                    <span className="block text-6xl font-mono font-bold leading-none">{Math.round((score / 10) * 100)}%</span>
                    <span className="text-[9px] uppercase tracking-widest opacity-40">Úspěšnost</span>
                  </div>
                </div>

                <div className="pt-8">
                  <button
                    onClick={resetQuiz}
                    className="px-12 py-5 border-2 border-white text-xs font-black uppercase tracking-[0.3em] hover:bg-white hover:text-black transition-all flex items-center gap-3 mx-auto"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Nový Test
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
