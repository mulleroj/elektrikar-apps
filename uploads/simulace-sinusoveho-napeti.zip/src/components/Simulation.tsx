/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Play, Pause, Info, Zap, RotateCcw, ChevronDown, ChevronUp, Beaker } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SimulationProps {
  speed: number;
  isRunning: boolean;
  length: number;
}

const Simulation: React.FC<SimulationProps> = ({ speed, isRunning, length }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [angle, setAngle] = useState(0);
  const [history, setHistory] = useState<number[]>([]);
  const requestRef = useRef<number>(null);
  const angleRef = useRef(0);
  const flowOffsetRef = useRef(0);
  const historyRef = useRef<number[]>([]);
  const lengthRef = useRef(length);

  useEffect(() => {
    lengthRef.current = length;
  }, [length]);

  const maxHistory = 400;

  const getExplanation = (deg: number) => {
    if (deg >= 350 || deg <= 10) return "Nulový bod: Vodič 'klouže' po siločárách. Ui = 0V.";
    if (deg > 10 && deg < 80) return "Nárůst: Úhel alfa se blíží k 90°, napětí Ui se zvětšuje.";
    if (deg >= 80 && deg <= 100) return "Maximum: Vodič krájí siločáry kolmo. Sin(90°) = 1, proto je Ui nejvyšší.";
    if (deg > 100 && deg < 170) return "Pokles: Úhel se opět zmenšuje, Ui klesá k nule.";
    if (deg >= 170 && deg <= 190) return "Obrat: Napětí prochází nulou a začíná indukovat opačným směrem.";
    if (deg > 190 && deg < 260) return "Záporný nárůst: Vodič řeže pole zespodu, Ui narůstá do záporu.";
    if (deg >= 260 && deg <= 280) return "Záporné maximum: Sin(270°) = -1. Maximální výchylka na druhou stranu.";
    return "Návrat: Dokončení periody a příprava na další otočku.";
  };

  const draw = useCallback((ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.clearRect(0, 0, width, height);

    const currentAngle = angleRef.current;
    const currentHistory = historyRef.current;
    const currentFlowOffset = flowOffsetRef.current;

    // Dimensions
    const generatorX = width < 640 ? width / 2 : 180;
    const generatorY = 160;
    // Make radius reactive to length parameter (0.1 to 1.0 -> 30 to 90px)
    const radius = 30 + lengthRef.current * 65;

    // 1. Draw Magnetic Field
    ctx.fillStyle = '#ef4444'; // Red (North)
    ctx.fillRect(generatorX - 150, generatorY - 110, 50, 220);
    ctx.fillStyle = '#3b82f6'; // Blue (South)
    ctx.fillRect(generatorX + 100, generatorY - 110, 50, 220);
    
    ctx.fillStyle = 'white';
    ctx.font = 'bold 24px "Playfair Display", serif';
    ctx.fillText('N', generatorX - 135, generatorY + 10);
    ctx.fillText('S', generatorX + 115, generatorY + 10);

    // Magnetic flux lines (Animated flow from N to S with realistic curvature)
    ctx.setLineDash([12, 18]);
    ctx.lineDashOffset = -currentFlowOffset;
    ctx.lineWidth = 1;
    
    // We draw more lines for a denser, more "scientific" look
    for (let i = -120; i <= 120; i += 20) {
      const startX = generatorX - 100;
      const endX = generatorX + 100;
      const startY = generatorY + i;
      const endY = generatorY + i;
      
      // Calculate more pronounced curvature (bowing outwards from center)
      const distFromCenter = i / 120;
      const curvature = distFromCenter * 35; 
      const controlX = generatorX;
      const controlY = generatorY + i + curvature;

      ctx.beginPath();
      // Center lines are stronger, outer lines are more faint/ethereal
      const alpha = 0.18 - Math.abs(distFromCenter) * 0.12;
      ctx.strokeStyle = `rgba(0,0,0,${alpha})`; 
      
      ctx.moveTo(startX, startY);
      ctx.quadraticCurveTo(controlX, controlY, endX, endY);
      ctx.stroke();

      // Flow indicators (arrows) that follow the curve path
      if (Math.abs(i) <= 100) {
        ctx.save();
        [0.25, 0.5, 0.75].forEach(t => {
          // Quadratic formula: B(t) = (1-t)^2*P0 + 2(1-t)t*P1 + t^2*P2
          const arrowX = (1-t)*(1-t)*startX + 2*(1-t)*t*controlX + t*t*endX;
          const arrowY = (1-t)*(1-t)*startY + 2*(1-t)*t*controlY + t*t*endY;
          
          // Calculate tangent for arrowhead rotation
          // B'(t) = 2(1-t)(P1 - P0) + 2t(P2 - P1)
          const tx = 2*(1-t)*(controlX - startX) + 2*t*(endX - controlX);
          const ty = 2*(1-t)*(controlY - startY) + 2*t*(endY - controlY);
          const angle = Math.atan2(ty, tx);

          ctx.save();
          ctx.translate(arrowX, arrowY);
          ctx.rotate(angle);
          ctx.beginPath();
          ctx.moveTo(-3, -3);
          ctx.lineTo(4, 0);
          ctx.lineTo(-3, 3);
          ctx.fillStyle = `rgba(0,0,0,${alpha + 0.1})`;
          ctx.fill();
          ctx.restore();
        });
        ctx.restore();
      }
    }
    ctx.setLineDash([]);
    ctx.lineDashOffset = 0;

    // 2. Draw Rotor Path, Trail & Axle
    ctx.strokeStyle = 'rgba(0,0,0,0.05)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(generatorX, generatorY, radius, 0, Math.PI * 2);
    ctx.stroke();

    // Central Axle (Rotating Hub)
    ctx.save();
    ctx.translate(generatorX, generatorY);
    ctx.rotate(currentAngle);
    
    // Hub detail
    ctx.fillStyle = '#f1f5f9';
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(0, 0, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    
    // Axle cross-section for rotation visual
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-6, 0);
    ctx.lineTo(6, 0);
    ctx.moveTo(0, -6);
    ctx.lineTo(0, 6);
    ctx.stroke();
    ctx.restore();

    // Rotation Sweep Trail
    if (isRunning) {
      const trailGradient = ctx.createConicGradient(currentAngle, generatorX, generatorY);
      trailGradient.addColorStop(0, 'rgba(0,0,0,0.1)');
      trailGradient.addColorStop(0.15, 'transparent');
      ctx.strokeStyle = trailGradient;
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.arc(generatorX, generatorY, radius, currentAngle - 0.6, currentAngle);
      ctx.stroke();
    }

    const endX = generatorX + Math.cos(currentAngle) * radius;
    const endY = generatorY + Math.sin(currentAngle) * radius;
    const startX = generatorX - Math.cos(currentAngle) * radius;
    const startY = generatorY - Math.sin(currentAngle) * radius;

    // Armature (Mechanical Bridge)
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#1a1a1a';
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(endX, endY);
    ctx.stroke();

    // Center bridge joint
    ctx.fillStyle = '#1a1a1a';
    ctx.beginPath();
    ctx.arc(generatorX, generatorY, 3, 0, Math.PI * 2);
    ctx.fill();

    // Conductors
    const normVoltage = Math.abs(Math.sin(currentAngle));
    const isPeak = normVoltage > 0.95;
    
    // Draw both conductor points
    [ {x: endX, y: endY}, {x: startX, y: startY} ].forEach((point) => {
      // 1. Peak Pulse Outer Glow & Subtle Flare
      if (isPeak) {
        const time = Date.now() / 150;
        const pulseSize = 14 + Math.sin(time) * 4;
        
        // Broad outer soft glow
        ctx.beginPath();
        ctx.arc(point.x, point.y, pulseSize + 4, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(245, 158, 11, 0.1)';
        ctx.fill();

        // Pulsing core aura
        ctx.beginPath();
        ctx.arc(point.x, point.y, pulseSize, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(245, 158, 11, 0.25)';
        ctx.fill();
        
        // Second sharper ring (synchronized)
        ctx.beginPath();
        ctx.arc(point.x, point.y, pulseSize * 0.6, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(245, 158, 11, 0.6)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        
        // Subtle "sparkle" flare lines
        ctx.strokeStyle = 'rgba(245, 158, 11, 0.3)';
        ctx.lineWidth = 1;
        for(let i=0; i<4; i++) {
          const rot = time + (i * Math.PI / 2);
          ctx.beginPath();
          ctx.moveTo(point.x + Math.cos(rot) * 6, point.y + Math.sin(rot) * 6);
          ctx.lineTo(point.x + Math.cos(rot) * (pulseSize + 2), point.y + Math.sin(rot) * (pulseSize + 2));
          ctx.stroke();
        }
      }

      // 2. Main Conductor Body
      ctx.beginPath();
      const pRadius = isPeak ? 8 + Math.abs(Math.sin(Date.now() / 150)) * 2 : 8;
      ctx.arc(point.x, point.y, pRadius, 0, Math.PI * 2);
      ctx.fillStyle = '#f59e0b';
      ctx.fill();
      ctx.strokeStyle = '#1a1a1a';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Dynamic shine highlight
      ctx.beginPath();
      ctx.arc(point.x - 2, point.y - 2, 2, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
      ctx.fill();
    });

    // Rotation Direction Indicator
    ctx.strokeStyle = 'rgba(0,0,0,0.2)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(generatorX, generatorY, radius + 20, currentAngle - 0.4, currentAngle - 0.1);
    ctx.stroke();
    
    // Arrowhead
    const arrowX = generatorX + Math.cos(currentAngle - 0.1) * (radius + 20);
    const arrowY = generatorY + Math.sin(currentAngle - 0.1) * (radius + 20);
    ctx.save();
    ctx.translate(arrowX, arrowY);
    ctx.rotate(currentAngle - 0.1);
    ctx.beginPath();
    ctx.moveTo(-3, -3);
    ctx.lineTo(3, 0);
    ctx.lineTo(-3, 3);
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.fill();
    ctx.restore();

    // Velocity vector 'v'
    const vx = -Math.sin(currentAngle) * 35;
    const vy = Math.cos(currentAngle) * 35;
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(endX, endY);
    ctx.lineTo(endX + vx, endY + vy);
    ctx.stroke();
    ctx.fillStyle = '#10b981';
    ctx.font = 'bold 11px Inter, sans-serif';
    ctx.fillText('v', endX + vx + 5, endY + vy + 5);

    // 3. Draw Graph
    const graphX = width < 640 ? 40 : 400;
    const graphY = width < 640 ? 380 : 160;
    const graphW = width < 640 ? width - 80 : width - 460;
    const graphH = 200;

    // --- Projection Line (The synchronization link) ---
    const currentVoltageY = graphY - Math.sin(currentAngle) * lengthRef.current * (graphH / 2.5);
    ctx.setLineDash([2, 4]);
    ctx.strokeStyle = 'rgba(230, 57, 70, 0.3)'; // Faded red
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(endX, endY);
    ctx.lineTo(graphX, currentVoltageY);
    ctx.stroke();
    ctx.setLineDash([]);
    // --- End Projection ---

    // Axes
    ctx.strokeStyle = '#d1d5db';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(graphX, graphY);
    ctx.lineTo(graphX + graphW, graphY);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(graphX, graphY - graphH / 2);
    ctx.lineTo(graphX, graphY + graphH / 2);
    ctx.stroke();

    // Waveform Output Label
    ctx.fillStyle = '#1a1a1a';
    ctx.globalAlpha = 0.4;
    ctx.font = 'bold 9px Inter, sans-serif';
    ctx.fillText('Waveform Output v0.8', graphX, graphY + graphH / 2 + 15);
    ctx.globalAlpha = 1.0;

    // 4. Draw Scale Markers
    ctx.setLineDash([2, 4]);
    ctx.strokeStyle = 'rgba(0,0,0,0.1)';
    ctx.lineWidth = 1;

    // +1.0 line
    const posMaxY = graphY - (graphH / 2.5);
    ctx.beginPath();
    ctx.moveTo(graphX, posMaxY);
    ctx.lineTo(graphX + graphW, posMaxY);
    ctx.stroke();

    // -1.0 line
    const negMaxY = graphY + (graphH / 2.5);
    ctx.beginPath();
    ctx.moveTo(graphX, negMaxY);
    ctx.lineTo(graphX + graphW, negMaxY);
    ctx.stroke();
    
    ctx.setLineDash([]);

    // Scale Labels
    ctx.fillStyle = '#1a1a1a';
    ctx.font = 'bold 8px Inter, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText('+1.0 Umax', graphX - 8, posMaxY + 3);
    ctx.fillText('0', graphX - 8, graphY + 3);
    ctx.fillText('-1.0 Umax', graphX - 8, negMaxY + 3);
    ctx.textAlign = 'left';

    // Sine Wave
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 3;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    for (let i = 0; i < currentHistory.length; i++) {
      const px = graphX + i;
      const py = graphY - currentHistory[i] * (graphH / 2.5);
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.stroke();

    // Tooltip dot
    if (currentHistory.length > 0) {
      const lastVal = currentHistory[currentHistory.length - 1];
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(graphX + currentHistory.length - 1, graphY - lastVal * (graphH / 2.5), 5, 0, Math.PI * 2);
      ctx.fill();
    }
  }, []);

  const animate = useCallback((time: number) => {
    if (isRunning) {
      angleRef.current += speed;
      flowOffsetRef.current = (flowOffsetRef.current + 0.5) % 25; // Continuous flow
      const val = Math.sin(angleRef.current) * lengthRef.current;
      historyRef.current.push(val);
      if (historyRef.current.length > maxHistory) {
        historyRef.current.shift();
      }
    }

    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        draw(ctx, canvas.width, canvas.height);
      }
    }

    // Force React re-render for UI updates (monitor values)
    setAngle(angleRef.current);
    setHistory([...historyRef.current]);

    requestRef.current = requestAnimationFrame(animate);
  }, [isRunning, speed, draw]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [animate]);

  // Handle Resize
  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current;
      if (canvas && canvas.parentElement) {
        canvas.width = canvas.parentElement.clientWidth;
        canvas.height = window.innerWidth < 640 ? 500 : 320;
      }
    };
    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const rawDeg = (angle * 180 / Math.PI) % 360;
  const deg = rawDeg < 0 ? 360 + rawDeg : rawDeg;
  const voltage = Math.sin(angle) * length;
  const explanation = getExplanation(deg);

  let quad = "I.";
  let phase = "Kladná ↑";
  if (deg < 90) { quad = "I."; phase = "Kladná ↑"; }
  else if (deg < 180) { quad = "II."; phase = "Kladná ↓"; }
  else if (deg < 270) { quad = "III."; phase = "Záporná ↑"; }
  else { quad = "IV."; phase = "Záporná ↓"; }

  const criticalPoint = Math.abs(voltage) > 0.95 || Math.abs(voltage) < 0.05;

  const [isDeepDiveOpen, setIsDeepDiveOpen] = useState(false);

  const getDetailedPhysics = (deg: number) => {
    if (deg >= 345 || deg <= 15) return {
      title: "Nulová linie (0°)",
      text: "Vodič se pohybuje rovnoběžně se siločárami magnetického pole. Nedochází k jejich 'protínání', a proto je indukované napětí nulové. Sin(0°) = 0."
    };
    if (deg > 15 && deg < 75) return {
      title: "Nárůst toku",
      text: "Vodič začíná pod úhlem řezat siločáry. Kolmá složka rychlosti roste, což zvyšuje rychlost změny magnetického toku ve smyčce."
    };
    if (deg >= 75 && deg <= 105) return {
      title: "Amplituda (90°)",
      text: "Vodič se pohybuje přesně kolmo na siločáry. V tomto okamžiku je efektivita indukce nejvyšší, protože vodič 'krájí' maximum siločár za jednotku času."
    };
    if (deg > 105 && deg < 165) return {
      title: "Pokles indukce",
      text: "Úhel se zmenšuje a vodič se vrací k pohybu, který je více rovnoběžný se siločárami. Hustota protínaných siločár klesá."
    };
    if (deg >= 165 && deg <= 195) return {
      title: "Reverze (180°)",
      text: "Průchod nulou. Vodič začíná vcházet do pole z opačné strany (relativně k pohybu), což způsobí změnu polarity indukovaného napětí."
    };
    if (deg > 195 && deg < 255) return {
      title: "Záporná vlna",
      text: "Narůstá napětí s opačnou polaritou. Fyzikálně se elektrony ve vodiči začínají pohybovat opačným směrem kvůli změně směru Lorentzoovy síly."
    };
    if (deg >= 255 && deg <= 285) return {
      title: "Záporné maximum (270°)",
      text: "Maximální záporná výchylka. Vodič opět řeže pole kolmo, ale v protisměru vůči prvnímu maximu."
    };
    return {
      title: "Uzavření periody",
      text: "Cyklus se blíží k 360°, kde se celý děj bude opakovat. Frekvence otáčení určuje, kolik takových period proběhne za sekundu (Hz)."
    };
  };

  const currentPhysics = getDetailedPhysics(deg);

  return (
    <div className="w-full flex flex-col h-full uppercase tracking-tight">
      <div className="flex-grow flex flex-col lg:flex-row relative">
        
        {/* Visualization Area */}
        <div className="flex-grow flex flex-col border-r border-black p-4 md:p-8 relative min-h-[400px]">
          <div className="flex-grow flex items-center justify-center relative">
            <canvas 
              ref={canvasRef} 
              className="w-full h-full max-h-[450px] cursor-crosshair touch-none"
            />
            <div className="absolute bottom-4 right-4 pointer-events-none hidden md:block">
              <span className="text-[9px] font-black uppercase tracking-[0.3em] opacity-20 rotate-90 origin-bottom-right translate-x-[-100%]">
                Waveform Output v0.8
              </span>
            </div>
          </div>
          
          <div className="h-24 md:h-32 border-t border-black bg-white -mx-4 md:-mx-8 -mb-4 md:-mb-8 relative overflow-hidden flex items-center justify-center p-6 mt-8">
            <div className="flex gap-4 items-start max-w-2xl">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40 whitespace-nowrap mt-1">Učitelský Postřeh /</span>
              <p className="text-[11px] leading-relaxed font-medium text-slate-600 italic">
                Pokud by se vodič nepohyboval v kruhu, ale jel by stále rovně kolmo na pole, napětí by bylo konstantní. Sinusovku z toho dělá právě to neustálé měnění úhlu alfa při rotaci.
              </p>
            </div>
          </div>
        </div>

        {/* Monitoring Area */}
        <div className="lg:w-80 flex flex-col bg-[#FDFCFB]">
          <div className="p-6 md:p-10 space-y-10">
            <div className="space-y-6">
              <h2 className="text-xs font-black uppercase tracking-[0.3em] border-b border-black pb-2 flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-black"></span>
                03. Monitoring
              </h2>
              <div className="grid grid-cols-1 gap-6">
                <div className="border border-black p-6 bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-transform hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                  <span className="text-[9px] font-black uppercase tracking-widest opacity-40 block mb-2">Indukované napětí [Ui]</span>
                  <div className="text-4xl font-serif italic">{voltage.toFixed(3)} <span className="text-xs uppercase font-sans font-black tracking-widest opacity-30">V</span></div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="border border-black p-4 bg-white">
                    <span className="text-[9px] font-black uppercase tracking-widest opacity-40 block mb-1">Úhel [α]</span>
                    <div className="text-2xl font-serif italic">{Math.round(deg)}°</div>
                  </div>
                  <div className="border border-black p-4 bg-white">
                    <span className="text-[9px] font-black uppercase tracking-widest opacity-40 block mb-1">Kvadrant</span>
                    <div className="text-2xl font-serif italic">{quad}</div>
                  </div>
                </div>

                <div className="border border-black p-4 bg-white">
                  <span className="text-[9px] font-black uppercase tracking-widest opacity-40 block mb-2">Aktuální Fáze</span>
                  <div className="text-sm font-black uppercase tracking-tighter">{phase}</div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="space-y-4">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={explanation}
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ 
                      opacity: 1, 
                      scale: 1,
                      backgroundColor: criticalPoint ? 'rgba(0,0,0,0.03)' : 'transparent',
                    }}
                    className="p-6 border-2 border-dashed border-black/10 rounded-sm min-h-[140px] flex flex-col justify-center transition-colors duration-300 relative"
                  >
                    <div className="absolute top-0 left-4 -translate-y-1/2 bg-[#FDFCFB] px-3">
                      <span className="text-[9px] font-black uppercase tracking-[0.2em] opacity-40">Status Log</span>
                    </div>
                    <p className="text-[11px] font-serif italic leading-relaxed text-slate-800">{explanation}</p>
                    {criticalPoint && (
                      <motion.div 
                        layoutId="critDot"
                        className="absolute bottom-2 right-2 w-2 h-2 bg-red-600 rounded-full animate-ping"
                      />
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Extra Physics Panel */}
              <div className="border-t border-black/10 pt-6">
                <button 
                  onClick={() => setIsDeepDiveOpen(!isDeepDiveOpen)}
                  className="w-full flex items-center justify-between group py-2"
                >
                  <div className="flex items-center gap-2">
                    <Beaker className="w-4 h-4 text-black opacity-30" />
                    <span className="text-[10px] font-black uppercase tracking-[0.2em]">Fyzikální Rozbor</span>
                  </div>
                  {isDeepDiveOpen ? <ChevronUp className="w-4 h-4 opacity-30" /> : <ChevronDown className="w-4 h-4 opacity-30" />}
                </button>
                
                <motion.div
                  initial={false}
                  animate={{ height: isDeepDiveOpen ? 'auto' : 0, opacity: isDeepDiveOpen ? 1 : 0 }}
                  className="overflow-hidden"
                >
                  <div className="pt-4 space-y-3">
                    <h4 className="text-[10px] font-black underline decoration-2 decoration-black/10 underline-offset-4">{currentPhysics.title}</h4>
                    <p className="text-[10px] leading-relaxed opacity-70 font-medium lowercase">
                      {currentPhysics.text}
                    </p>
                    <div className="pt-2">
                      <div className="w-full h-[1px] bg-black/5"></div>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Simulation;
