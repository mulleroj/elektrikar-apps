/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Play, Pause, Settings, BookOpen, RotateCcw, Zap, Share2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeCanvas } from 'qrcode.react';
import Simulation from './components/Simulation';
import Quiz from './components/Quiz';

export default function App() {
  const [speed, setSpeed] = useState(0.02);
  const [length, setLength] = useState(0.5);
  const [isRunning, setIsRunning] = useState(true);
  const [isShareOpen, setIsShareOpen] = useState(false);

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';

  return (
    <div className="min-h-screen bg-[#FDFCFB] text-[#1A1A1A] font-sans flex flex-col selection:bg-black selection:text-white">
      <div className="w-full max-w-[1400px] mx-auto border-x border-black min-h-screen flex flex-col">
        
        {/* Top Header Navigation */}
        <header className="w-full border-b border-black flex flex-col md:flex-row items-end justify-between px-6 md:px-10 py-6 md:py-10 bg-white">
          <div className="flex flex-col">
            <span className="text-[10px] font-black tracking-[0.3em] uppercase opacity-40 mb-3">Fyzikální Simulace / 01</span>
            <motion.h1 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-4xl md:text-7xl font-serif italic leading-none tracking-tight"
            >
              Sinusové Napětí
            </motion.h1>
          </div>
          <div className="text-right flex flex-col items-end mt-6 md:mt-0">
            <div className="hidden md:flex w-20 h-20 border border-black rounded-full items-center justify-center mb-6 animate-pulse">
              <span className="text-[10px] font-black tracking-widest uppercase rotate-12">Live View</span>
            </div>
            <p className="max-w-[240px] text-[11px] leading-relaxed uppercase tracking-wider opacity-60 text-right">
              Interaktivní výuková pomůcka pro vizualizaci elektromagnetické indukce v rotujícím vodiči.
            </p>
          </div>
        </header>

        {/* Main Workspace */}
        <main className="flex-grow grid grid-cols-1 xl:grid-cols-12 gap-0 border-b border-black">
          
          {/* Left Column: Theory & Controls */}
          <section className="xl:col-span-3 border-r border-black p-6 md:p-10 flex flex-col justify-between bg-white/50">
            <div className="space-y-12">
              <div>
                <h2 className="text-xs font-black uppercase tracking-[0.3em] mb-6 border-b border-black pb-2 flex items-center gap-2">
                  <span className="w-2 h-2 bg-black rounded-full"></span>
                  01. Teorie
                </h2>
                <p className="text-sm leading-relaxed mb-8 font-medium">
                  Indukované napětí <span className="italic font-serif">U<sub>i</sub></span> vzniká pohybem vodiče v magnetickém poli. Velikost závisí na úhlu pohybu <span className="italic font-serif">α</span>.
                </p>
                <div className="p-8 bg-black text-white rounded-sm transform -rotate-1 shadow-2xl relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <Zap className="w-12 h-12 text-white" />
                  </div>
                  <p className="text-[10px] uppercase tracking-[0.3em] opacity-50 mb-3 text-center font-bold">Základní Vztah</p>
                  <p className="text-2xl font-serif italic text-center relative z-10">U<sub>i</sub> = B · l · v · sin(α)</p>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-[10px] font-black uppercase tracking-widest opacity-40">Vysvětlivky symbolů</h3>
                <ul className="text-[10px] space-y-3 font-bold uppercase tracking-[0.15em]">
                  <li className="flex justify-between border-b border-black/5 pb-2"><span>B</span> <span className="opacity-60">Indukce [T]</span></li>
                  <li className="flex justify-between border-b border-black/5 pb-2"><span>l</span> <span className="opacity-60">Délka [m]</span></li>
                  <li className="flex justify-between border-b border-black/5 pb-2"><span>v</span> <span className="opacity-60">Rychlost [m/s]</span></li>
                  <li className="flex justify-between border-b border-black/5 pb-2"><span>α</span> <span className="opacity-60">Úhel [°]</span></li>
                </ul>
              </div>
            </div>

            <div className="mt-12 pt-12 border-t border-black/10">
              <h2 className="text-xs font-black uppercase tracking-[0.3em] mb-6 border-b border-black pb-2 flex items-center gap-2">
                <Settings className="w-3.5 h-3.5" />
                02. Kontrola
              </h2>
              <div className="space-y-8">
                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <label className="text-[10px] font-black uppercase tracking-widest opacity-50 text-slate-400">Rychlost [ω]</label>
                    <span className="text-[10px] font-mono font-bold bg-black text-white px-2 py-0.5 rounded">
                      {(speed * 10).toFixed(2)} rad/s
                    </span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="0.1" 
                    step="0.001" 
                    value={speed}
                    onChange={(e) => setSpeed(parseFloat(e.target.value))}
                    className="w-full h-[1px] bg-black/20 appearance-none cursor-pointer accent-black"
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <label className="text-[10px] font-black uppercase tracking-widest opacity-50 text-slate-400">Délka vodiče [l]</label>
                    <span className="text-[10px] font-mono font-bold bg-black text-white px-2 py-0.5 rounded">
                      {length.toFixed(2)} m
                    </span>
                  </div>
                  <input 
                    type="range" 
                    min="0.1" 
                    max="1.0" 
                    step="0.05" 
                    value={length}
                    onChange={(e) => setLength(parseFloat(e.target.value))}
                    className="w-full h-[1px] bg-black/20 appearance-none cursor-pointer accent-black"
                  />
                </div>

                <div className="grid grid-cols-1 gap-3">
                  <button 
                    onClick={() => setIsRunning(!isRunning)}
                    className={`w-full py-5 text-xs font-black uppercase tracking-[0.3em] transition-all border-2 border-black ${
                      isRunning 
                        ? 'bg-transparent text-black hover:bg-black hover:text-white' 
                        : 'bg-black text-white shadow-xl translate-y-[-2px]'
                    }`}
                  >
                    {isRunning ? 'Pause Engine' : 'Resume Engine'}
                  </button>
                  <button 
                    onClick={() => {
                      setSpeed(0.02);
                      setLength(0.5);
                    }}
                    className="w-full py-4 text-[9px] font-black uppercase tracking-[0.3em] opacity-40 hover:opacity-100 transition-opacity flex items-center justify-center gap-2"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Reset Params
                  </button>
                </div>
              </div>
            </div>
          </section>

          {/* Right Column: Visualization & Monitor */}
          <section className="xl:col-span-9 flex flex-col bg-white">
            <div className="flex-grow flex items-center justify-center relative overflow-hidden">
              <Simulation speed={speed} isRunning={isRunning} length={length} />
            </div>
          </section>

        </main>

        <Quiz />

        {/* Share Button & Modal */}
        <div className="fixed bottom-10 right-10 z-50">
          <button 
            onClick={() => setIsShareOpen(true)}
            className="w-14 h-14 bg-black text-white rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-transform group"
          >
            <Share2 className="w-6 h-6 group-hover:rotate-12 transition-transform" />
          </button>
        </div>

        <AnimatePresence>
          {isShareOpen && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm"
              onClick={() => setIsShareOpen(false)}
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 20 }}
                className="bg-white border border-black p-8 max-w-sm w-full relative"
                onClick={e => e.stopPropagation()}
              >
                <button 
                  onClick={() => setIsShareOpen(false)}
                  className="absolute top-4 right-4 p-2 hover:bg-black/5 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="text-center space-y-6">
                  <div>
                    <h3 className="text-2xl font-serif italic mb-2 tracking-tight">Sdílet Simulaci</h3>
                    <p className="text-[10px] uppercase tracking-[0.3em] opacity-50">Naskenujte pro otevření v mobilu</p>
                  </div>

                  <div className="bg-white p-4 border border-black/10 inline-block mx-auto shadow-inner">
                    <QRCodeCanvas 
                      value={currentUrl} 
                      size={200}
                      level="H"
                      includeMargin={true}
                    />
                  </div>

                  <div className="pt-4">
                    <div className="text-[10px] font-mono font-bold bg-[#FDFCFB] p-3 border border-black/5 break-all opacity-70">
                      {currentUrl}
                    </div>
                  </div>

                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(currentUrl);
                      alert('Odkaz zkopírován do schránky');
                    }}
                    className="w-full py-4 border-2 border-black text-[11px] font-black uppercase tracking-[0.2em] hover:bg-black hover:text-white transition-all"
                  >
                    Kopírovat Odkaz
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer Bar */}
        <footer className="h-16 w-full flex flex-col md:flex-row items-center justify-between px-10 text-[9px] font-black uppercase tracking-[0.3em] opacity-50 bg-white">
          <div className="py-2 md:py-0">Technical Institute for Electrical Engineering</div>
          <div className="hidden md:block py-2">Experimental Model No. 892-SIM-2024</div>
          <div className="py-2 md:py-0">All Calculations Computed in Real-Time</div>
        </footer>
      </div>
    </div>
  );
}
