/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { AreaChart, Area, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, ResponsiveContainer } from 'recharts';
import { Zap, Thermometer, Settings2, Activity, CheckCircle2, AlertTriangle, Trophy, Info, Lightbulb, BookOpen, GraduationCap, Share2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeSVG } from 'qrcode.react';

const App = () => {
  // --- STAV A KONSTANTY ---
  const [bias, setBias] = useState(0);
  const [amplitude, setAmplitude] = useState(0.8);
  const [activeTask, setActiveTask] = useState(0);
  const [completedTasks, setCompletedTasks] = useState<number[]>([]);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [view, setView] = useState<'lab' | 'theory'>('lab'); // 'lab' nebo 'theory'
  const [hoveredClass, setHoveredClass] = useState<string | null>(null);
  const [showShareModal, setShowShareModal] = useState(false);

  const shareUrl = process.env.APP_URL || (typeof window !== 'undefined' ? window.location.origin : '');

  const VCC = 1.8;
  const THRESHOLD = -1.0;

  // --- DATA PRO TEORII ---
  const theoryData = {
    A: {
      title: "Třída A",
      description: "Pracovní bod je uprostřed lineární části. Tranzistor vede proud po celou periodu signálu (360°).",
      pros: "Nejvyšší věrnost zvuku, žádné přechodové zkreslení.",
      cons: "Extrémní zahřívání, účinnost max. 25–50 %.",
      usage: "High-end audio, předzesilovače."
    },
    AB: {
      title: "Třída AB",
      description: "Pracovní bod je mírně nad bodem zániku. Tranzistor vede o něco více než polovinu periody.",
      pros: "Skvělý kompromis mezi věrností a účinností.",
      cons: "Složitější nastavení klidového proudu.",
      usage: "Drtivá většina domácích Hi-Fi zesilovačů."
    },
    B: {
      title: "Třída B",
      description: "Pracovní bod je přesně v bodě zániku. Tranzistor vede přesně polovinu periody (180°).",
      pros: "Vysoká účinnost (až 78 %), netopí v klidu.",
      cons: "Silné přechodové zkreslení v okolí nuly.",
      usage: "Dnes se samostatně téměř nepoužívá."
    },
    C: {
      title: "Třída C",
      description: "Pracovní bod je hluboko v nevodivé oblasti. Tranzistor vede jen krátké impulzy.",
      pros: "Vynikající účinnost (až 90 %).",
      cons: "Obrovské zkreslení, nepoužitelné pro audio.",
      usage: "Vysokofrekvenční vysílače s laděnými obvody."
    }
  };

  // --- DEFINICE VŠECH MOŽNÝCH ÚKOLŮ (50+) ---
  const ALL_TASKS = [
    // KATEGORIE 1: TŘÍDA A & HI-FI PURISMUS
    { title: "Třída A: Perfektní sinus", instruction: "Nastavte Bias na 0V a amplitudu na 0.5V. Sledujte nulové zkreslení.", check: (b: number, a: number, m: any) => b > -0.1 && b < 0.1 && a < 0.6 && !m.clipping && m.angle === 360, hint: "Bias na střed (0V), nízká amplituda." },
    { title: "Třída A: Maximální výkmit", instruction: "Nastavte Bias tak, aby amplituda 0.8V byla symetrická bez ořezu.", check: (b: number, a: number, m: any) => b > -0.2 && b < 0.0 && a > 0.75 && !m.clipping, hint: "Hledej bod, kde je modrá plocha nahoře i dole stejně daleko od hranic." },
    { title: "Třída A: Teplotní limit", instruction: "Dostaňte se na hranici tepelného stresu ve třídě A.", check: (b: number, a: number, m: any) => b > -0.2 && m.heat > 80, hint: "Vysoký Bias a vysoká amplituda." },
    { title: "Třída A: Nízké vybuzení", instruction: "Nastavte čistou třídu A při minimálním vybuzení (pod 0.2V).", check: (b: number, a: number, m: any) => b > -0.3 && a < 0.25, hint: "Stáhni Zap doleva." },
    { title: "Třída A: Symetrie", instruction: "Nastavte Bias přesně tak, aby byl výstup symetrický kolem 0.9V.", check: (b: number, a: number, m: any) => b > -0.15 && b < -0.05, hint: "Bias by měl být kolem -0.1V." },
    { title: "Třída A: Předzesilovač", instruction: "Simulujte předzesilovač: amplituda 0.3V, bezpečné teplo.", check: (b: number, a: number, m: any) => m.heat < 60 && a < 0.4 && b > -0.3, hint: "Stáhni oba posuvníky mírně doleva." },
    { title: "Třída A: Limitace zdroje", instruction: "Zvyšte amplitudu ve třídě A tak, aby začala limitace nahoře.", check: (b: number, a: number, m: any) => b > -0.2 && m.clipping, hint: "Amplituda doprava, dokud se vrchol nezarovná o červenou linku." },
    { title: "Třída A: Minimální zkreslení", instruction: "Udržujte třídu A s úhlem 360° při amplitudě 1.0V.", check: (b: number, a: number, m: any) => b > -0.2 && a > 0.95 && m.angle === 360, hint: "Bias musí být dostatečně vysoko." },
    { title: "Třída A: Výkonová rezerva", instruction: "Nastavte maximální možnou amplitudu bez limitace ve třídě A.", check: (b: number, a: number, m: any) => a > 0.8 && a < 0.9 && b > -0.2 && !m.clipping, hint: "Jemně ladit Zap." },
    { title: "Třída A: Stabilita", instruction: "Nastavte Bias na 0.2V a pozorujte posun pracovního bodu.", check: (b: number, a: number, m: any) => b > 0.15, hint: "Bias úplně doprava." },

    // KATEGORIE 2: TŘÍDA AB & KOMPROMISY
    { title: "Třída AB: Úhel 270°", instruction: "Nastavte pracovní bod tak, aby úhel otevření byl přesně kolem 270°.", check: (b: number, a: number, m: any) => m.angle > 260 && m.angle < 280, hint: "Bias posuňte kousek doleva od třídy A." },
    { title: "Třída AB: Přechodová oblast", instruction: "Najděte bod, kdy se třída AB začne blížit čisté třídě B (úhel 200°).", check: (b: number, a: number, m: any) => m.angle > 190 && m.angle < 210, hint: "Bias blíž k -1.0V." },
    { title: "Třída AB: Efektivní Hi-Fi", instruction: "Dosáhněte účinnosti nad 55 % v režimu AB.", check: (b: number, a: number, m: any) => b < -0.5 && m.eff > 55, hint: "Sniž Bias, spaluj méně proudu." },
    { title: "Třída AB: Bezpečná teplota", instruction: "Udržujte režim AB s úhlem 240° a teplem pod 40 %.", check: (b: number, a: number, m: any) => m.angle > 230 && m.angle < 250 && m.heat < 40, hint: "Kombinace středního Biasu a rozumné Amplitudy." },
    { title: "Třída AB: Výkonový test", instruction: "Nastavte AB s vysokou amplitudou (nad 1.5V) bez limitace.", check: (b: number, a: number, m: any) => a > 1.45 && !m.clipping && m.angle < 300, hint: "Pozor na červenou linku!" },
    { title: "Třída AB: Zlatý střed", instruction: "Nastavte Bias přesně na -0.5V.", check: (b: number, a: number, m: any) => b > -0.55 && b < -0.45, hint: "Sleduj hodnotu v modrém poli." },
    { title: "Třída AB: Mírné zkreslení", instruction: "Dovolte mírné oříznutí spodní části periody v režimu AB.", check: (b: number, a: number, m: any) => m.angle < 350 && m.angle > 300, hint: "Bias mírně doleva." },
    { title: "Třída AB: Dynamika", instruction: "Měňte amplitudu od 0.5V do 1.5V v režimu AB a sledujte úhel.", check: (b: number, a: number, m: any) => a > 1.4 && m.angle < 340, hint: "Rozkývejte Zap." },
    { title: "Třída AB: Chlazení", instruction: "Snižte tepelný stres na minimum při zachování úhlu 220°.", check: (b: number, a: number, m: any) => m.angle > 210 && m.angle < 230 && m.heat < 35, hint: "Hledej rovnováhu." },
    { title: "Třída AB: Audiofil", instruction: "Nastavte úhel 300° pro co nejvěrnější AB zvuk.", check: (b: number, a: number, m: any) => m.angle > 290 && m.angle < 310, hint: "Bias blíž ke třídě A." },

    // KATEGORIE 3: TŘÍDA B & ÚČINNOST
    { title: "Třída B: Bod zániku", instruction: "Nastavte Bias přesně na -1.0V.", check: (b: number, a: number, m: any) => b > -1.02 && b < -0.98, hint: "To je teoretický bod třídy B." },
    { title: "Třída B: Poloviční sinus", instruction: "Ve třídě B (Bias -1.0V) sledujte úhel otevření 180°.", check: (b: number, a: number, m: any) => m.angle > 175 && m.angle < 185, hint: "Tranzistor vede přesně půlku času." },
    { title: "Třída B: Účinnost 70 %", instruction: "Dosáhněte účinnosti 70 % ve třídě B.", check: (b: number, a: number, m: any) => m.eff >= 70 && m.angle < 190, hint: "Vysoká amplituda je klíčová." },
    { title: "Třída B: Nulový klidový proud", instruction: "Sledujte, že při nulové amplitudě ve třídě B je teplo 0 %.", check: (b: number, a: number, m: any) => m.angle < 190 && a < 0.2 && m.heat < 5, hint: "Ve třídě B tranzistor v klidu netopí." },
    { title: "Třída B: Limitace špiček", instruction: "Zvyšte amplitudu ve třídě B na maximum (2.5V).", check: (b: number, a: number, m: any) => b < -0.95 && a > 2.4, hint: "Drsné ořezání nahoře." },
    { title: "Třída B: Přechodové zkreslení", instruction: "Nastavte Bias na -1.1V a sledujte 'díru' v signálu.", check: (b: number, a: number, m: any) => b < -1.05 && b > -1.15, hint: "Tohle v Hi-Fi nechceš." },
    { title: "Třída B: Optimální buzení", instruction: "Nastavte amplitudu 1.2V při Biasu -1.0V.", check: (b: number, a: number, m: any) => b > -1.05 && b < -0.95 && a > 1.1 && a < 1.3, hint: "Standardní nastavení kategorie." },
    { title: "Třída B: Ekonomický režim", instruction: "Udržujte třídu B s teplem pod 20 %.", check: (b: number, a: number, m: any) => m.angle < 190 && m.heat < 20, hint: "Nižší amplituda šetří energii." },
    { title: "Třída B: Laborant", instruction: "Nastavte úhel otevření 180° při amplitudě 0.8V.", check: (b: number, a: number, m: any) => m.angle > 175 && m.angle < 185 && a > 0.7 && a < 0.9, hint: "Bias na -1.0V." },
    { title: "Třída B: Max. účinnost", instruction: "Vytáhněte účinnost nad 75 % v čisté třídě B.", check: (b: number, a: number, m: any) => m.eff > 75 && m.angle < 190, hint: "Zapni to naplno!" },

    // KATEGORIE 4: TŘÍDA C & VYSOKÉ FREKVENCE
    { title: "Třída C: Úzké impulzy", instruction: "Nastavte úhel otevření pod 90°.", check: (b: number, a: number, m: any) => m.angle < 90 && m.angle > 10, hint: "Bias hodně doleva, amplituda střední." },
    { title: "Třída C: Extrémní účinnost", instruction: "Dosáhněte účinnosti nad 90 %.", check: (b: number, a: number, m: any) => m.eff >= 90, hint: "Bias nadoraz doleva, Amplituda doprava." },
    { title: "Třída C: Vysílač", instruction: "Nastavte úhel 120° pro optimální vysílací režim.", check: (b: number, a: number, m: any) => m.angle > 110 && m.angle < 130, hint: "Bias kolem -1.3V." },
    { title: "Třída C: Minimální vedení", instruction: "Nastavte nejmenší detekovatelný zákmrt (úhel pod 45°).", check: (b: number, a: number, m: any) => m.angle < 45 && m.angle > 5, hint: "Skoro vypnutý tranzistor." },
    { title: "Třída C: Vysoký výkon", instruction: "Ve třídě C nastavte amplitudu nad 2.0V.", check: (b: number, a: number, m: any) => b < -1.1 && a > 2.0, hint: "Silné impulzy na výstupu." },
    { title: "Třída C: Chladný provoz", instruction: "Udržujte třídu C s teplem pod 10 %.", check: (b: number, a: number, m: any) => b < -1.1 && m.heat < 10, hint: "Krátké impulzy hřejí minimálně." },
    { title: "Třída C: Rezonance", instruction: "Nastavte Bias -1.5V a Amplitudu 1.5V.", check: (b: number, a: number, m: any) => b < -1.45 && a > 1.45, hint: "Typické nastavení pro RF stupně." },
    { title: "Třída C: Šetřič energie", instruction: "Dosáhněte stavu, kdy účinnost je 10x vyšší než teplo.", check: (b: number, a: number, m: any) => m.eff > m.heat * 10, hint: "Ponořte se hluboko do třídy C." },
    { title: "Třída C: Inženýr", instruction: "Nastavte úhel přesně 100°.", check: (b: number, a: number, m: any) => m.angle > 95 && m.angle < 105, hint: "Jemně s Biasem." },
    { title: "Třída C: Teoretik", instruction: "Nastavte Bias na -2.0V a pozorujte vypnutý stav.", check: (b: number, a: number, m: any) => b < -1.9, hint: "Absolutní ticho." },

    // KATEGORIE 5: LIMITACE A SMÍŠENÉ
    { title: "Limitace: Oboustranná", instruction: "Nastavte signál tak, aby byl oříznut nahoře (Vcc) i dole (0V).", check: (b: number, a: number, m: any) => m.clipping && m.angle < 360, hint: "Obrovská amplituda, Bias kolem 0V." },
    { title: "Limitace: Čistý řez", instruction: "Dosáhněte limitace nahoře přesně při úhlu 360°.", check: (b: number, a: number, m: any) => m.clipping && m.angle === 360, hint: "Třída A vytočená na max." },
    { title: "Inženýrská výzva: 50/50", instruction: "Nastavte stav, kdy účinnost i teplo jsou přesně 50 %.", check: (b: number, a: number, m: any) => m.eff > 48 && m.eff < 52 && m.heat > 48 && m.heat < 52, hint: "Hledej bod zlomu mezi A a AB." },
    { title: "Inženýrská výzva: Max. teplo", instruction: "Způsobte tranzistoru co největší tepelné utrpení.", check: (b: number, a: number, m: any) => m.heat > 90, hint: "Třída A, nízká amplituda - vše se pálí na teplo." },
    { title: "Inženýrská výzva: Eko-HiFi", instruction: "Nastavte úhel 220° při účinnosti nad 60 %.", check: (b: number, a: number, m: any) => m.angle > 210 && m.angle < 230 && m.eff > 60, hint: "Vysoké vybuzení v režimu AB." },
    { title: "Diagnostika: Podpětí", instruction: "Sledujte chování při Biasu pod -1.8V.", check: (b: number, a: number, m: any) => b < -1.8, hint: "Tranzistor skoro neotevře." },
    { title: "Diagnostika: Přebuzení", instruction: "Nastavte amplitudu 2.5V a Bias 0.5V.", check: (b: number, a: number, m: any) => a > 2.4 && b > 0.4, hint: "Totální destrukce signálu." },
    { title: "Zkouška: 240 stupňů", instruction: "Nastavte úhel otevření přesně na 240°.", check: (b: number, a: number, m: any) => m.angle > 235 && m.angle < 245, hint: "Hledej v režimu AB." },
    { title: "Zkouška: Účinnost 33 %", instruction: "Nastavte systém na účinnost přesně 33 %.", check: (b: number, a: number, m: any) => m.eff > 31 && m.eff < 35, hint: "Nižší vybuzení ve třídě A." },
    { title: "Absolutorium: Balanc", instruction: "Nastavte Bias -0.4V a Amplitudu 1.4V.", check: (b: number, a: number, m: any) => b > -0.45 && b < -0.35 && a > 1.35 && a < 1.45, hint: "Zadejte přesné hodnoty." },
  ];

  // --- LOGIKA VÝBĚRU ÚKOLŮ ---
  const tasks = useMemo(() => {
    // Rozdělíme úkoly do 5 balíčků po 10
    const chunks = [];
    for (let i = 0; i < 50; i += 10) {
      chunks.push(ALL_TASKS.slice(i, i + 10));
    }
    // Z každého balíčku vybereme jeden náhodný
    return chunks.map((chunk, idx) => {
      const randomTask = chunk[Math.floor(Math.random() * chunk.length)];
      return { ...randomTask, id: idx };
    });
  }, []); // Spustí se pouze při načtení/aktualizaci

  // --- VÝPOČETNÍ JÁDRO ---
  const { data, metrics } = useMemo(() => {
    const points = [];
    let clipping = false;
    let conductionCount = 0;

    for (let i = 0; i <= 100; i++) {
      const x = (i / 100) * 4 * Math.PI;
      const input = Math.sin(x) * amplitude;
      let output = input + (bias - THRESHOLD);
      if (output > VCC) {
        output = VCC;
        clipping = true;
      }
      if (output < 0) output = 0;

      points.push({ 
        time: i, 
        vstup: parseFloat(input.toFixed(2)), 
        vystup: parseFloat(output.toFixed(2)) 
      });
      if (output > 0) conductionCount++;
    }

    const angle = Math.round((conductionCount / 101) * 360);
    let eff = 0;
    if (bias > -0.4) eff = (amplitude / 2.5) * 45 + 5;
    else if (bias > -1.1) eff = 50 + (amplitude / 2.5) * 25 - (bias + 0.5) * 10;
    else eff = 75 + (amplitude / 2.5) * 15;
    
    eff = Math.min(Math.max(Math.round(eff), 5), 95);

    return { data: points, metrics: { angle, eff, clipping, heat: 100 - eff } };
  }, [bias, amplitude]);

  // --- DATA PRO POROVNÁNÍ TŘÍD (TEORIE) ---
  const theoryChartData = useMemo(() => {
    return Array.from({ length: 41 }, (_, i) => {
      const vin = (i - 20) / 10; // -2.0 až 2.0
      // Idealizovaný přenos
      const outA = vin + 1.2; 
      const outB = vin; 
      const outC = vin - 0.8;
      
      const clamp = (v: number) => Math.max(0, Math.min(VCC, v));
      
      return { 
        vin: vin.toFixed(1), 
        A: parseFloat(clamp(outA).toFixed(2)), 
        B: parseFloat(clamp(outB).toFixed(2)), 
        C: parseFloat(clamp(outC).toFixed(2)) 
      };
    });
  }, []);

  const validateTask = () => {
    if (tasks[activeTask].check(bias, amplitude, metrics)) {
      if (!completedTasks.includes(activeTask)) {
        setCompletedTasks([...completedTasks, activeTask]);
      }
      setFeedback({ type: 'success', text: 'Skvěle! Úkol splněn.' });
    } else {
      setFeedback({ type: 'error', text: 'Zatím to není ono.' });
    }
  };

  const currentClass = bias > -0.3 ? "A" : bias > -0.9 ? "AB" : bias > -1.1 ? "B" : "C";
  const activeTheory = theoryData[currentClass as keyof typeof theoryData];

  return (
    <div className="flex flex-col h-screen bg-[#f8fafc] font-sans text-[#0f172a] overflow-hidden">
      {/* HEADER - Professional Polish: 64px height, white bg, border-bottom */}
      <header className="h-16 bg-white border-b border-[#e2e8f0] px-6 flex justify-between items-center shrink-0">
        <div className="flex items-center gap-3">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-[#2563eb] p-2 rounded-lg text-white"
          >
            <Activity className="w-5 h-5 stroke-[2.5]" />
          </motion.div>
          <h1 className="text-lg font-extrabold tracking-tight">
            Laboratoř zesilovačů <span className="text-[#2563eb]">v2.5</span>
          </h1>
        </div>
        
        <div className="flex bg-[#f1f5f9] p-1 rounded-xl border border-[#e2e8f0]">
          <button 
            onClick={() => setView('lab')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${view === 'lab' ? 'bg-white shadow-sm text-[#2563eb]' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Laboratoř
          </button>
          <button 
            onClick={() => setView('theory')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${view === 'theory' ? 'bg-white shadow-sm text-[#2563eb]' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Teorie
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowShareModal(true)}
            className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-[#e2e8f0] text-xs font-bold text-slate-600 hover:bg-slate-50 transition-all hover:shadow-sm"
          >
            <Share2 className="w-3.5 h-3.5" /> Sdílet
          </button>
          <div className="flex items-center gap-2 bg-[#ecfdf5] px-3 py-1.5 rounded-full border border-[#d1fae5]">
            <span className="text-xs font-bold text-[#059669]">Progres: {completedTasks.length}/{tasks.length}</span>
          </div>
        </div>

        {/* Share Modal */}
        <AnimatePresence>
          {showShareModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowShareModal(false)}
                className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ scale: 0.9, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 20 }}
                className="relative bg-white w-full max-w-sm rounded-3xl shadow-2xl p-8 flex flex-col items-center text-center overflow-hidden"
              >
                <button 
                  onClick={() => setShowShareModal(false)}
                  className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-all"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="bg-[#2563eb]/10 p-3 rounded-2xl mb-4">
                  <Share2 className="w-6 h-6 text-[#2563eb]" />
                </div>
                
                <h3 className="text-xl font-extrabold mb-2 tracking-tight">Sdílet laboratoř</h3>
                <p className="text-sm text-slate-500 mb-8 px-4">Studenti se mohou připojit naskenováním QR kódu níže.</p>

                <div className="p-6 bg-white border-4 border-[#f1f5f9] rounded-3xl shadow-inner mb-6">
                  <QRCodeSVG 
                    value={shareUrl} 
                    size={200}
                    level="H"
                    includeMargin={false}
                    fgColor="#0f172a"
                  />
                </div>

                <div className="w-full space-y-3">
                  <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-3 flex items-center justify-between gap-3 group">
                    <span className="text-[11px] font-mono font-bold text-slate-500 truncate">{shareUrl}</span>
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText(shareUrl);
                        // Optional: could add a "Copied!" state
                      }}
                      className="bg-white border border-[#e2e8f0] px-3 py-1.5 rounded-lg text-[10px] font-black text-[#2563eb] shadow-sm hover:bg-white/50 active:scale-95 transition-all"
                    >
                      KOPÍROVAT
                    </button>
                  </div>
                </div>

                <div className="mt-8 flex items-center gap-2 text-[#10b981] bg-[#ecfdf5] px-4 py-2 rounded-full border border-[#d1fae5]">
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="text-[10px] font-extrabold uppercase tracking-wider">Odkaz je připraven</span>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* LEVÝ PANEL - Professional Polish: 300px width, white bg, border-right */}
        <aside className="w-[300px] bg-white border-r border-[#e2e8f0] overflow-y-auto p-5 space-y-5 shrink-0 flex flex-col">
          <AnimatePresence mode="wait">
            {view === 'lab' ? (
              <motion.div 
                key="tasks"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <h2 className="text-[11px] font-extrabold uppercase text-[#94a3b8] tracking-[0.1em] mb-4">
                  Aktuální Úkoly
                </h2>
                {tasks.map((task, idx) => (
                  <motion.div 
                    key={idx}
                    whileHover={{ y: -1 }}
                    onClick={() => { setActiveTask(idx); setFeedback(null); }}
                    className={`p-3 rounded-xl border-2 transition-all cursor-pointer ${
                      activeTask === idx ? 'border-[#2563eb] bg-[#eff6ff]' : 
                      completedTasks.includes(idx) ? 'border-transparent bg-[#f0fdf4]' :
                      'border-transparent hover:border-[#e2e8f0] bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-[10px] font-bold uppercase ${
                        completedTasks.includes(idx) ? 'text-[#10b981]' : 
                        activeTask === idx ? 'text-[#2563eb]' : 'text-[#94a3b8]'
                      }`}>
                        {completedTasks.includes(idx) ? 'HOTOVO' : idx === activeTask ? 'AKTIVNÍ' : 'ZAMČENO'}
                      </span>
                      {completedTasks.includes(idx) && <CheckCircle2 className="w-3.5 h-3.5 text-[#10b981] stroke-[3]" />}
                    </div>
                    <h3 className={`text-sm font-bold leading-tight ${!completedTasks.includes(idx) && activeTask !== idx ? 'text-[#64748b]' : ''}`}>
                      {idx + 1}. {task.title.split(': ')[1]}
                    </h3>
                    {activeTask === idx && (
                      <div className="space-y-3 pt-2">
                        <p className="text-[11px] text-[#475569] leading-relaxed">{task.instruction}</p>
                        <button 
                          onClick={(e) => { e.stopPropagation(); validateTask(); }}
                          className="w-full py-2 bg-[#2563eb] text-white rounded-lg text-[11px] font-bold hover:bg-[#1d4ed8] active:scale-95 transition-all shadow-sm"
                        >
                          Zkontrolovat
                        </button>
                        {feedback && (
                          <motion.div 
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            className={`text-[10px] p-2 rounded border flex gap-2 ${
                            feedback.type === 'success' ? 'bg-[#f0fdf4] border-[#d1fae5] text-[#166534]' : 'bg-[#fffbeb] border-[#fef3c7] text-[#92400e]'
                          }`}>
                            <span className="shrink-0">{feedback.type === 'success' ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}</span>
                            <span>{feedback.type === 'success' ? feedback.text : task.hint}</span>
                          </motion.div>
                        )}
                      </div>
                    )}
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <motion.div 
                key="theory"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <h2 className="text-[11px] font-extrabold uppercase text-[#94a3b8] tracking-[0.1em] mb-4">
                  Encyklopedie tříd
                </h2>

                {/* Porovnávací Graf ve Sidebar (Teorie) */}
                <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-3 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-extrabold text-[#64748b] uppercase tracking-wider">Charakteristiky</span>
                    <Activity className="w-3 h-3 text-[#94a3b8]" />
                  </div>
                  <div className="h-32 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={theoryChartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                        <XAxis dataKey="vin" hide />
                        <YAxis hide domain={[0, VCC]} />
                        <Line 
                          type="monotone" 
                          dataKey="A" 
                          stroke="#3b82f6" 
                          strokeWidth={hoveredClass === 'A' ? 4 : 2} 
                          dot={false} 
                          strokeOpacity={hoveredClass && hoveredClass !== 'A' ? 0.2 : 1}
                          animationDuration={300}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="B" 
                          stroke="#10b981" 
                          strokeWidth={hoveredClass === 'B' ? 4 : 2} 
                          dot={false} 
                          strokeOpacity={hoveredClass && hoveredClass !== 'B' ? 0.2 : 1}
                          animationDuration={300}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="C" 
                          stroke="#ef4444" 
                          strokeWidth={hoveredClass === 'C' ? 4 : 2} 
                          dot={false} 
                          strokeOpacity={hoveredClass && hoveredClass !== 'C' ? 0.2 : 1}
                          animationDuration={300}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  {/* Interaktivní Legenda */}
                  <div className="flex justify-between gap-1">
                    {[
                      { id: 'A', color: 'bg-[#3b82f6]', label: 'Třída A' },
                      { id: 'B', color: 'bg-[#10b981]', label: 'Třída B' },
                      { id: 'C', color: 'bg-[#ef4444]', label: 'Třída C' }
                    ].map(item => (
                      <div 
                        key={item.id}
                        onMouseEnter={() => setHoveredClass(item.id)}
                        onMouseLeave={() => setHoveredClass(null)}
                        className={`flex flex-col items-center flex-1 p-1.5 rounded-lg border transition-all cursor-default ${
                          hoveredClass === item.id ? 'bg-white border-[#cbd5e1] shadow-sm' : 'border-transparent'
                        }`}
                      >
                        <div className={`w-full h-1 ${item.color} rounded-full mb-1`}></div>
                        <span className="text-[9px] font-extrabold text-[#64748b] leading-none">{item.label}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="p-5 border border-[#e2e8f0] rounded-2xl shadow-sm">
                    <h3 className="text-lg font-extrabold mb-1">{activeTheory.title}</h3>
                    <p className="text-xs text-[#64748b] leading-relaxed">{activeTheory.description}</p>
                  </div>
                  <div className="space-y-4 px-1">
                    <div>
                      <h4 className="text-[10px] font-extrabold uppercase text-[#10b981] mb-1 flex items-center gap-1.5">
                        Přednosti
                      </h4>
                      <p className="text-xs text-[#475569]">{activeTheory.pros}</p>
                    </div>
                    <div>
                      <h4 className="text-[10px] font-extrabold uppercase text-[#ef4444] mb-1 flex items-center gap-1.5">
                        Slabiny
                      </h4>
                      <p className="text-xs text-[#475569]">{activeTheory.cons}</p>
                    </div>
                    <div className="p-3 bg-[#f8fafc] rounded-xl border border-[#e2e8f0]">
                      <h4 className="text-[10px] font-extrabold uppercase text-[#94a3b8] mb-1">Typické použití</h4>
                      <p className="text-xs font-bold text-[#1e293b]">{activeTheory.usage}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          <div className="bg-[#0f172a] text-white p-5 rounded-2xl space-y-4 mt-auto shadow-xl">
            <h3 className="text-[10px] font-black uppercase text-[#94a3b8] tracking-widest">Status Systému</h3>
            <div className="flex justify-between items-end">
              <div>
                <div className="text-2xl font-black text-[#60a5fa]">Třída {currentClass}</div>
              </div>
              <div className="text-right">
                <div className="text-lg font-mono font-bold">{metrics.angle}°</div>
              </div>
            </div>
            <div className="space-y-2">
              <div className="h-1.5 bg-[#334155] rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${metrics.eff}%` }}
                  className="h-full bg-[#10b981] transition-all duration-300"
                ></motion.div>
              </div>
              <div className="flex justify-between text-[10px] font-extrabold">
                <span className="text-[#10b981] uppercase">Účinnost {metrics.eff}%</span>
                <span className="text-[#f87171] uppercase">Ztráty {metrics.heat}%</span>
              </div>
            </div>
          </div>
        </aside>

        {/* PRAVÝ PANEL - Professional Polish: 24px padding, gap 24px */}
        <main className="flex-1 flex flex-col p-6 overflow-y-auto bg-[#f8fafc] gap-6">
          <AnimatePresence mode="wait">
            <motion.div 
              key={view}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="flex-1 flex flex-col gap-6"
            >
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-[#e2e8f0] flex-1 flex flex-col min-h-[500px]">
                <div className="flex justify-between items-center mb-5">
                  <div>
                    <h2 className="text-xl font-extrabold tracking-tight">Virtuální Osciloskop</h2>
                    <p className="text-xs text-[#64748b] font-medium">Monitoring Vstup/Výstup (Vcc = 1.8V)</p>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-0.5 bg-[#cbd5e1] border-b border-[#94a3b8] border-dashed"></div>
                      <span className="text-[10px] font-extrabold text-[#64748b] uppercase">Vstup</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-1 bg-[#2563eb] rounded-full"></div>
                      <span className="text-[10px] font-extrabold text-[#2563eb] uppercase">Výstup</span>
                    </div>
                  </div>
                </div>

                {/* Oscilloscope Background - Professional Polish style */}
                <motion.div 
                  initial={{ scale: 0.98, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="flex-1 min-h-[300px] relative bg-[#0f172a] rounded-2xl p-4 overflow-hidden border border-[#1e293b]"
                >
                  <div className="absolute inset-0 pointer-events-none opacity-20">
                    <div className="absolute top-[20%] w-full h-[1px] bg-[#94a3b8]"></div>
                    <div className="absolute top-[40%] w-full h-[1px] bg-[#94a3b8]"></div>
                    <div className="absolute top-[50%] w-full h-[1px] bg-[#94a3b8] opacity-50"></div>
                    <div className="absolute top-[60%] w-full h-[1px] bg-[#94a3b8]"></div>
                    <div className="absolute top-[80%] w-full h-[1px] bg-[#94a3b8]"></div>
                    <div className="absolute left-[25%] h-full w-[1px] bg-[#94a3b8]"></div>
                    <div className="absolute left-[50%] h-full w-[1px] bg-[#94a3b8]"></div>
                    <div className="absolute left-[75%] h-full w-[1px] bg-[#94a3b8]"></div>
                  </div>
                  
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={data}>
                      <defs>
                        <linearGradient id="vystupGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#2563eb" stopOpacity={0.6}/>
                          <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid stroke="rgba(148,163,184,0.1)" vertical={false} />
                      <XAxis dataKey="time" hide />
                      <YAxis domain={[-2.5, 2.5]} hide />
                      <Tooltip 
                        contentStyle={{ borderRadius: '12px', border: '1px solid #1e293b', background: '#0f172a', color: '#fff', fontSize: '11px' }}
                      />
                      <ReferenceLine y={VCC} stroke="#ef4444" strokeDasharray="4 4" label={{ value: 'LIMITACE (+1.8V)', position: 'insideTopRight', fill: '#ef4444', fontSize: 10, fontWeight: 'bold' }} />
                      <Area 
                        type="monotone" 
                        dataKey="vystup" 
                        stroke="#2563eb" 
                        strokeWidth={3} 
                        fill="url(#vystupGrad)" 
                        animationDuration={0} 
                        isAnimationActive={false} 
                      />
                      <Area 
                        type="monotone" 
                        dataKey="vstup" 
                        stroke="#94a3b8" 
                        strokeWidth={1} 
                        strokeDasharray="4 4" 
                        fill="transparent"
                        animationDuration={0} 
                        isAnimationActive={false} 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </motion.div>

                {/* OVLÁDÁNÍ - Slider container style from Professional Polish */}
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mt-6">
                  <div className="space-y-6 bg-[#f1f5f9] p-6 rounded-2xl border border-[#e2e8f0]">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <label className="text-[11px] font-extrabold uppercase text-[#64748b] tracking-widest flex items-center gap-2">
                          <Settings2 className="w-3.5 h-3.5" /> Pracovní bod (Bias)
                        </label>
                        <span className="text-xs font-mono font-extrabold text-[#2563eb]">
                          {(bias + 1).toFixed(2)} V
                        </span>
                      </div>
                      <input 
                        type="range" min="-2" max="0.5" step="0.01" value={bias} 
                        onChange={(e) => { setBias(parseFloat(e.target.value)); setFeedback(null); }}
                        className="w-full"
                      />
                      <div className="flex justify-between text-[9px] font-extrabold text-[#94a3b8] mt-2 uppercase tracking-tight">
                        <span className={currentClass === 'C' ? 'text-[#2563eb]' : ''}>Třída C</span>
                        <span className={currentClass === 'B' ? 'text-[#2563eb]' : ''}>Třída B</span>
                        <span className={currentClass === 'AB' ? 'text-[#2563eb]' : ''}>Třída AB</span>
                        <span className={currentClass === 'A' ? 'text-[#2563eb]' : ''}>Třída A</span>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <label className="text-[11px] font-extrabold uppercase text-[#64748b] tracking-widest flex items-center gap-2">
                          <Zap className="w-3.5 h-3.5" /> Vybuzení (Amplituda)
                        </label>
                        <span className="text-xs font-mono font-extrabold text-[#10b981]">
                          {amplitude.toFixed(2)} V
                        </span>
                      </div>
                      <input 
                        type="range" min="0.1" max="2.5" step="0.01" value={amplitude} 
                        onChange={(e) => { setAmplitude(parseFloat(e.target.value)); setFeedback(null); }}
                        className="w-full range-accent-success"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] flex flex-col items-center justify-center text-center">
                      <div className="text-[9px] font-extrabold text-[#94a3b8] uppercase mb-2">Teplota</div>
                      <motion.div
                        animate={metrics.heat > 60 ? { scale: [1, 1.1, 1] } : {}}
                        transition={{ repeat: Infinity, duration: 1 }}
                      >
                        <Thermometer className={`w-5 h-5 mb-1 ${metrics.heat > 60 ? 'text-[#ef4444]' : 'text-[#10b981]'}`} />
                      </motion.div>
                      <div className="text-[11px] font-bold">{metrics.heat > 60 ? 'KRITICKÝ' : 'OPTIMÁLNÍ'}</div>
                    </div>
                    <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] flex flex-col items-center justify-center text-center">
                      <div className="text-[9px] font-extrabold text-[#94a3b8] uppercase mb-2">Zkreslení</div>
                      <div className={`text-[13px] font-black ${metrics.clipping ? 'text-[#ef4444]' : metrics.angle < 360 ? 'text-[#f59e0b]' : 'text-[#10b981]'}`}>
                        {metrics.clipping ? 'LIMITACE' : metrics.angle < 360 ? 'SLYŠITELNÉ' : 'NULOVÉ'}
                      </div>
                      {metrics.angle < 360 && !metrics.clipping && <div className="text-[9px] text-[#64748b]">Část periody oříznuta</div>}
                    </div>
                    <div className="col-span-2 bg-[#0f172a] text-white p-4 rounded-xl flex items-center gap-4">
                      <div className="bg-[#2563eb] p-2 rounded-lg shrink-0">
                        <Info className="w-4 h-4 text-white" />
                      </div>
                      <div className="text-left">
                        <div className="text-[10px] font-extrabold text-[#60a5fa] uppercase">TIP PRO VÝUKU</div>
                        <div className="text-[11px] leading-tight text-white/90">
                          {metrics.clipping ? "Sledujte limitaci (+1.8V) - špičky signálu jsou oříznuty." : "Sledujte, jak se při změně Biasu mění tvar modré plochy."}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
};

export default App;
